package com.pingan.qhzx.anshao.model.common.enums;

public enum MatchKnowledge {
	
	YES("匹配知识库答案", "1"), NO("不配置知识库答案", "0");
	
	private String describe;
	private String value;
	
	private  MatchKnowledge(String describe, String value) {
		this.describe = describe;
		this.value = value;
	}

	public String getDescribe() {
		return describe;
	}

	public void setDescribe(String describe) {
		this.describe = describe;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	
	
}
