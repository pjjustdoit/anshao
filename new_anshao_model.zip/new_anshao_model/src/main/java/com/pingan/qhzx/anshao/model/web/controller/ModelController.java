package com.pingan.qhzx.anshao.model.web.controller;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.common.Term;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.qhzx.anshao.model.common.bean.CreateModelBean;
import com.pingan.qhzx.anshao.model.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.model.common.utils.WebUtils;
import com.pingan.qhzx.anshao.model.common.utils.WekaModel;
import com.pingan.qhzx.anshao.model.web.bean.CvsBean;

import weka.core.Instances;

/***
 * 模型创造器
 * 
 * @author peijian280
 *
 */
@Controller
@RequestMapping("model")
public class ModelController extends BaseController {

	private static final Logger log = LoggerFactory.getLogger(ModelController.class);

	@Autowired
	private WekaModel wekaModel;
	
	@Value("${transformer.model.name}")
	private String modelTrainarffName;
	
	@Value("${sys.nas.dir}")
	private String basePath;
	
	@Value("${classifier.model.name}")
	private String modelClassifierDir;

	/***
	 * 创建模型
	 * 
	 * 步骤: 读取csv文件到requestlist， 使用hanlop分词 将分词后到string转为arff文件 使用weka
	 * stringtowordvector转换为所需到矩阵
	 * 
	 * @param request
	 * @param response
	 * @param orgId:机构id
	 *            如果orgId=all表示所有机构都要重新创建模型
	 * @return
	 * @throws Throwable
	 */
	@ResponseBody
	@RequestMapping("/createmodel")
	@ESA("ansirqa.model.createmodel")
	public JSONObject hanLP(CreateModelBean createModelBean, HttpServletRequest request, HttpServletResponse response)
			throws Throwable {
		final List<String> orgIdList = createModelBean.getOrgId();
		try {
			HanLP.Config.enableDebug();
			if (orgIdList != null && orgIdList.size() > 0) {
				// 新加线程，异步处理
				Thread t = new Thread() {
					public void run() {
						try {
							handleCreateModel(orgIdList);
						} catch (Throwable e) {
							log.info("线程异步创建模型失败,handleCreateModel fail : " + e.getMessage());
						}
					}
				};
				t.start();
				return WebUtils.createSuccResult();
			} else {
				return WebUtils.createErrorResult(ResponseEnum.FAILURE, "orgId is null");
			}
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult();
		}

	}

	private void handleCreateModel(List<String> orgIdList) throws Throwable {
		for (int i = 0; i < orgIdList.size(); i++) {
			String orgId = orgIdList.get(i);
			String hanlpResultStr = hanlpResult(orgId);
			log.info("分词结果字符串:" + hanlpResultStr);
			if("".equals(hanlpResultStr)) {    //知识库内容为空、删除模型文件
				deleteModelFile(orgId);
			} else {
				wekaModel.readStringToCSV(hanlpResultStr, orgIdList.get(i));
				wekaModel.csvToArff(orgId);
				Instances instances = wekaModel.etl(orgId);
				wekaModel.trainModels(instances, orgId);
			}
			wekaModel.resetQuestionAndAnswerPutInRedis(orgId);
		}
	}
	
	private String hanlpResult(String orgId) throws Exception {
		StringBuffer sb = new StringBuffer();
		CvsBean csvBean = wekaModel.getCvsBean(orgId);
		List<String> keywordList = csvBean.getKeyWordList();
//		List<String> keywordList = wekaModel.getKeyWords(orgId);
		WekaModel.definedKeywords(keywordList);
		List<String> questionList = csvBean.getQuestionList();
		List<String> answerList = csvBean.getAnswerList();
//		List<String> requestList = wekaModel.getQuestions(orgId);
		// List<String> labelList = wekaModel.getLabels(orgId);
//		List<String> answerList = wekaModel.getAnswers(orgId);
		for (int j = 0; j < questionList.size(); j++) {
			sb.append(answerList.get(j));
			sb.append(",");
			List<Term> termList = HanLP.segment(questionList.get(j));
			for (Term term : termList) {
				if (!isExistStopWord(term.word, orgId)) {
					sb.append(term.word + " ");
				}
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	// 判断分词是否是stopword
	protected boolean isExistStopWord(String word, String orgId) throws Exception {
		List<String> stopwordList = wekaModel.readStopWordCsv(orgId);
		return stopwordList.contains(word);
	}
	
	private void deleteModelFile(String orgId) {
		String trainsformerModelName = MessageFormat.format(modelTrainarffName, orgId);
		String trainsFormerModelNamefilepath = wekaModel.getPath(trainsformerModelName, orgId);
		String classifierModelName = MessageFormat.format(modelClassifierDir, orgId);
		String classifierModelNamefilepath = wekaModel.getPath(classifierModelName, orgId);
		deleteFile(trainsFormerModelNamefilepath);
		deleteFile(classifierModelNamefilepath);
	}
	
	/** 
	 * 删除单个文件 
	 * @param   sPath    被删除文件的文件名 
	 * @return 单个文件删除成功返回true，否则返回false 
	 */  
	private void deleteFile(String sPath) {  
	    File file = new File(sPath);  
	    // 路径为文件且不为空则进行删除  
	    if (file.isFile() && file.exists()) {  
	        file.delete();  
	    }  
	}  

}
