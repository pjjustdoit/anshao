package com.pingan.qhzx.anshao.model.service;

import java.io.File;

public interface INasWrapper {

	File createFile(String filePath);

}
