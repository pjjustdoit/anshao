package com.pingan.qhzx.anshao.model.web.interceptor;

import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Charsets;
import org.apache.http.entity.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public abstract class BaseInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(BaseInterceptor.class);

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    protected void write(HttpServletResponse response, JSONObject errorResult) throws IOException {
        try {
            response.setContentType(ContentType.APPLICATION_JSON.toString());
            ServletOutputStream outputStream = response.getOutputStream();
            outputStream.write(errorResult.toJSONString().getBytes(Charsets.UTF_8));
            outputStream.flush();
        } catch (IOException e) {
            log.debug("", e);
        }
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
