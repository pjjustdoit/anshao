package com.pingan.qhzx.anshao.model.service;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;



public class HanlpConfigService implements IHanlpConfigService, InitializingBean, DisposableBean {
	
	private static final Logger log = LoggerFactory.getLogger(HanlpConfigService.class);
	
	private Resource configure;

	@Override
	public void afterPropertiesSet() throws Exception {
//		Assert.notNull(configure, "Property 'configure' is required");
		if(configure == null) {
			throw new FatalBeanException("configure is null. ");
		}
		Properties props = null;
		try {
			props = new Properties();
			props.load(configure.getInputStream());
		} catch(Exception e) {
			throw new FatalBeanException("Create Hanlp.properties error by config:"
					+ props, e);
		}
	}

	@Override
	public void destroy() throws Exception {
		this.configure = null;
	}

	public Resource getConfigure() {
		return configure;
	}

	public void setConfigure(Resource configure) {
		this.configure = configure;
	}
	
	

}
