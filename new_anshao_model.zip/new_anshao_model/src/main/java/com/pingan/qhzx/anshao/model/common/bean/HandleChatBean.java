package com.pingan.qhzx.anshao.model.common.bean;

import java.util.Set;

import com.pingan.qhzx.anshao.model.common.enums.QuestionOrAnswer;

public class HandleChatBean  extends BaseBean {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1336321734325341871L;
	
	private Set<QuestionAnswerResultBean> questionAnswerResultBeanSet;
	private String isMatchKnowledge;
	private String questionOrAnswer;
	private String flag;   // 流程分支
	
	public Set<QuestionAnswerResultBean> getQuestionAnswerResultBeanSet() {
		return questionAnswerResultBeanSet;
	}
	public void setQuestionAnswerResultBeanSet(Set<QuestionAnswerResultBean> questionAnswerResultBeanSet) {
		this.questionAnswerResultBeanSet = questionAnswerResultBeanSet;
	}
	public String getIsMatchKnowledge() {
		return isMatchKnowledge;
	}
	public void setIsMatchKnowledge(String isMatchKnowledge) {
		this.isMatchKnowledge = isMatchKnowledge;
	}
	public String getQuestionOrAnswer() {
		return questionOrAnswer;
	}
	public void setQuestionOrAnswer(String questionOrAnswer) {
		this.questionOrAnswer = questionOrAnswer;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	
	
}
