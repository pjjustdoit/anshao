package com.pingan.qhzx.anshao.model.web.interceptor;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.model.common.utils.WebUtils;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.http.entity.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ExceptionInterceptor extends BaseInterceptor {

    private static final Logger log = LoggerFactory.getLogger(ExceptionInterceptor.class);

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        if (ex != null) {
            log.error("[!!!未处理异常!!!] path:" + request.getRequestURI(), ex);
            response.setContentType(ContentType.APPLICATION_JSON.toString());
            JSONObject errorResult = WebUtils.createErrorResult();
            errorResult.put("exception", ExceptionUtils.getMessage(ex));
            if (log.isDebugEnabled())
                errorResult.put("stackTrace", ExceptionUtils.getStackTrace(ex));
            write(response, errorResult);
            response.getWriter().flush();
        }
    }
}
