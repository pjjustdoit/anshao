package com.pingan.qhzx.anshao.model.common.mybatis;

/**
 * Created by yuzilei869 on 16/7/20.
 */
public interface BaseMapper {
}
