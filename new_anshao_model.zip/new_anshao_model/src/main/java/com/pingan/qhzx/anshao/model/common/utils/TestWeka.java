package com.pingan.qhzx.anshao.model.common.utils;

import weka.classifiers.Classifier;
import weka.classifiers.evaluation.Evaluation;
import weka.core.Instance;
import weka.core.Instances;

public class TestWeka {

//	public static void main(String[] args) {
//		Instances ins = null;  
//        Classifier cfs = null;  
//  
//        try {  
//        	String inputFile = "/Users/peijian280/Documents/model/weka/question.arff";
//	        java.io.Reader r = new java.io.BufferedReader(new java.io.FileReader(inputFile));
//	        
//	        //分词
//	        
//	        //转成词频矩阵
//	        
//	        //tfidf变换
//	        
//	        
//	        ins = new Instances(r);            
//	        ins.setClassIndex(0);  
//  
//            // 初始化分类器  
//            cfs = (Classifier) Class.forName(  
//                    "weka.classifiers.bayes.NaiveBayes").newInstance();  
//  
//            // 使用训练样本进行分类  
//            cfs.buildClassifier(ins);  
//  
//            // 使用测试样本测试分类器的学习效果  
//            Instance testInst;  
//            Evaluation testingEvaluation = new Evaluation(ins);  
//            int length = ins.numInstances();  
//            for (int i = 0; i < length; i++) {  
//                testInst = ins.instance(i);  
//                testingEvaluation.evaluateModelOnceAndRecordPrediction(cfs,  
//                        testInst);  
//                
//                System.out.println("分类的正确率" + (1 - testingEvaluation.errorRate()));
//            }  
//  
//            // 打印分类结果  
////            System.out.println("分类的正确率" + (1 - testingEvaluation.errorRate()));  
//        } catch (Exception e) {  
//            e.printStackTrace();  
//        }  
//
//	}

}
