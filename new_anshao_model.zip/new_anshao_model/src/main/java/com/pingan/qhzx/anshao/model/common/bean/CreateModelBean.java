package com.pingan.qhzx.anshao.model.common.bean;

import java.util.List;

public class CreateModelBean {
	
	private List<String> orgId;

	public List<String> getOrgId() {
		return orgId;
	}

	public void setOrgId(List<String> orgId) {
		this.orgId = orgId;
	}
	
	
}
