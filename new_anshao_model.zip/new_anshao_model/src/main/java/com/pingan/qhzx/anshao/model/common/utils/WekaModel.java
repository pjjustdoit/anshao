package com.pingan.qhzx.anshao.model.common.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.dictionary.CustomDictionary;
import com.pingan.qhzx.anshao.model.web.bean.CvsBean;
import com.pingan.qhzx.anshao.model.web.bean.QuestionAndAnswer;

import weka.classifiers.Classifier;
import weka.classifiers.evaluation.Evaluation;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SerializationHelper;
import weka.core.converters.ArffLoader;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;
import weka.core.converters.TextDirectoryLoader;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.NominalToString;
import weka.filters.unsupervised.attribute.StringToWordVector;

/***
 * weka模型创建util类
 * 
 * @author peijian280
 * 
 */
@Component
public class WekaModel {

	@Value("${knowledge.csv.name}")
	private String knowledgeCSVName;

	@Value("${stopword.csv.name}")
	private String stopwordCSVName;

	@Value("${arff.name}")
	private String modelArffName;
	
	@Value("${arff.name2}")
	private String modelArffName2;
	
	@Value("${train.arff.name}")
	private String trainArffName;
	
	@Value("${transformer.model.name}")
	private String modelTrainarffName;

	@Value("${answer.question.csv.name}")
	private String AnswerQuestionCSVName;

	@Value("${classifier.model.name}")
	private String modelClassifierDir;

	@Value("${sys.nas.dir}")
	private String basePath;
	
	@Autowired
	private RedisService redisService;
	
	private static final Logger log = LoggerFactory.getLogger(WekaModel.class);

	public List<QuestionAndAnswer> readCsv(String orgId) throws IOException {
		String knowledgefileName = MessageFormat.format(knowledgeCSVName, orgId);
		List<QuestionAndAnswer> list = new ArrayList<QuestionAndAnswer>();
		FileInputStream fileInputStream = new FileInputStream(getPath(knowledgefileName, orgId));
		InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
		BufferedReader bufferdReader = new BufferedReader(inputStreamReader);
		String str = "";

		int k = 0;
		while (null != (str = bufferdReader.readLine())) {// 每次读取一行
			QuestionAndAnswer questionAndAnswer = new QuestionAndAnswer();
			// 不读第一行
			if (StringUtils.isNotBlank(str) && StringUtils.indexOf(str, ",") > 0 && k >= 1) {
				// 以","(英文逗号)拆分
				String[] keywordsArray = str.split(",");
				for (int i = 0; i < keywordsArray.length; i++) {
					if (i == 0) {
						questionAndAnswer.setAnswer(keywordsArray[i]);
					} else if (i == 1) {
						questionAndAnswer.setKeywords(keywordsArray[i]);
					} else if (i == 2) {
						questionAndAnswer.setQuestion(keywordsArray[i]);
					}
				}
				list.add(questionAndAnswer);
			}
			k++;
		}

		bufferdReader.close();
		inputStreamReader.close();
		fileInputStream.close();
		return list;
	}
	
	/**
	 * 读取Csv数据 add by gushijie
	 * @param orgId
	 * @return
	 * @throws Exception
	 */
	public List<QuestionAndAnswer> readCsvNew(String orgId) throws Exception {
		String knowledgefileName = MessageFormat.format(knowledgeCSVName, orgId);
		List<QuestionAndAnswer> list = new ArrayList<QuestionAndAnswer>();
		
		RedisProvider redisProvider = redisService.getQuestionAndAnswerListRedis();
		if(redisProvider!=null){
			list = (List<QuestionAndAnswer>)redisProvider.get(orgId);
			if(list != null && !list.isEmpty()){ 
				log.info("redis中存在数据, 直接读取redis中的数据,orgId="+orgId);
				return list; 
			}else{ 
				log.info("redis中不存在数据, 直接读取知识库中的数据,orgId="+orgId);
				BufferedReader bufferdReader = null;
				FileInputStream fileInputStream = null;
				InputStreamReader inputStreamReader = null;
				try{
					fileInputStream = new FileInputStream(getPath(knowledgefileName, orgId));
					inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
					bufferdReader = new BufferedReader(inputStreamReader);
					list = this.setQuestionAndAnswerList(bufferdReader, list);
				}catch(IOException e){
					log.error("获取文件信息出错：" + e);
					throw new Exception ("获取文件信息出错：" + e.toString());
				}catch(Exception ex){
					log.error("设定问题和答案列表出错：" + ex);
					throw new Exception ("设定问题和答案列表出错：" + ex.toString());
				}finally{
					if(bufferdReader != null){
						bufferdReader.close();
					}
					if(inputStreamReader != null) {
						inputStreamReader.close();
					}
					if(fileInputStream!=null) {
						fileInputStream.close();
					}
				}
				
				redisProvider.remove(orgId);
				redisProvider.add(orgId, list);
			}
		}else{
			log.error("获取redis对象出错！");
			throw new Exception("获取redis对象出错！");
		}
		return list;
	}
	
	/**
	 * 初始化redis中的问题和答案数据 add by gushijie251
	 * @param orgId
	 * @throws Exception
	 */
	public void resetQuestionAndAnswerPutInRedis(String orgId)throws Exception{
		log.info("开始进入增加缓存环节>>>>"+orgId);
		String knowledgefileName = MessageFormat.format(knowledgeCSVName, orgId);
		List<QuestionAndAnswer> list = new ArrayList<QuestionAndAnswer>();
//		Integer modelNum = 0;
		RedisProvider redisProvider = redisService.getQuestionAndAnswerListRedis();
//		RedisProvider changeModelProvider = redisService.getIsChangeModelRedis();
//		RedisProvider oldModelProvider = redisService.getOldModelNumRedis();

//		if(changeModelProvider != null){
//			if(changeModelProvider.get(orgId) != null){
//				modelNum = (Integer)changeModelProvider.get(orgId);
//			}
//			modelNum = modelNum + 1 ;
//			changeModelProvider.remove(orgId);
//			oldModelProvider.remove(orgId);
//			changeModelProvider.add(orgId, modelNum);
//			oldModelProvider.add(orgId,0);
//		}
		if(redisProvider!=null){
			BufferedReader bufferdReader = null;
			FileInputStream fileInputStream = null;
			InputStreamReader inputStreamReader = null;
			try{
				fileInputStream = new FileInputStream(getPath(knowledgefileName, orgId));
				inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
				bufferdReader = new BufferedReader(inputStreamReader);
				list = this.setQuestionAndAnswerList(bufferdReader, list);
			}catch(IOException e){
				log.error("获取文件信息出错：" + e);
				throw new Exception ("获取文件信息出错：" + e.toString());
			}catch(Exception e){
				log.error("设定问题和答案列表出错！" + e);
				throw new Exception ("设定问题和答案列表出错：" + e.toString());
			}finally{
				if(bufferdReader != null){
					bufferdReader.close();
				}
				if(inputStreamReader != null) {
					inputStreamReader.close();
				}
				if(fileInputStream!=null) {
					fileInputStream.close();
				}
			}
			
			redisProvider.remove(orgId);
			redisProvider.add(orgId, list);
			log.info("增加缓存结束>>>>"+orgId);
		}else{
			log.error("获取redis对象出错！");
			throw new Exception("获取redis对象出错！");
		}
	}
	
	/**
	 *  设定问题和答案列表 add by gushijie251
	 * @param bufferdReader
	 * @param list
	 * @throws Exception
	 */
	private List<QuestionAndAnswer> setQuestionAndAnswerList(BufferedReader bufferdReader,List<QuestionAndAnswer> list) throws Exception{
		list = new ArrayList<QuestionAndAnswer>();
		String str = "";
		int k = 0;
		while (null != (str = bufferdReader.readLine())) {// 每次读取一行
			QuestionAndAnswer questionAndAnswer = new QuestionAndAnswer();
			// 不读第一行
			if (StringUtils.isNotBlank(str) && StringUtils.indexOf(str, ",") > 0 && k >= 1) {
				// 以","(英文逗号)拆分
				String[] keywordsArray = str.split(",");
				for (int i = 0; i < keywordsArray.length; i++) {
					if (i == 0) {
						questionAndAnswer.setAnswer(keywordsArray[i]);
					} else if (i == 1) {
						questionAndAnswer.setKeywords(keywordsArray[i]);
					} else if (i == 2) {
						questionAndAnswer.setQuestion(keywordsArray[i]);
					}
				}
				list.add(questionAndAnswer);
			}
			k++;
		}
		return list;
	}

	public List<String> readStopWordCsv(String orgId) throws Exception {
		List<String> list = new ArrayList<String>();
		String stopwordName = MessageFormat.format(stopwordCSVName, orgId);
		FileInputStream fileInputStream = null;
		InputStreamReader inputStreamReader = null;
		BufferedReader bufferdReader = null;
		try {
			fileInputStream = new FileInputStream(getPath(stopwordName, orgId));
			inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
			bufferdReader = new BufferedReader(inputStreamReader);
			String str = "";
			int k = 0;
			while (null != (str = bufferdReader.readLine())) {// 每次读取一行
				// 不读第一行
				if (StringUtils.isNotBlank(str) && k >= 1) {
					list.add(str);
				}
				k++;
			}
			bufferdReader.close();
		} catch(Exception e) {
			log.error("readStopWordCsv fail msg: "+e.getMessage());
		} finally {
			if(bufferdReader!=null) {
				bufferdReader.close();
			}
			if(inputStreamReader!=null) {
				inputStreamReader.close();
			}
			if(fileInputStream!=null) {
				fileInputStream.close();
			}
		}
		
		return list;
	}

	// 获取问题列表
	public List<String> getQuestions(String orgId) throws IOException,Exception {
		List<String> questionList = new ArrayList<String>();
//		List<QuestionAndAnswer> list = readCsv(orgId); 
		List<QuestionAndAnswer> list = readCsvNew(orgId); 
		for (QuestionAndAnswer questionAndAnswer : list) {
			String question = questionAndAnswer.getQuestion();
			questionList.add(question);
		}
		return questionList;
	}

	// 获取label列表
//	public List<String> getLabels(String orgId) throws IOException {
//		List<String> labelList = new ArrayList<String>();
//		List<QuestionAndAnswer> list = readCsv(orgId);
//		for (QuestionAndAnswer labelObject : list) {
//			String label = labelObject.getLabel();
//			labelList.add(label);
//		}
//		return labelList;
//	}

	// 获取keyword列表
	public List<String> getKeyWords(String orgId) throws IOException,Exception {
		List<String> keywordList = new ArrayList<String>();
//		List<QuestionAndAnswer> list = readCsv(orgId); 
		List<QuestionAndAnswer> list = readCsvNew(orgId); 
		for (QuestionAndAnswer labelObject : list) {
			String keyword = labelObject.getKeywords();
			keywordList.add(keyword);
		}
		return keywordList;
	}
	
	// 获取keyword列表
		public List<String> getAnswers(String orgId) throws IOException,Exception {
			List<String> answerList = new ArrayList<String>();
//			List<QuestionAndAnswer> list = readCsv(orgId); 
			List<QuestionAndAnswer> list = readCsvNew(orgId); 
			for (QuestionAndAnswer labelObject : list) {
				String answer = labelObject.getAnswer();
				answerList.add(answer);
			}
			return answerList;
		}

	public void createArff(String str, String orgId) throws IOException {
		String arffName = MessageFormat.format(modelArffName, orgId);
		String arffName2 = MessageFormat.format(modelArffName2, orgId, 2);
		Instances instance = generatePopularInstance2(str);
		// save ARFF
		ArffSaver saver = new ArffSaver();
		saver.setInstances(instance);
		saver.setFile(new File(getPath(arffName2, orgId)));
		saver.setDestination(new File(getPath(arffName, orgId)));
		saver.writeBatch();
	}

	// 创建instance
	public static Instances generatePopularInstance(String str) {
		// set attributes
		ArrayList<Attribute> attributes = new ArrayList<Attribute>();
		attributes.add(new Attribute("fork"));
		// set instances
		Instances instances = new Instances("Data", attributes, 0);
		instances.setClassIndex(instances.numAttributes() - 1);
		// add instance
		Instance instance = new DenseInstance(attributes.size());
		instance.setValue(attributes.get(0), str);
		instance.setDataset(instances);
		// instances.add(instance);
		return instances;
	}

	// 创建instance
	public static Instances generatePopularInstance2(String str) {
		ArrayList<Attribute> attributes = new ArrayList<Attribute>();
		Attribute question = new Attribute("question");
		Attribute Label = new Attribute("Label");
		attributes.add(question);
		attributes.add(Label);
		// add instance
		Instance inst = new DenseInstance(2);

		inst.setValue(0, 5.3);
		inst.setValue(1, 300);

		log.info("generatePopularInstance2:[]{}",inst);

		// Instances df = new Instances("Data", attributes, 0);
		//// Instances df = new Instances("predictData", atts, 0);
		// df.setClassIndex(df.numAttributes() - 1);
		//// Instances df = new Instances("Data", attributes, 2);
		//
		//
		// inst.setDataset(df);
		return null;
	}

	/***
	 * 处理stringtowordvector
	 * 
	 * @throws Exception
	 */
	public void handleStringToWordVector(String orgId) throws Exception {
		String arffName = MessageFormat.format(modelArffName, orgId);
		String trainarffName = MessageFormat.format(trainArffName, orgId);
		InputStream input = null;
		FileWriter fileWriter=null;
		BufferedWriter bw = null;
		try {
			TextDirectoryLoader tdl = new TextDirectoryLoader();
			// tdl.setDirectory(new File(arffDir));
			input = new FileInputStream(new File(getPath(arffName, orgId)));

			tdl.setSource(input);
			Instances ins = tdl.getDataSet();
			ins.setClassIndex(0);

			// 将字符串属性转换为表示词频的词属性向量空间
			StringToWordVector filter = new StringToWordVector();
			// filter.setUseStoplist(true);
			filter.setTFTransform(true);
			filter.setIDFTransform(true);
			// LovinsStemmer stemmer = new LovinsStemmer ();
			// filter.setStemmer(stemmer);
			filter.setMinTermFreq(1);
			// filter.setWordsToKeep(500);
			filter.setInputFormat(ins);
			Instances newtrain = Filter.useFilter(ins, filter);
			fileWriter = new FileWriter(new File(getPath(trainarffName, orgId)));
			bw = new BufferedWriter(fileWriter);
			bw.write(newtrain.toString());
			bw.flush();
			
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(fileWriter != null){
				try{
					fileWriter.close();
				}catch(Exception e){
					log.error("{}",e);
				}
			}
			if(bw != null){
				try{
					bw.close();
				}catch(Exception e){
					log.error("{}",e);
				}
			}
			
			if(input != null){
				try{
					input.close();
				}catch(Exception e){
					log.error("{}",e);
				}
			}
			
			
		}

	}
	
	/**
	 * 从知识库的csv文件里提取出label、question列来插入到新到csv文件中
	 * 新csv文件命名规范：{orgId}_labelquestion.csv
	 * @throws IOException 
	 */
	public void readStringToCSV(String str, String orgId) throws IOException {
		String labelQuestionName = MessageFormat.format(AnswerQuestionCSVName, orgId);
		File file = new File(getPath(labelQuestionName, orgId));
		FileOutputStream out = null;
		OutputStreamWriter osw = null;
		BufferedWriter bw = null;
		try {
			out = new FileOutputStream(file);
			osw = new OutputStreamWriter(out);
			bw = new BufferedWriter(osw);
			bw.write("Answer,Question" + "\r" + str);
		} catch (Exception e) {
//			throw new IOException(e);
		} finally {
			if (bw != null) {
				try {
					bw.close();
					bw = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (osw != null) {
				try {
					osw.close();
					osw = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (out != null) {
				try {
					out.close();
					out = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * 将新生成到到{orgId}_labelquestion.csv文件转换成arff格式文件
	 * arff文件命名规范:{orgId}.arff
	 */
	public void csvToArff(String orgId) throws Exception {
		String answerQuestionName = MessageFormat.format(AnswerQuestionCSVName, orgId);
		String arffName = MessageFormat.format(modelArffName, orgId);
		String arffName2 = MessageFormat.format(modelArffName2, orgId, 2);
		CSVLoader loader = new CSVLoader();
		FileInputStream fileInputStream = new FileInputStream(getPath(answerQuestionName, orgId));
		loader.setSource(fileInputStream);
		Instances dataRaw = loader.getDataSet();

		// 这步很关键,instance增加一个string类型到attribute
		NominalToString filter = new NominalToString();
		filter.setInputFormat(dataRaw);
		// filter.setAttributeIndexes("1,");
		dataRaw = Filter.useFilter(dataRaw, filter);
		// save ARFF
		ArffSaver saver = new ArffSaver();
		saver.setInstances(dataRaw);
		saver.setFile(new File(getPath(arffName2, orgId)));
		saver.setDestination(new File(getPath(arffName, orgId)));
		saver.writeBatch();
		try{
			fileInputStream.close();
		}catch(Exception e){
			log.error("{}",e);
		}finally{
			if(fileInputStream != null){
				try{
					fileInputStream.close();
				}catch(Exception e2){
					log.error("{}",e2);
				}
			}
		}
	}
	
	/**
	 * 数据预处理
	 * 通过StringToWordVector
	 * 将模型序列化保存到文件trainsformer.model
	 * 
	 */
	public Instances etl(String orgId) throws Exception {
		String arffName = MessageFormat.format(modelArffName, orgId);
		String trainarffName = MessageFormat.format(trainArffName, orgId);
		String trainsformerModelName = MessageFormat.format(modelTrainarffName, orgId);
		FileWriter fileWriter = null;
		BufferedWriter bw = null;
		Instances newtrain = null;
		try {
			File inputFile = new File(getPath(arffName, orgId));
			ArffLoader atf = new ArffLoader();
			atf.setFile(inputFile);
			Instances data = atf.getDataSet();

			StringToWordVector filter = new StringToWordVector();
			// filter.setUseStoplist(true);
			filter.setTFTransform(true);
			filter.setIDFTransform(true);
			filter.setMinTermFreq(1);
			// filter.setWordsToKeep(500);
			filter.setInputFormat(data);

			newtrain = Filter.useFilter(data, filter);

			SerializationHelper.write(getPath(trainsformerModelName, orgId), filter);
			
			fileWriter = new FileWriter(new File(getPath(trainarffName, orgId)));
			bw = new BufferedWriter(fileWriter);
			bw.write(newtrain.toString());
			bw.flush();
			
			// StringToNominal strToNom = new StringToNominal();
		} catch(Exception e) {
			throw new Exception(e);
		} finally{
			if(fileWriter != null){
				try{
					fileWriter.close();
				}catch(Exception e){
					log.error("{}",e);
				}
			}
			if(bw != null){
				try{
					bw.close();
				}catch(Exception e){
					log.error("{}",e);
				}
			}
			
		}
		return newtrain;
	}

	// 训练模型，并将分类器保存到文件classifier.model
	public void trainModels(Instances ins, String orgId) throws Throwable {
//		String classifierModelName = orgId+"_classifier.model";
		String classifierModelName = MessageFormat.format(modelClassifierDir, orgId);
		ins.setClassIndex(0);
		// 初始化分类器
		Classifier cfs = (Classifier) Class.forName("weka.classifiers.bayes.NaiveBayes").newInstance();
		// 使用训练样本进行分类
		cfs.buildClassifier(ins);
		SerializationHelper.write(getPath(classifierModelName, orgId), cfs);
		// 使用测试样本测试分类器的学习效果
		Instance testInst;
		Evaluation testingEvaluation = new Evaluation(ins);
		int length = ins.numInstances();
		for (int i = 0; i < length; i++) {
			testInst = ins.instance(i);
			testingEvaluation.evaluateModelOnceAndRecordPrediction(cfs, testInst);
			log.info("分类的正确率" + (1 - testingEvaluation.errorRate()));
		}
	}

	public static Instances newInstances(String userquestion) {
		ArrayList<Attribute> atts = new ArrayList<Attribute>(2);
		ArrayList<String> label = new ArrayList<String>();
		label.add("default");
		atts.add(new Attribute("Label", label));
		atts.add(new Attribute("question", (ArrayList<String>) null));

		Instances dataRaw = new Instances("TestInstances", atts, 0);

		double[] instanceValue = new double[dataRaw.numAttributes()];
		instanceValue[0] = 0;
		instanceValue[1] = dataRaw.attribute(1).addStringValue(userquestion);

		dataRaw.add(new DenseInstance(1.0, instanceValue));

		return dataRaw;
	}

	// 将关键字自定义分词,每个关键字都是一个词,eg:你好吗,就是一个词
	public static void definedKeywords(List<String> keywordlist) {
		HanLP.newSegment().enableCustomDictionary(true);
		if (keywordlist != null && keywordlist.size() > 0) {
			for (String keyword : keywordlist) {
				CustomDictionary.add(keyword);
			}

		}
	}
	
	//获取存放商户的模型文件路径
	public String getPath(String filePath, String orgId) {
		String modelPath = MessageFormat.format(basePath, orgId);
		log.info("modelPath:[{}]", modelPath);
		return modelPath + filePath;
	}
	
	
	/**
	 * 根据机构ID获取cvs内容
	 * @param argId
	 * @return
	 * @throws Exception
	 */
	public CvsBean getCvsBean(String argId)throws Exception{
		List<String> questionList = new ArrayList<String>();
		List<String> keywordList = new ArrayList<String>();
		List<String> answerList = new ArrayList<String>();
		CvsBean cvsBean = new CvsBean();
//		List<QuestionAndAnswer> list = readCsvNew(argId); 
		List<QuestionAndAnswer> list = readCsv(argId); 
		for (QuestionAndAnswer labelObject : list) {
			String keyword = labelObject.getKeywords();
			String question = labelObject.getQuestion();
			String answer = labelObject.getAnswer();
			keywordList.add(keyword);
			questionList.add(question);
			answerList.add(answer);
		}
		cvsBean.setAnswerList(answerList);
		cvsBean.setKeyWordList(keywordList);
		cvsBean.setQuestionList(questionList);
		return cvsBean;
	}

}
