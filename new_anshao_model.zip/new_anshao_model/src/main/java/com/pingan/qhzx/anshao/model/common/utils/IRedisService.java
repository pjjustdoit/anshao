package com.pingan.qhzx.anshao.model.common.utils;

import java.util.List;
import java.util.Map;

import com.pingan.qhzx.anshao.model.common.bean.HandleChatBean;

import weka.core.Instances;

/**
 * Created by yuzilei869 on 16/7/21.
 */
public interface IRedisService {
    
    RedisProvider<Integer> getIsChangeModelRedis();
    
    RedisProvider<Integer> getOldModelNumRedis();
    
    RedisProvider<Map> getAnswerQuestionMapRedis();
    
    RedisProvider<Map> getAnswerProbMapRedis();
    
    RedisProvider<List> getQuestionKWanswerListRedis();
    
    RedisProvider<List> getQuestionAndAnswerListRedis();

}
