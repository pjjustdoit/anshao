package com.pingan.qhzx.anshao.model.service;

public interface IHanlpConfigService {

}
