package com.pingan.qhzx.anshao.model.common.utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MapUtils {
	
	//获取map key list
	public static List<Integer> keyList(Map<Integer, Object> map) {
		List<Integer> keyList = new ArrayList<Integer>();
		Set<Integer> keylist = map.keySet();
		for(Iterator iter = keylist.iterator(); iter.hasNext();) {
		   Integer key = (Integer)iter.next();
		   keyList.add(key);
		}
		return keyList;
	}
}
