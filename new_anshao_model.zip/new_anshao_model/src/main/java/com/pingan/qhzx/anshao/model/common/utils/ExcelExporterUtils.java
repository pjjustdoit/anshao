package com.pingan.qhzx.anshao.model.common.utils;

import com.google.common.collect.Lists;
import com.pingan.qhzx.anshao.model.common.ex.ServiceException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

import java.beans.PropertyDescriptor;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by yuzilei869 on 16/4/27.
 */
public class ExcelExporterUtils {

    private static final Logger log = LoggerFactory.getLogger(ExcelExporterUtils.class);

    public static <T> ByteArrayOutputStream export(List<T> data, List<FiledDefine> filedDefines) {
        return ExcelWriter.exportExcel(new ExportConfiguration<T>(data, filedDefines));
    }

    public static <T> ByteArrayOutputStream export(List<ExportConfiguration<T>> allData) {
        return ExcelWriter.exportExcel(allData);
    }


    public enum FiledType {

        DATE,

        NUMBER,

        STRING

    }

    public static class ExportConfiguration<T> {

        private List<T> data;


        private List<FiledDefine> filedDefines = Lists.newArrayList();


        public ExportConfiguration(List<T> data, List<FiledDefine> filedDefines) {
            this.data = data;
            this.filedDefines = Lists.newArrayList(filedDefines);
        }

        public List<T> getData() {
            return data;
        }

        public List<FiledDefine> getFiledDefines() {
            return filedDefines;
        }
    }

    public static class FiledDefine {

        private String title;

        private String filedName;

        private FiledType filedType;

        private String formatPatten;

        private String defaultVal;

        public FiledDefine(String title, String filedName, FiledType filedType, String formatPatten, String defaultVal) {
            this.defaultVal = defaultVal;
            this.filedName = filedName;
            this.filedType = filedType;
            this.formatPatten = formatPatten;
            this.title = title;
        }

        public FiledDefine(String title, String filedName, FiledType filedType) {
            this(title, filedName, filedType, null, null);

        }

        public FiledDefine(String title, String filedName) {
            this(title, filedName, FiledType.STRING);
        }
    }

    public static class ExcelWriter {

        public static <T> void createSheetData(HSSFWorkbook wb, ExportConfiguration<T> exportConfiguration, String sheetName) {
            // 创建Excel的工作书册 Workbook,对应到一个excel文档
            HSSFSheet sheet = createSheetTemplate(exportConfiguration, wb, sheetName);
            List<T> data = exportConfiguration.getData();
            if (data != null) {
                // 数据
                for (int i = 0; i < data.size(); i++) {
                    // 数据行从第二行开始
                    HSSFRow row = sheet.createRow(i + 1);
                    writeRow(row, data.get(i), exportConfiguration.getFiledDefines());
                }
            }
        }

        /*
         * 生成多个sheet
         */
        public static <T> ByteArrayOutputStream exportExcel(List<ExportConfiguration<T>> allData) {
            HSSFWorkbook wb = new HSSFWorkbook();
            try {
                for (int i = 0; i < allData.size(); i++) {
                    createSheetData(wb, allData.get(i), "sheet" + i);
                }
                ByteArrayOutputStream os = new ByteArrayOutputStream(1024 * 1024);
                wb.write(os);
                return os;
            } catch (IOException e) {
                log.error("", e);
                throw new ServiceException("", e);
            } finally {

            }

        }

        public static <T> ByteArrayOutputStream exportExcel(ExportConfiguration<T> exportConfiguration) {
            HSSFWorkbook wb = new HSSFWorkbook();
            try {
                // 创建Excel的工作书册 Workbook,对应到一个excel文档
                HSSFSheet sheet = createSheetTemplate(exportConfiguration, wb, "sheet");
                List<T> data = exportConfiguration.getData();
                if (data != null) {
                    // 数据
                    for (int i = 0; i < data.size(); i++) {
                        // 数据行从第二行开始
                        HSSFRow row = sheet.createRow(i + 1);
                        writeRow(row, data.get(i), exportConfiguration.getFiledDefines());
                    }
                }
                ByteArrayOutputStream os = new ByteArrayOutputStream(1024 * 1024);
                wb.write(os);
                return os;
            } catch (IOException e) {
                log.error("", e);
                throw new ServiceException("", e);
            } finally {
            }

        }

        private static <T> HSSFSheet createSheetTemplate(ExportConfiguration<T> head, HSSFWorkbook wb, String sheetName) {
            // 创建Excel的工作sheet,对应到一个excel文档的tab
            HSSFSheet sheet = wb.createSheet(sheetName);
            setFont(wb);
            // title行
            setTitle(head, sheet);
            return sheet;
        }

        private static <T> void writeRow(HSSFRow row, T feeSerialExcelBean, List<FiledDefine> filedDefines) {
            for (int i = 0; i < filedDefines.size(); i++) {
                HSSFCell cell = row.createCell(i);
                cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                FiledDefine filedDefine = filedDefines.get(i);
                cell.setCellValue(getStringValue(feeSerialExcelBean, filedDefine));
            }
        }

        private static <T> String getStringValue(T feeSerialExcelBean, FiledDefine filedDefine) {
            Object obj = getPropertieByName(feeSerialExcelBean, filedDefine.filedName);
            if (obj == null) {
                if (filedDefine.defaultVal != null) {
                    return filedDefine.defaultVal;
                }
                return StringUtils.EMPTY;
            }
            if (filedDefine.filedType == FiledType.STRING) {
                return obj.toString();
            }
            if (filedDefine.filedType == FiledType.NUMBER) {
                if (StringUtils.isBlank(filedDefine.formatPatten)) {
                    filedDefine.formatPatten = "#0.00";
                }
                DecimalFormat df = new DecimalFormat(filedDefine.formatPatten);
                return df.format(obj);
            }
            if (filedDefine.filedType == FiledType.DATE) {
                if (StringUtils.isBlank(filedDefine.formatPatten)) {
                    filedDefine.formatPatten = "yyyy-MM-dd HH:mm:ss";
                }
                return DateFormatUtils.format((Date) obj, filedDefine.formatPatten);
            }
            return obj.toString();
        }

        private static <T> Object getPropertieByName(T feeSerialExcelBean, String filedName) {
            PropertyDescriptor propertyDescriptor = BeanUtils.getPropertyDescriptor(feeSerialExcelBean.getClass(), filedName);

            try {
                Method readMethod = propertyDescriptor.getReadMethod();

                if (!Modifier.isPublic(readMethod.getDeclaringClass().getModifiers())) {
                    readMethod.setAccessible(true);
                }
                return readMethod.invoke(feeSerialExcelBean);
            } catch (Exception e) {
                log.error("", e);
                throw new ServiceException(filedName + " undefined!!!", e);
            }
        }

        private static <T> void setTitle(ExportConfiguration<T> head, HSSFSheet sheet) {
            HSSFRow row = sheet.createRow(0);

            List<FiledDefine> filedDefines = head.getFiledDefines();
            for (int i = 0; i < filedDefines.size(); i++) {
                HSSFCell cell = row.createCell(i);
                cell.setCellType(HSSFCell.CELL_TYPE_STRING);

                FiledDefine filedDefine = filedDefines.get(i);
                cell.setCellValue(filedDefine.title);

            }

        }

        private static void setFont(HSSFWorkbook wb) {
            // 创建字体样式
            HSSFFont font = getHssfFont(wb);

            // 创建单元格样式
            HSSFCellStyle style = wb.createCellStyle();
            style.setFont(font);// 设置字体
        }

        private static HSSFFont getHssfFont(HSSFWorkbook wb) {
            HSSFFont font = wb.createFont();
            font.setFontName("Verdana");
            font.setBoldweight((short) 100);
            font.setFontHeight((short) 300);
            font.setColor(HSSFColor.BLACK.index);
            return font;
        }
    }
}
