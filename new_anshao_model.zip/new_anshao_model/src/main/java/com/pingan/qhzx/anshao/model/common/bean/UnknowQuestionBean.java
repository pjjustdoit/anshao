package com.pingan.qhzx.anshao.model.common.bean;

import java.util.Date;

import com.paic.pafa.biz.dto.BaseDTO;

public class UnknowQuestionBean {
	
	private String questionContent;    //问题
	private String questionSource;       //问题来源
	private String accountId;      //客户id
	private String orgId;           //机构id
	private Date questionDate;      //提问时间
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public Date getQuestionDate() {
		return questionDate;
	}
	public void setQuestionDate(Date questionDate) {
		this.questionDate = questionDate;
	}
	public String getQuestionContent() {
		return questionContent;
	}
	public void setQuestionContent(String questionContent) {
		this.questionContent = questionContent;
	}
	public String getQuestionSource() {
		return questionSource;
	}
	public void setQuestionSource(String questionSource) {
		this.questionSource = questionSource;
	}
	
}
