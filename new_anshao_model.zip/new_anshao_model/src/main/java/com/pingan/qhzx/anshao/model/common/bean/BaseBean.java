package com.pingan.qhzx.anshao.model.common.bean;

import java.io.Serializable;

public abstract class BaseBean implements Serializable {
	
}
