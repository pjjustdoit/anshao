package com.pingan.qhzx.anshao.model.common.web.session.ser;

import com.alibaba.com.caucho.hessian.io.Deserializer;
import com.alibaba.com.caucho.hessian.io.HessianProtocolException;
import com.alibaba.com.caucho.hessian.io.SerializerFactory;
import com.pingan.pafa.pizza.classloader.PizzaClassLoader;
import org.apache.commons.lang.reflect.MethodUtils;
import org.slf4j.Logger;

import java.lang.reflect.Field;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * Created by yuzilei022 on 16/9/14.
 */
public class Hessian2SerializerFactory extends SerializerFactory {

    public static final SerializerFactory SERIALIZER_FACTORY = new Hessian2SerializerFactory();
    private static final Logger log = getLogger(Hessian2SerializerFactory.class);

    public ClassLoader getClassLoader() {
        return Thread.currentThread().getContextClassLoader();
    }

    public Deserializer getDeserializer(String type) throws HessianProtocolException {
        Deserializer deserializer = super.getDeserializer(type);
        if (deserializer == null) {
            return deserializer;
        }
        ClassLoader classLoader = getClassLoader();
        if (!(deserializer.getType().getClassLoader() instanceof PizzaClassLoader) || deserializer.getType().getClassLoader() == classLoader) {
            return deserializer;
        }
        clearCache(type);
        return super.getDeserializer(type);
    }

    private void clearCache(String type) throws HessianProtocolException {
        try {
            Field cachedTypeDeserializerMap = SerializerFactory.class.getDeclaredField("_cachedTypeDeserializerMap");
            cachedTypeDeserializerMap.setAccessible(true);
            Object o = cachedTypeDeserializerMap.get(this);
            synchronized (o) {
                MethodUtils.invokeMethod(o, "remove", type);
            }
        } catch (Exception e) {
            log.error("", e);
        }
    }
}
