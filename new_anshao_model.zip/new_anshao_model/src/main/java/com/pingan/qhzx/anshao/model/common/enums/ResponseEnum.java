package com.pingan.qhzx.anshao.model.common.enums;

/**
 * Created by yuzilei869 on 16/7/20.
 */
public enum ResponseEnum {
    /**
     * =====================================
     * 0-99
     * =====================================
     */
    SUCCESS("0", "ok"),
    FAILURE("1", "Operation failed."),
    INVALID_PARAMS("2", "Invalid parameter"),
    INVALID_SIGN("3", "Invalid sign"),
    UNKNOWN_ERROR("4", "unknown error"),
    INNER_ERROR("9", "Inner Error"),
    INVALID_LOGIN_PWD("10", "Invalid login password"),
    LOGIN_PASSWORD_ERROR_LIMIT("12", "login error 4 times at least,can not login in 60 min"),
    INVALID_REG_NAME("13", "invalid name"),
    IDCARD_NOT_BELONG_TO_USER("14", "this id card doesn't belong to this user"),
    PHONE_EXIST("20", "Phone exist"),
    PHONE_NOT_EXIST("21", "Phone don't exist"),
    PHONE_INVALID("22", "Invalid phone"),
    PHONE_SEND_OVER_LIMIT("23","This phone number is sent out of limit"),
    IDENTITYID_INVALID("25", "identity invalid"),
    IDENTITYID_SHOULD_BE_SAME("26", "identity should be same"),
    IDENTITYID_ILLEGAL("27", "identity illegal"),

    /**
     * =====================================
     * 100-199
     * =====================================
     */
    VCODE_PHONE_OVER_LIMIT("100", "sending vcode is over limit"),
    VCODE_IP_OVER_LIMIT("101", "sending vcode is over limit"),
    VCODE_FAULT_OVER_LIMIT("102", "fault vcode is over limit"),
    VCODE_TOO_MUCH("103", "Number of sending vcode is too much"),
    VCODE_NOT_EXIST("104", "Vcode don't exist"),
    VCODE_OVER_TIME("105", "Vcode over time"),
    VCODE_INCORRECT("106", "Vcode is incorrect"),
    VCODE_ERROR_MORE_THAN_MAX("107", "Vcode error times more than max"),
    VCODE_SENDING_FAIL("108", "failed to send vcode"),
    SECURITY_CODE_ERROR("110", "Security code error"),
    SECURITY_PWD_IRREGULAR("111", "Password is irregular"),

    /**
     * =====================================
     * 200-399
     * =====================================
     */
    PUNCHED_IN_TODAY("200", "punched in today!"),
    USERNAME_IS_EMPTY("201", "userName is empty!"),
    ID_CARD_NO_IS_EMPTY("202", "idCardNo is empty!"),
    IDCARDNO_HAS_BE_REGISTER("203", "idCardNo has be register!"),

    /**
     * =====================================
     * 1000-1999
     * =====================================
     */
    USER_FROZEN("1000", "frozen user"),
    USER_NOT_EXIST("1001", "user not exist"),
    USER_EXIST("1002", "user exist"),
    USER_NOT_LOGIN("1003", "user not login"),

    IDCARD_NAME_NOT_MATCH("1100", "ID card and name is not match"),

    IMAGE_SIZE_BEYOND_10M("1107", "image size beyond 10M"),
    PARAM_ERROR("1500", "error in param,same param"),
    PARAM_EMPTY_SIGN("1501", "empty sign"),
    PARAMS_ERROR_SIGN("1502", "error sign,can not recognize sign"),
    PARAMS_COMMON_LACK_OR_ILLEGAL("1503", "lacking or illegal common params"),


    /**
     * 2000-2999
     */
    POINT_NOT_ENOUGH("2000", "point not enough"),
    GESTURE_ILLEGAL_LOGINTOKEN("2200", "illegal login token"),


    /**
     * =====================================
     * 10000-19999
     * =====================================
     */
    IDCARD_QUERY_FAILURE("10006", "quert idcard failure"),

    INVALID_VUID("10007", "Verify code error, please re-enter "),
    
    /***
     * 模型
     */
    NOT_EXIST_MODEL_FILE("20000", "model file is not exist ");


    private String code;


    private String message;

    // 构造方法
    private ResponseEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }


    public String getMessage() {
        return message;
    }

}
