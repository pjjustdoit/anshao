
package com.pingan.qhzx.anshao.model.common.utils;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.pingan.pafa.redis.Redis;
import com.pingan.pafa.redis.cache.RedisCacheBean;
import com.pingan.qhzx.anshao.model.common.bean.HandleChatBean;

import weka.core.Instances;

/**
 * Created by gushijie251 on 16/10/25.
 */
@Service
public class RedisService implements InitializingBean, IRedisService {

    public static final String SET_RADIS_IS_CHANGE_MODEL_NUM = "setRedis->isChangeModelNum:";
    public static final String SET_RADIS_OLD_MODEL_NUM = "setRedis->oldModelNum:";
    public static final String SET_RADIS_QUESTION_KW_ANSWER_LIST = "setRedis->QuestionKWanswerList:";
    public static final String SET_RADIS_ANSWER_PROB_MAP = "setRedis->AnswerProbMap:";
    public static final String SET_RADIS_ANSWER_QUESTION_MAP = "setRedis->AnswerQuestionMap:";
    public static final String SET_RADIS_QUESTION_AND_ANSWER_LIST = "setRedis->QuestionAndAnswerList:";
    

    @Resource(name = "ansirqa_redis")
    private Redis redis;
    

    private Map<String, RedisProvider> cache = Maps.newHashMap();


    protected <T> RedisProvider<T> getProvider(String cacheName) {
        return cache.get(cacheName);
    }
    

    public void afterPropertiesSet() throws Exception {
        registerProvider(SET_RADIS_QUESTION_KW_ANSWER_LIST, -1, List.class);
        registerProvider(SET_RADIS_ANSWER_PROB_MAP, -1, Map.class);
        registerProvider(SET_RADIS_ANSWER_QUESTION_MAP, -1, Map.class);
        registerProvider(SET_RADIS_IS_CHANGE_MODEL_NUM,-1,Integer.class);
        registerProvider(SET_RADIS_OLD_MODEL_NUM,-1,Integer.class);
        registerProvider(SET_RADIS_QUESTION_AND_ANSWER_LIST, -1, List.class);
    }

	private void registerProvider(String key, int expire, Class<?> aClass) {
        cache.put(key, RedisProvider.buildProvider(expire, new RedisCacheBean(key, redis, aClass)));
    }


	@Override
	public RedisProvider<Integer> getIsChangeModelRedis() {
		
		return getProvider(SET_RADIS_IS_CHANGE_MODEL_NUM);
	}


	@Override
	public RedisProvider<Integer> getOldModelNumRedis() {
		
		return getProvider(SET_RADIS_OLD_MODEL_NUM);
	}


	@Override
	public RedisProvider<Map> getAnswerQuestionMapRedis() {
		
		return getProvider(SET_RADIS_ANSWER_QUESTION_MAP);
	}


	@Override
	public RedisProvider<Map> getAnswerProbMapRedis() {
		
		return getProvider(SET_RADIS_ANSWER_PROB_MAP);
	}


	@Override
	public RedisProvider<List> getQuestionKWanswerListRedis() {
		
		return getProvider(SET_RADIS_QUESTION_KW_ANSWER_LIST);
	}


	@Override
	public RedisProvider<List> getQuestionAndAnswerListRedis() {

		return getProvider(SET_RADIS_QUESTION_AND_ANSWER_LIST);
	}


	


	


	
}
