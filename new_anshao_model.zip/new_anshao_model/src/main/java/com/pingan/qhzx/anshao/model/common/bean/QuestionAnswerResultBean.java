package com.pingan.qhzx.anshao.model.common.bean;

import java.io.Serializable;

public class QuestionAnswerResultBean implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String question;
	private String answer;
	private double classifierValue; // 模型概率

	public QuestionAnswerResultBean(String question, String answer, double classifierValue) {
		this.question = question;
		this.answer = answer;
		this.classifierValue = classifierValue;
	}

	public QuestionAnswerResultBean(String question, String answer) {
		this.question = question;
		this.answer = answer;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public double getClassifierValue() {
		return classifierValue;
	}

	public void setClassifierValue(double classifierValue) {
		this.classifierValue = classifierValue;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (this == obj)
			return true;
		if (obj instanceof QuestionAnswerResultBean) {
			QuestionAnswerResultBean questionAnswerResultBean = (QuestionAnswerResultBean) obj;
			// 比较question和answer和classifierValue 一致时才返回true 之后再去比较 hashCode
			if (questionAnswerResultBean.question.equals(this.question)
					&& questionAnswerResultBean.answer.equals(this.answer)
					&& questionAnswerResultBean.classifierValue == this.classifierValue)
				return true;
		}
		return false;
	}
	
	/** 
     * 重写hashcode 方法，返回的hashCode 不一样才认定为不同的对象 
     */  
    @Override  
    public int hashCode() {  
        return question.hashCode() * answer.hashCode();  
    }  

}
