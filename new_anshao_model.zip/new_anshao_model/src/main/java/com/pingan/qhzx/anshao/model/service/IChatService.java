package com.pingan.qhzx.anshao.model.service;

import java.util.List;

import com.pingan.qhzx.anshao.model.common.bean.UnknowQuestionBean;

public interface IChatService {

	void insertUnknowQuestion(List<UnknowQuestionBean> unknowQuestionBeanList);

}
