package com.pingan.qhzx.anshao.model.web.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.dictionary.CustomDictionary;
import com.hankcs.hanlp.seg.common.Term;
import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.qhzx.anshao.model.common.bean.DebugBean;
import com.pingan.qhzx.anshao.model.common.bean.HandleChatBean;
import com.pingan.qhzx.anshao.model.common.bean.QuestionAnswerResultBean;
import com.pingan.qhzx.anshao.model.common.bean.QuestionBean;
import com.pingan.qhzx.anshao.model.common.bean.UnknowQuestionBean;
import com.pingan.qhzx.anshao.model.common.enums.MatchKnowledge;
import com.pingan.qhzx.anshao.model.common.enums.QuestionOrAnswer;
import com.pingan.qhzx.anshao.model.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.model.common.utils.RedisProvider;
import com.pingan.qhzx.anshao.model.common.utils.RedisService;
import com.pingan.qhzx.anshao.model.common.utils.WebUtils;
import com.pingan.qhzx.anshao.model.common.utils.WekaModel;
import com.pingan.qhzx.anshao.model.service.IChatService;
import com.pingan.qhzx.anshao.model.web.bean.QuestionAndAnswer;

import weka.classifiers.Classifier;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.StringToWordVector;

@Controller
@RequestMapping("/chatInRedis")
public class ChatInRedisController extends BaseController {

	private static final Logger log = LoggerFactory.getLogger(ChatInRedisController.class);
	
	@Autowired
	private WekaModel wekaModel;
	
	@Autowired
	private IChatService chatService;
	
	@Value("${knowledge.csv.name}")
	private String knowledgeCSVName;

	@Value("${stopword.csv.name}")
	private String stopwordCSVName;

	@Value("${arff.name}")
	private String modelArffName;
	
	@Value("${arff.name2}")
	private String modelArffName2;
	
	@Value("${train.arff.name}")
	private String trainArffName;
	
	@Value("${transformer.model.name}")
	private String modelTrainarffName;

	@Value("${classifier.model.name}")
	private String modelClassifierDir;
	
	@Value("${test.is.debug}")
	private String isdebug;
	
	@Autowired
	private RedisService redisService;
	
	//--创建redis对象
	private RedisProvider isChangeModelProvider ;
	private RedisProvider oldModelProvider ;
	private RedisProvider answerQuestionProvider ;
	private RedisProvider answerProbProvider ;
	private RedisProvider questionKWanswerListProvider ;
	
	
	@ResponseBody
	@ESA("ansirqa.chatInRedis.resetRedisByQuestion")
	@RequestMapping("/resetRedisByQuestion")
	public JSONObject setRedisByQuestion (@ModelAttribute @Valid QuestionBean questionBean, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String orgId = questionBean.getOrgId();
		try{
			wekaModel.resetQuestionAndAnswerPutInRedis(orgId);
			return WebUtils.createSuccResult();
		} catch (Exception e) {
			throw new Exception(e);
		}
	}
	
	@ResponseBody
	@ESA("ansirqa.chatInRedis.answer")
	@RequestMapping("/answer")
	public JSONObject answer(@ModelAttribute @Valid QuestionBean questionBean, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		try {
			HanLP.Config.enableDebug();
			List<String> keywordList = wekaModel.getKeyWords(questionBean.getOrgId());
			definedKeywords(keywordList);
			List<String> segList = new ArrayList<String>();
			StringBuffer sb = new StringBuffer();
			List<Term> termList = HanLP.segment(questionBean.getUserQuestion());
			for(Term term:termList) {
				if(!isExistStopWord(term.word, questionBean.getOrgId())) {
					sb.append(term.word+" ");
					segList.add(term.word);
				}
			}
			log.info("用户输入问题分词结果:[{}]", sb.toString());
			Instances newTrain = getNewTrains(sb.toString(), questionBean.getOrgId());
			double[] classifierValue = clasifierValue(newTrain, questionBean.getOrgId());
			
			if("true".equals(isdebug)) {
				HandleChatBean result = getQuestionOrAnswer(classifierValue, questionBean.getUserQuestion() ,questionBean.getThreshold(), segList, newTrain, questionBean.getOrgId(), questionBean.getFuzzyMatch());
				DebugBean debugbean = debugContent(classifierValue, questionBean.getUserQuestion() ,questionBean.getThreshold(), segList, newTrain, questionBean.getOrgId(), questionBean.getFuzzyMatch());
				debugbean.setQuestionHanlpResult(sb.toString());
				debugbean.setFlag(result.getFlag());
				JSONObject jsonObject = new JSONObject();
				String debugbeanStr = jsonObject.toJSONString(debugbean);
				handleUnknowQuestion(result.getFlag(), questionBean);
				return WebUtils.createSuccResult(result.getQuestionAnswerResultBeanSet(), result.getIsMatchKnowledge(), result.getQuestionOrAnswer(), debugbeanStr);
			} else {
				HandleChatBean result = getQuestionOrAnswer(classifierValue, questionBean.getUserQuestion() ,questionBean.getThreshold(), segList, newTrain, questionBean.getOrgId(), questionBean.getFuzzyMatch());
				handleUnknowQuestion(result.getFlag(), questionBean);
				return WebUtils.createSuccResult(result.getQuestionAnswerResultBeanSet(), result.getIsMatchKnowledge(), result.getQuestionOrAnswer());
			}
			
		} catch (IOException e) {
			log.error("IO", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE, e.getMessage());
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult();
		}

	}
	
	//将关键字自定义分词,每个关键字都是一个词,eg:你好吗,就是一个词
		protected void definedKeywords(List<String> keywordlist) {
			HanLP.newSegment().enableCustomDictionary(true);
			if(keywordlist!=null && keywordlist.size()>0) {
				for(String keyword : keywordlist) {
					CustomDictionary.add(keyword);
				}
				
			}
		}
		
		//得到filter的结果集
		private Instances getNewTrains(String questionStr, String orgId) throws Exception {
			ObjectInputStream ois = null;
			Instances ins = WekaModel.newInstances(questionStr);
			String transformerModelName = MessageFormat.format(modelTrainarffName, orgId);
			InputStream is = null;
			try {
				is = new FileInputStream(wekaModel.getPath(transformerModelName, orgId));
				ois = new ObjectInputStream(is);
				StringToWordVector filter = (StringToWordVector)ois.readObject();  //反序列化构成对象
				Instances newtrain = Filter.useFilter(ins, filter);
				newtrain.setClassIndex(0);
				log.info("newtrain:::"+newtrain);
				return newtrain;
			} catch (FileNotFoundException e) {
				throw new IOException(e);
			} catch (IOException e) {
				throw new IOException(e);
			} catch (Exception e) {
				throw new Exception(e);
			} finally {
				if(ois!=null) {
					try {
						ois.close();
						ois = null;
					} catch(IOException e) {
						e.printStackTrace();
					}
				}
				if(is != null){
					try{
						is.close();
					}catch(Exception e){
						log.error("{}",e);
					}
				}
			}
			
		}
		
		//判断分词是否是stopword
		protected boolean isExistStopWord(String word, String orgId) throws Exception {
			List<String> stopwordList = wekaModel.readStopWordCsv(orgId);
			return stopwordList.contains(word);
		}
		
		//获取用户输出问题返回的贝叶斯概率列表,列表值和label一一对应
		private double[] clasifierValue(Instances newtrain, String orgId) throws Exception {
			ObjectInputStream oisClassifier = null;
			List<Double> classifierresult = new ArrayList<Double>();
//			String classifierModelName = orgId+"_classifier.model";
			String classifierModelName = MessageFormat.format(modelClassifierDir, orgId);
			InputStream is = null;
			try {
				is = new FileInputStream(wekaModel.getPath(classifierModelName, orgId));
				oisClassifier = new ObjectInputStream(is);
//		        int length = ins.numInstances();
				Classifier cls = (Classifier)oisClassifier.readObject();
				double d = cls.classifyInstance(newtrain.instance(0));
				double[] darray = cls.distributionForInstance(newtrain.instance(0));
				if(darray!=null && darray.length>0) {
					for(int i=0;i<darray.length;i++) {
						classifierresult.add(darray[i]);
					}
				}
				log.info("贝叶斯概率列表result:::"+classifierresult);
				return darray;
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				throw new IOException(e);
			} catch (IOException e) {
				e.printStackTrace();
				throw new IOException(e);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception(e);
			} finally {
				if(oisClassifier!=null) {
					try {
						oisClassifier.close();
						oisClassifier = null;
					} catch(IOException e) {
						e.printStackTrace();
					}
				}
				if(is != null){
					try{
						is.close();
					}catch(Exception e){
						log.error("{}",e);
					}
				}
			}
			
		}
		
		private DebugBean debugContent(double[] darray,String userQuestion, double threshold, List<String> segList, Instances newTrain, String orgId, String fuzzyMatch) throws Exception {
			double threshold1 = threshold;// 无关键词阀值概率
			List<QuestionAndAnswer> csvList = wekaModel.readCsv(orgId);
			Map<String, String> answerQuestion = new HashMap<String, String>();
			ArrayList<String> Answer = new ArrayList<String>();
			Map<String, String> KWanswerList = new HashMap<String, String>();

			Set<String> questionKWanswer = new HashSet<String>();
			Map<String, Double> answerProb = new HashMap<String, Double>();
			ArrayList<String> thresholdAnswer = new ArrayList<String>();
			for (QuestionAndAnswer qa : csvList) {
				if (answerQuestion.containsKey(qa.getAnswer())) {
					if (answerQuestion.get(qa.getAnswer()).length() < qa.getQuestion().length())
						answerQuestion.replace(qa.getAnswer(), qa.getQuestion());
				} else {
					answerQuestion.put(qa.getAnswer(), qa.getQuestion());
				}
				if (!Answer.contains(qa.getAnswer()))
					Answer.add(qa.getAnswer());

				List<String> KWperAnswer = Arrays.asList(qa.getKeywords().split("，"));
				for (String KW : KWperAnswer) {
					if (KWanswerList.containsKey(KW)) {
						KWanswerList.replace(KW, KWanswerList.get(KW) + ",,," + qa.getAnswer());
					} else {
						KWanswerList.put(KW, qa.getAnswer());
					}
				}
			}

			for (String word : segList) {
				if (KWanswerList.containsKey(word)) {
					String kwanswer[] = KWanswerList.get(word).split(",,,");
					for (int i = 0; i < kwanswer.length; i++)
						questionKWanswer.add(kwanswer[i]);
				}

			}

			List<String> questionKWanswerList = new ArrayList<String>(questionKWanswer);
			for (int i = 0; i < Answer.size(); i++) {
				answerProb.put(Answer.get(i).toString(), darray[i]);
			}
			// 排序
			List<Map.Entry<String, Double>> answerProbOrder = new ArrayList<Map.Entry<String, Double>>(
					answerProb.entrySet());
			Collections.sort(answerProbOrder, new Comparator<Map.Entry<String, Double>>() {
				public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
					return (o2.getValue().compareTo(o1.getValue()));
				}
			});
			DebugBean debugBean = new DebugBean();
			List<Map.Entry<String, Double>> answerProbOrderTen = new ArrayList<Map.Entry<String, Double>>();
			if(answerProbOrder!=null && answerProbOrder.size()>0) {
				if(answerProbOrder.size()<=10) {
					debugBean.setAnswerThresholdList(answerProbOrder);
				} else {
					for(int i=0;i<10;i++) {
						answerProbOrderTen.add(answerProbOrder.get(i));
					}
					debugBean.setAnswerThresholdList(answerProbOrderTen);
				}
			}
			
			debugBean.setKeywordAnswerList(questionKWanswerList);
			return debugBean;
		}
		
		private void handleUnknowQuestion(String flag, QuestionBean questionBean) {
			if("1".equals(flag) || "2".equals(flag)) {
				List<UnknowQuestionBean> unknowQuestionBeanList = new ArrayList<UnknowQuestionBean>();
				UnknowQuestionBean unknowQuestionBean = new UnknowQuestionBean();
				unknowQuestionBean.setAccountId(questionBean.getAccountId());
				unknowQuestionBean.setOrgId(questionBean.getOrgId());
				unknowQuestionBean.setQuestionContent(questionBean.getUserQuestion());
				unknowQuestionBean.setQuestionSource("ansirQa");
				unknowQuestionBean.setQuestionDate(new Date());
				unknowQuestionBeanList.add(unknowQuestionBean);
				chatService.insertUnknowQuestion(unknowQuestionBeanList);
			}
		}
		
		private HandleChatBean getQuestionOrAnswer(double[] darray,String userQuestion, double threshold, List<String> segList, Instances newTrain, String orgId, String fuzzyMatch) throws Exception {
			double threshold1 = threshold;// 无关键词阀值概率
			List<QuestionAndAnswer> csvList = wekaModel.readCsvNew(orgId);
			Map<String, String> answerQuestion = new HashMap<String, String>();
			
			Map<String, Double> answerProb = new HashMap<String, Double>();
			ArrayList<String> thresholdAnswer = new ArrayList<String>();
			Set<String> questionKWanswer = new HashSet<String>();
			ArrayList<String> Answer = new ArrayList<String>();
			List<String> questionKWanswerList = null;
			List<Map.Entry<String, Double>> answerProbOrder = null;
			Integer isChangeModelNum = 0;
			Integer oldModelNum = 0;
			
			//--从redis中获取数据，如果为空，则往radis中设置数据
			if(isChangeModelProvider !=null){
				if(isChangeModelProvider.get(orgId) != null){
					isChangeModelNum = (Integer)isChangeModelProvider.get(orgId);
				}
				
				if(oldModelProvider.get(orgId) !=null){
					oldModelNum = (Integer)oldModelProvider.get(orgId);
				}
			}
			if(answerQuestionProvider!=null && answerProbProvider !=null && questionKWanswerListProvider !=null){
				answerQuestion = (Map<String, String>)answerQuestionProvider.get(orgId);
				answerProb = (Map<String, Double>)answerProbProvider.get(orgId);
				questionKWanswerList = (List<String>)questionKWanswerListProvider.get(orgId);
				
				if((answerQuestion == null) || (answerProb == null) || (questionKWanswerList == null) || isChangeModelNum != oldModelNum){
					answerQuestion = new HashMap<String, String>();
					answerProb = new HashMap<String, Double>();
					
					this.setBycsvList(csvList, answerQuestion, segList, answerProb, questionKWanswer, Answer, darray);
					
					questionKWanswerList = new ArrayList<String>(questionKWanswer);
					for (int i = 0; i < Answer.size(); i++) {
						answerProb.put(Answer.get(i).toString(), darray[i]);
					}
					//--移除redis内容
					answerQuestionProvider.remove(orgId);
					answerProbProvider.remove(orgId);
					questionKWanswerListProvider.remove(orgId);
					
					//--存入redis内容
					answerQuestionProvider.add(orgId, answerQuestion);
					answerProbProvider.add(orgId, answerProb);
					questionKWanswerListProvider.add(orgId, questionKWanswerList);
					
					
				}
			}else{
				log.error("获取redis信息异常！");
				this.setBycsvList(csvList, answerQuestion, segList, answerProb, questionKWanswer, Answer, darray);
				questionKWanswerList = new ArrayList<String>(questionKWanswer);
				for (int i = 0; i < Answer.size(); i++) {
					answerProb.put(Answer.get(i).toString(), darray[i]);
				}
			}
			
			answerProbOrder = new ArrayList<Map.Entry<String, Double>>(answerProb.entrySet());
			Collections.sort(answerProbOrder, new Comparator<Map.Entry<String, Double>>() {
				public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
					return (o2.getValue().compareTo(o1.getValue()));
				}
			});
			
			HandleChatBean handleChatBean = handleQuestionKWanswer(questionKWanswerList, answerProbOrder, threshold1, thresholdAnswer, fuzzyMatch, userQuestion, answerQuestion, answerProb);;
			
			
			
			return handleChatBean;
		}
		
		/**
		 *  对问题和答案进行整理
		 * @param csvList
		 * @param answerQuestion
		 */
		private void setBycsvList(List<QuestionAndAnswer> csvList,Map<String, String> answerQuestion,List<String> segList,
				                  Map<String, Double> answerProb,Set<String> questionKWanswer,
				                  ArrayList<String> Answer,double[] darray){
			Map<String, String> KWanswerList = new HashMap<String, String>();
			
			
			for (QuestionAndAnswer qa : csvList) {
				if (answerQuestion.containsKey(qa.getAnswer())) {
					if (answerQuestion.get(qa.getAnswer()).length() < qa.getQuestion().length())
						answerQuestion.replace(qa.getAnswer(), qa.getQuestion());
				} else {
					answerQuestion.put(qa.getAnswer(), qa.getQuestion());
				}
				if (!Answer.contains(qa.getAnswer()))
					Answer.add(qa.getAnswer());

				List<String> KWperAnswer = Arrays.asList(qa.getKeywords().split("，"));
				for (String KW : KWperAnswer) {
					if (KWanswerList.containsKey(KW)) {
						KWanswerList.replace(KW, KWanswerList.get(KW) + ",,," + qa.getAnswer());
					} else {
						KWanswerList.put(KW, qa.getAnswer());
					}
				}
			}

			for (String word : segList) {
				if (KWanswerList.containsKey(word)) {
					String kwanswer[] = KWanswerList.get(word).split(",,,");
					for (int i = 0; i < kwanswer.length; i++)
						questionKWanswer.add(kwanswer[i]);
				}

			}
			
		}
		
		private HandleChatBean handleQuestionKWanswer(List<String> questionKWanswerList, List<Map.Entry<String, Double>> answerProbOrder, double threshold1, ArrayList<String> thresholdAnswer, String fuzzyMatch,String userQuestion, Map<String, String> answerQuestion, Map<String, Double> answerProb) throws Exception {
			int threshold2 = 3;// 抛出问题的最大个数
			double threshold3 = 0.9;// 有关键词，只有一个标签类别的阀值概率
			double threshold4 = 0.95;// 有关键词，多个标签类别的直接抛出答案的阀值概率
			Set<QuestionAnswerResultBean> questionAnswerResultBeanList = new HashSet<QuestionAnswerResultBean>();
			HandleChatBean handleChatBean = new HandleChatBean();
			Set<String> questionList = new HashSet<String>();
			String flag = "";
			
			if (questionKWanswerList.size() == 0) {
				for (int i = 0; i < answerProbOrder.size(); i++) {
					if (answerProbOrder.get(i).getValue() >= threshold1) // 大于无关键词阀值
						thresholdAnswer.add(answerProbOrder.get(i).getKey());
					else
						break;
				}
				if (thresholdAnswer.size() == 0) {
					if("1".equals(fuzzyMatch)) {
						//调用图灵接口
						log.info("开始调用图灵接口返回问题答案");
						QuestionAnswerResultBean qar = new QuestionAnswerResultBean(userQuestion, "待定...,还未调用图灵接口");
						questionAnswerResultBeanList.add(qar);
						handleChatBean.setIsMatchKnowledge(MatchKnowledge.NO.getValue());
						handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.ANSWER.getValue());
						flag = "1";
					} else if("0".equals(fuzzyMatch)) {
						flag = "2";
						//返回空
//						handleChatBean.setIsMatchKnowledge(MatchKnowledge.NO.getValue());
					} else {
						throw new Exception("未知的fuzzyMatch");
					}
					
				} else if (thresholdAnswer.size() == 1) {
					QuestionAnswerResultBean qar = new QuestionAnswerResultBean(userQuestion, thresholdAnswer.get(0), answerProbOrder.get(0).getValue());
					questionAnswerResultBeanList.add(qar);
					handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
					handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.ANSWER.getValue());
					flag = "3";
				} else if (thresholdAnswer.size() > 1) {
					for (int i = 0; i < (thresholdAnswer.size() > threshold2 ? threshold2 : thresholdAnswer.size()); i++) {
						questionList.add(thresholdAnswer.get(i));
					}
					List<String> answerList = new ArrayList<String>(questionList);
					for(int i = 0;i<answerList.size();i++) {
						QuestionAnswerResultBean qar = new QuestionAnswerResultBean(answerQuestion.get(answerList.get(i)), answerList.get(i), answerProb.get(answerList.get(i)));
						questionAnswerResultBeanList.add(qar);
					}
					handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
					handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.QUESTION.getValue());
					flag = "4";
				}

			} else if (questionKWanswerList.size() == 1) {
				if (answerProb.get(questionKWanswerList.get(0)) >= threshold3) {
					QuestionAnswerResultBean qar = new QuestionAnswerResultBean(userQuestion, questionKWanswerList.get(0), answerProb.get(questionKWanswerList.get(0)));
					questionAnswerResultBeanList.add(qar);
					handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
					handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.ANSWER.getValue());
					flag = "5";
				} else {
					QuestionAnswerResultBean qar = new QuestionAnswerResultBean(answerQuestion.get(questionKWanswerList.get(0)), questionKWanswerList.get(0), answerProb.get(questionKWanswerList.get(0)));
					questionAnswerResultBeanList.add(qar);
					handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
					handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.QUESTION.getValue());
					flag = "6";
				}
					
			} else if (questionKWanswerList.size() > 1) {
				if (answerProbOrder.get(0).getValue() >= threshold4) {
					QuestionAnswerResultBean qar = new QuestionAnswerResultBean(userQuestion, answerProbOrder.get(0).getKey(), answerProbOrder.get(0).getValue());
					questionAnswerResultBeanList.add(qar);
					handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
					handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.ANSWER.getValue());
					flag = "7";
				} else {
					for (int i = 0; i < answerProbOrder.size(); i++) {
						int j = 0;
						if (questionKWanswerList.contains(answerProbOrder.get(i).getKey())) {
							questionList.add(answerQuestion.get(answerProbOrder.get(i).getKey()));
							j++;
							QuestionAnswerResultBean qar = new QuestionAnswerResultBean(answerQuestion.get(answerProbOrder.get(i).getKey()), answerProbOrder.get(i).getKey(), answerProbOrder.get(i).getValue());
							questionAnswerResultBeanList.add(qar);
						}
						if (j > threshold2)
							break;
					}
					handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
					handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.QUESTION.getValue());
					flag = "8";
				}
			}
			handleChatBean.setQuestionAnswerResultBeanSet(questionAnswerResultBeanList);
			handleChatBean.setFlag(flag);
			return handleChatBean;
		}

		@PostConstruct
		public void afterPropertiesSet() throws Exception {
			this. isChangeModelProvider = redisService.getIsChangeModelRedis();
			this. oldModelProvider = redisService.getOldModelNumRedis();
			this. answerQuestionProvider = redisService.getAnswerQuestionMapRedis();
			this. answerProbProvider = redisService.getAnswerProbMapRedis();
			this. questionKWanswerListProvider = redisService.getQuestionKWanswerListRedis();
			
		}
	
	
}
