package com.pingan.qhzx.anshao.model.common.bean;

import java.util.List;

public class ChatAnswerData {
	
	private List<QuestionAnswerResultBean> questionAnswerResultBeanList;

	public List<QuestionAnswerResultBean> getQuestionAnswerResultBeanList() {
		return questionAnswerResultBeanList;
	}

	public void setQuestionAnswerResultBeanList(List<QuestionAnswerResultBean> questionAnswerResultBeanList) {
		this.questionAnswerResultBeanList = questionAnswerResultBeanList;
	}
	
	
}
