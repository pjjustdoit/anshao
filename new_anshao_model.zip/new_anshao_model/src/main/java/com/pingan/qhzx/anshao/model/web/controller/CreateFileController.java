package com.pingan.qhzx.anshao.model.web.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.common.Term;
import com.paic.pafa.validator.annotation.Valid;
import com.pingan.pafa.papp.ESA;
import com.pingan.qhzx.anshao.model.common.bean.CreateModelBean;
import com.pingan.qhzx.anshao.model.common.bean.HandleChatBean;
import com.pingan.qhzx.anshao.model.common.bean.QuestionBean;
import com.pingan.qhzx.anshao.model.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.model.common.utils.WebUtils;
import com.pingan.qhzx.anshao.model.common.utils.WekaModel;

import weka.core.Instances;

@RequestMapping("/createfile")
@Controller
public class CreateFileController {
	
	private static final Logger log = LoggerFactory.getLogger(ModelController.class);
	
	@Autowired
	private WekaModel wekaModel;
	
	@ResponseBody
	@RequestMapping("/csv")
	public JSONObject createcsv(CreateModelBean createModelBean,HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		StringBuffer sb = new StringBuffer();
		List<String> orgIdList = createModelBean.getOrgId();
		try {
			if(orgIdList!=null && orgIdList.size()>0) {
				for(int i=0;i<orgIdList.size();i++) {
					String orgId = orgIdList.get(i);
					List<String> keywordList = wekaModel.getKeyWords(orgId);
					List<String> requestList = wekaModel.getQuestions(orgId);
					List<String> answerList = wekaModel.getAnswers(orgId);
					for(int j=0;j<requestList.size();j++) {
						sb.append(answerList.get(j));
						sb.append(",");
						sb.append(keywordList.get(j));
						sb.append(",");
						sb.append(requestList.get(j));
						sb.append("\n");
					}
					
					log.info("分词结果字符串:"+sb.toString());
					
					readStringToCSV(sb.toString(), orgIdList.get(i));
					
				}
				return WebUtils.createSuccResult();
			} else {
				return WebUtils.createErrorResult(ResponseEnum.FAILURE, "orgId is null");
			}
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult();
		}
	
	}
	
	public void readStringToCSV(String str, String orgId) {
		File file = new File("/Users/peijian280/Documents/model/weka/new.csv");
		FileOutputStream out = null;
		OutputStreamWriter osw = null;
		BufferedWriter bw = null;
		try {
			out = new FileOutputStream(file);
			osw = new OutputStreamWriter(out);
			bw = new BufferedWriter(osw);
			bw.write("Answer,keywords,Question" + "\r" + str);
		} catch (Exception e) {
		} finally {
			if (bw != null) {
				try {
					bw.close();
					bw = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (osw != null) {
				try {
					osw.close();
					osw = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (out != null) {
				try {
					out.close();
					out = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
