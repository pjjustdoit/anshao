package com.pingan.qhzx.anshao.model.common.bean;

import java.util.List;
import java.util.Map;

public class DebugBean {
	
	private String questionHanlpResult;
	
	private List<String> keywordAnswerList;
	
	private List<Map.Entry<String, Double>> answerThresholdList;
	
	private String flag;

	public String getQuestionHanlpResult() {
		return questionHanlpResult;
	}

	public void setQuestionHanlpResult(String questionHanlpResult) {
		this.questionHanlpResult = questionHanlpResult;
	}

	public List<String> getKeywordAnswerList() {
		return keywordAnswerList;
	}

	public void setKeywordAnswerList(List<String> keywordAnswerList) {
		this.keywordAnswerList = keywordAnswerList;
	}

	public List<Map.Entry<String, Double>> getAnswerThresholdList() {
		return answerThresholdList;
	}

	public void setAnswerThresholdList(List<Map.Entry<String, Double>> answerThresholdList) {
		this.answerThresholdList = answerThresholdList;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}
	
	
	
}
