package com.pingan.qhzx.anshao.model.common.bean;

import java.io.Serializable;
import java.util.Date;

public class QuestionBean  extends BaseBean {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1284132461264732350L;
	
	private String userQuestion;    //用户问题
	private String accountId;       //客户id
	private String questionId;      //问题id
	private String questionFlag;    //问题标签
	private String questionFlagId;  //问题标签id
	private String orgId;           //机构id
	private Date questionDate;      //提问时间
	private Double threshold;       //阀值
	private String fuzzyMatch;     //是否模糊匹配，1:是， 0:否
	
	
	public String getUserQuestion() {
		return userQuestion;
	}
	public void setUserQuestion(String userQuestion) {
		this.userQuestion = userQuestion;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public String getQuestionFlag() {
		return questionFlag;
	}
	public void setQuestionFlag(String questionFlag) {
		this.questionFlag = questionFlag;
	}
	public String getQuestionFlagId() {
		return questionFlagId;
	}
	public void setQuestionFlagId(String questionFlagId) {
		this.questionFlagId = questionFlagId;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public Date getQuestionDate() {
		return questionDate;
	}
	public void setQuestionDate(Date questionDate) {
		this.questionDate = questionDate;
	}
	public Double getThreshold() {
		return threshold;
	}
	public void setThreshold(Double threshold) {
		this.threshold = threshold;
	}
	public String getFuzzyMatch() {
		return fuzzyMatch;
	}
	public void setFuzzyMatch(String fuzzyMatch) {
		this.fuzzyMatch = fuzzyMatch;
	}
	
	
}
