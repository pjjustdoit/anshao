package com.pingan.qhzx.anshao.model.common.bean;

import java.util.List;

public class UnknowQuestionForm {
	
	private List<UnknowQuestionBean> unknowQuestionBeanList;

	public List<UnknowQuestionBean> getUnknowQuestionBeanList() {
		return unknowQuestionBeanList;
	}

	public void setUnknowQuestionBeanList(List<UnknowQuestionBean> unknowQuestionBeanList) {
		this.unknowQuestionBeanList = unknowQuestionBeanList;
	}
	
	
}
