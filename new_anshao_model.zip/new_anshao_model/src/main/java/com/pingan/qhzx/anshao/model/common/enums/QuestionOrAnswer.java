package com.pingan.qhzx.anshao.model.common.enums;

public enum QuestionOrAnswer {
	
	QUESTION("问题", "0"), ANSWER("答案", "1");
	
	private String describe;
	private String value;
	
	private  QuestionOrAnswer(String describe, String value) {
		this.describe = describe;
		this.value = value;
	}

	public String getDescribe() {
		return describe;
	}

	public void setDescribe(String describe) {
		this.describe = describe;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	
	
}
