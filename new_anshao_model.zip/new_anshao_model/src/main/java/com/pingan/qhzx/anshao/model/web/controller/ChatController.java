package com.pingan.qhzx.anshao.model.web.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.dictionary.CustomDictionary;
import com.hankcs.hanlp.seg.common.Term;
import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.qhzx.anshao.model.common.bean.DebugBean;
import com.pingan.qhzx.anshao.model.common.bean.HandleChatBean;
import com.pingan.qhzx.anshao.model.common.bean.ProxyInfo;
import com.pingan.qhzx.anshao.model.common.bean.QuestionAnswerResultBean;
import com.pingan.qhzx.anshao.model.common.bean.QuestionBean;
import com.pingan.qhzx.anshao.model.common.bean.UnknowQuestionBean;
import com.pingan.qhzx.anshao.model.common.bean.UnknowQuestionForm;
import com.pingan.qhzx.anshao.model.common.enums.MatchKnowledge;
import com.pingan.qhzx.anshao.model.common.enums.QuestionOrAnswer;
import com.pingan.qhzx.anshao.model.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.model.common.utils.HttpUtils;
import com.pingan.qhzx.anshao.model.common.utils.WebUtils;
import com.pingan.qhzx.anshao.model.common.utils.WekaModel;
import com.pingan.qhzx.anshao.model.service.IChatService;
import com.pingan.qhzx.anshao.model.web.bean.QuestionAndAnswer;

import weka.classifiers.Classifier;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.StringToWordVector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 用户输入问题以及系统返回结果
 * @author peijian280
 *
 */
@Controller
@RequestMapping("/chat")
public class ChatController extends BaseController {

	private static final Logger log = LoggerFactory.getLogger(ChatController.class);
	
	private static final String TULING_URL = "http://www.tuling123.com/openapi/api";     //图灵接口
	
	@Autowired
	private WekaModel wekaModel;
	
	@Autowired
	private IChatService chatService;
	
	@Value("${knowledge.csv.name}")
	private String knowledgeCSVName;

	@Value("${stopword.csv.name}")
	private String stopwordCSVName;

	@Value("${arff.name}")
	private String modelArffName;
	
	@Value("${arff.name2}")
	private String modelArffName2;
	
	@Value("${train.arff.name}")
	private String trainArffName;
	
	@Value("${transformer.model.name}")
	private String modelTrainarffName;

	@Value("${classifier.model.name}")
	private String modelClassifierDir;
	
	@Value("${test.is.debug}")
	private String isdebug;
	
	@Value("${ansirqa.proxy.hostname}")
	private String proxyHostName;
	
	@Value("${ansirqa.proxy.port}")
	private int proxyPort;
	
	@Value("${ansirqa.proxy.scheme}")
	private String proxyScheme;
	
	@Value("${tuling.api.key}")
	private String tulingApiKEY;
	
	/**
	 * 用户提出问题，返回问题或者答案
	 * @param userquestion
	 * @param orgid此处还有一个作用，用来做为文件名称，比如ogrid.csv
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException 
	 */
	@ResponseBody
	@ESA("ansirqa.chat.answer")
	@RequestMapping("/answer")
	public JSONObject answer(@ModelAttribute @Valid QuestionBean questionBean, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		log.info("测试－－－－－－－－－－－－－－－>threshold:"+questionBean.getThreshold()+",orgid:"+questionBean.getOrgId());
		try {
			if(!isExistsModelFile(questionBean.getOrgId())) {
				return WebUtils.createErrorResult(ResponseEnum.NOT_EXIST_MODEL_FILE, "机构id＝"+questionBean.getOrgId()+"对应的模型文件不存在");
			}
			HanLP.Config.enableDebug();
			List<String> keywordList = wekaModel.getKeyWords(questionBean.getOrgId());
			definedKeywords(keywordList);
			List<String> segList = new ArrayList<String>();
			StringBuffer sb = new StringBuffer();
			List<Term> termList = HanLP.segment(questionBean.getUserQuestion());
			for(Term term:termList) {
				if(!isExistStopWord(term.word, questionBean.getOrgId())) {
					sb.append(term.word+" ");
					segList.add(term.word);
				}
			}
			log.info("用户输入问题分词结果:[{}]", sb.toString());
			
			Instances newTrain = getNewTrains(sb.toString(), questionBean.getOrgId());
			double[] classifierValue = clasifierValue(newTrain, questionBean.getOrgId());
			
			if("true".equals(isdebug)) {
				HandleChatBean result = getQuestionOrAnswer(classifierValue, questionBean.getUserQuestion() ,questionBean.getThreshold(), segList, newTrain, questionBean.getOrgId(), questionBean.getFuzzyMatch(), questionBean.getAccountId());
				DebugBean debugbean = debugContent(classifierValue, questionBean.getUserQuestion() ,questionBean.getThreshold(), segList, newTrain, questionBean.getOrgId(), questionBean.getFuzzyMatch());
				debugbean.setQuestionHanlpResult(sb.toString());
				debugbean.setFlag(result.getFlag());
				JSONObject jsonObject = new JSONObject();
				String debugbeanStr = jsonObject.toJSONString(debugbean);
				handleUnknowQuestion(result.getFlag(), questionBean);
				return WebUtils.createSuccResult(JSONObject.toJSON(result.getQuestionAnswerResultBeanSet()), JSONObject.toJSON(result.getIsMatchKnowledge()), result.getQuestionOrAnswer(), debugbeanStr);

			} else {
				HandleChatBean result = getQuestionOrAnswer(classifierValue, questionBean.getUserQuestion() ,questionBean.getThreshold(), segList, newTrain, questionBean.getOrgId(), questionBean.getFuzzyMatch(), questionBean.getAccountId());
				handleUnknowQuestion(result.getFlag(), questionBean);
				return WebUtils.createSuccResult(JSONObject.toJSON(result.getQuestionAnswerResultBeanSet()), JSONObject.toJSON(result.getIsMatchKnowledge()), result.getQuestionOrAnswer());
			}
			
		} catch (IOException e) {
			log.error("IO", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE, e.getMessage());
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult();
		}

	}
	
	/**
	 * 未知问题入库
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@ResponseBody
	@ESA("ansirqa.chat.unknow.question")
	@RequestMapping("/unknow/question")
	public JSONObject unknowquestion(UnknowQuestionForm unknowQuestionForm, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		try {
			
			chatService.insertUnknowQuestion(unknowQuestionForm.getUnknowQuestionBeanList());
			return WebUtils.createSuccResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult();
		}

	}
	
	private void handleUnknowQuestion(String flag, QuestionBean questionBean) {
		if("1".equals(flag) || "2".equals(flag)) {
			List<UnknowQuestionBean> unknowQuestionBeanList = new ArrayList<UnknowQuestionBean>();
			UnknowQuestionBean unknowQuestionBean = new UnknowQuestionBean();
			unknowQuestionBean.setAccountId(questionBean.getAccountId());
			unknowQuestionBean.setOrgId(questionBean.getOrgId());
			unknowQuestionBean.setQuestionContent(questionBean.getUserQuestion());
			if("1".equals(flag)) {
				unknowQuestionBean.setQuestionSource("ansirQa_tuling");
			} else if("2".equals(flag)) {
				unknowQuestionBean.setQuestionSource("ansirQa_noneMatchknowledge");
			}
			unknowQuestionBean.setQuestionDate(new Date());
			unknowQuestionBeanList.add(unknowQuestionBean);
			chatService.insertUnknowQuestion(unknowQuestionBeanList);
		}
	}
	
	//将关键字自定义分词,每个关键字都是一个词,eg:你好吗,就是一个词
	protected void definedKeywords(List<String> keywordlist) {
		HanLP.newSegment().enableCustomDictionary(true);
		if(keywordlist!=null && keywordlist.size()>0) {
			for(String keyword : keywordlist) {
				String[] keywordArray = keyword.split("，");
				if(keywordArray.length>0) {
					for(int i=0;i<keywordArray.length;i++) {
						CustomDictionary.add(keywordArray[i]);
					}
				}
				
			}
			
		}

	}
	
	//得到filter的结果集
	private Instances getNewTrains(String questionStr, String orgId) throws Exception {
		ObjectInputStream ois = null;
		Instances ins = WekaModel.newInstances(questionStr);
//		String transformerModelName = orgId+"_transformer.model";
		String transformerModelName = MessageFormat.format(modelTrainarffName, orgId);
		try {
			ois = new ObjectInputStream(new FileInputStream(wekaModel.getPath(transformerModelName, orgId)));
			StringToWordVector filter = (StringToWordVector)ois.readObject();  //反序列化构成对象
			Instances newtrain = Filter.useFilter(ins, filter);
			newtrain.setClassIndex(0);
//			Attribute attri = newtrain.attribute(0);
//			String testValue = attri.value(0);
			log.info("newtrain:::"+newtrain);
			return newtrain;
		} catch (FileNotFoundException e) {
			throw new IOException(e);
		} catch (IOException e) {
			throw new IOException(e);
		} catch (Exception e) {
			throw new Exception(e);
		} finally {
			if(ois!=null) {
				try {
					ois.close();
					ois = null;
				} catch(IOException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	//获取用户输出问题返回的贝叶斯概率列表,列表值和label一一对应
	private double[] clasifierValue(Instances newtrain, String orgId) throws Exception {
		ObjectInputStream oisClassifier = null;
		List<Double> classifierresult = new ArrayList<Double>();
//		String classifierModelName = orgId+"_classifier.model";
		String classifierModelName = MessageFormat.format(modelClassifierDir, orgId);
		try {
			
			oisClassifier = new ObjectInputStream(new FileInputStream(wekaModel.getPath(classifierModelName, orgId)));
//	        int length = ins.numInstances();
			Classifier cls = (Classifier)oisClassifier.readObject();
			double d = cls.classifyInstance(newtrain.instance(0));
			double[] darray = cls.distributionForInstance(newtrain.instance(0));
			if(darray!=null && darray.length>0) {
				for(int i=0;i<darray.length;i++) {
					classifierresult.add(darray[i]);
				}
			}
			log.info("贝叶斯概率列表result:::"+classifierresult);
			return darray;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new IOException(e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new IOException(e);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		} finally {
			if(oisClassifier!=null) {
				try {
					oisClassifier.close();
					oisClassifier = null;
				} catch(IOException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	private HandleChatBean getQuestionOrAnswer(double[] darray,String userQuestion, double threshold, List<String> segList, Instances newTrain, String orgId, String fuzzyMatch, String accountId) throws Exception {
		double threshold1 = threshold;// 无关键词阀值概率
//		List<QuestionAndAnswer> csvList = wekaModel.readCsv(orgId);
		List<QuestionAndAnswer> csvList = wekaModel.readCsvNew(orgId);
		Map<String, String> answerQuestion = new HashMap<String, String>();
		ArrayList<String> Answer = new ArrayList<String>();
		Map<String, String> KWanswerList = new HashMap<String, String>();

		Set<String> questionKWanswer = new HashSet<String>();
		Map<String, Double> answerProb = new HashMap<String, Double>();
		ArrayList<String> thresholdAnswer = new ArrayList<String>();
		for (QuestionAndAnswer qa : csvList) {
			if (answerQuestion.containsKey(qa.getAnswer())) {
				if (answerQuestion.get(qa.getAnswer()).length() < qa.getQuestion().length())
					answerQuestion.replace(qa.getAnswer(), qa.getQuestion());
			} else {
				answerQuestion.put(qa.getAnswer(), qa.getQuestion());
			}
			if (!Answer.contains(qa.getAnswer()))
				Answer.add(qa.getAnswer());

			List<String> KWperAnswer = Arrays.asList(qa.getKeywords().split("，"));
			for (String KW : KWperAnswer) {
				if (KWanswerList.containsKey(KW)) {
					KWanswerList.replace(KW, KWanswerList.get(KW) + ",,," + qa.getAnswer());
				} else {
					KWanswerList.put(KW, qa.getAnswer());
				}
			}
		}

		for (String word : segList) {
			if (KWanswerList.containsKey(word)) {
				String kwanswer[] = KWanswerList.get(word).split(",,,");
				for (int i = 0; i < kwanswer.length; i++)
					questionKWanswer.add(kwanswer[i]);
			}

		}

		List<String> questionKWanswerList = new ArrayList<String>(questionKWanswer);
		for (int i = 0; i < Answer.size(); i++) {
			answerProb.put(Answer.get(i).toString(), darray[i]);
		}
		// 排序
		List<Map.Entry<String, Double>> answerProbOrder = new ArrayList<Map.Entry<String, Double>>(
				answerProb.entrySet());
		Collections.sort(answerProbOrder, new Comparator<Map.Entry<String, Double>>() {
			public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
				return (o2.getValue().compareTo(o1.getValue()));
			}
		});

		HandleChatBean handleChatBean = handleQuestionKWanswer(questionKWanswerList, answerProbOrder, threshold1, thresholdAnswer, fuzzyMatch, userQuestion, answerQuestion, answerProb, accountId);
		return handleChatBean;
	}
	
	
	private HandleChatBean handleQuestionKWanswer(List<String> questionKWanswerList, List<Map.Entry<String, Double>> answerProbOrder, double threshold1, ArrayList<String> thresholdAnswer, String fuzzyMatch,String userQuestion, Map<String, String> answerQuestion, Map<String, Double> answerProb, String accountId) throws Exception {
		int threshold2 = 5;// 抛出问题的最大个数
		double threshold3 = 0.9;// 有关键词，只有一个标签类别的阀值概率
		double threshold4 = 0.95;// 有关键词，多个标签类别的直接抛出答案的阀值概率
		Set<QuestionAnswerResultBean> questionAnswerResultBeanList = new HashSet<QuestionAnswerResultBean>();
		HandleChatBean handleChatBean = new HandleChatBean();
		Set<String> questionList = new HashSet<String>();
		String flag = "";
		if (questionKWanswerList.size() == 0) {
			for (int i = 0; i < answerProbOrder.size(); i++) {
				if (answerProbOrder.get(i).getValue() >= threshold1) // 大于无关键词阀值
					thresholdAnswer.add(answerProbOrder.get(i).getKey());
				else
					break;
			}
			if (thresholdAnswer.size() == 0) {
				if("1".equals(fuzzyMatch)) {
					//调用图灵接口
					log.info("开始调用图灵接口返回问题答案");
					String tulingAnswer = visitTuling(userQuestion, accountId);
					QuestionAnswerResultBean qar = new QuestionAnswerResultBean(userQuestion, tulingAnswer);
					questionAnswerResultBeanList.add(qar);
					handleChatBean.setIsMatchKnowledge(MatchKnowledge.NO.getValue());
					handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.ANSWER.getValue());
					flag = "1";
				} else if("0".equals(fuzzyMatch)) {
					flag = "2";
					//返回空
//					handleChatBean.setIsMatchKnowledge(MatchKnowledge.NO.getValue());
				} else {
					throw new Exception("未知的fuzzyMatch");
				}
				
			} else if (thresholdAnswer.size() == 1) {
				QuestionAnswerResultBean qar = new QuestionAnswerResultBean(userQuestion, thresholdAnswer.get(0), answerProbOrder.get(0).getValue());
				questionAnswerResultBeanList.add(qar);
				handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
				handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.ANSWER.getValue());
				flag = "3";
			} else if (thresholdAnswer.size() > 1) {
				for (int i = 0; i < (thresholdAnswer.size() > threshold2 ? threshold2 : thresholdAnswer.size()); i++) {
					questionList.add(thresholdAnswer.get(i));
				}
				List<String> answerList = new ArrayList<String>(questionList);
				for(int i = 0;i<answerList.size();i++) {
					QuestionAnswerResultBean qar = new QuestionAnswerResultBean(answerQuestion.get(answerList.get(i)), answerList.get(i), answerProb.get(answerList.get(i)));
					questionAnswerResultBeanList.add(qar);
				}
				handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
				handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.QUESTION.getValue());
				flag = "4";
			}

		} else if (questionKWanswerList.size() == 1) {
			if (answerProb.get(questionKWanswerList.get(0)) >= threshold3) {
				QuestionAnswerResultBean qar = new QuestionAnswerResultBean(userQuestion, questionKWanswerList.get(0), answerProb.get(questionKWanswerList.get(0)));
				questionAnswerResultBeanList.add(qar);
				handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
				handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.ANSWER.getValue());
				flag = "5";
			} else {
				QuestionAnswerResultBean qar = new QuestionAnswerResultBean(answerQuestion.get(questionKWanswerList.get(0)), questionKWanswerList.get(0), answerProb.get(questionKWanswerList.get(0)));
				questionAnswerResultBeanList.add(qar);
				handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
				handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.QUESTION.getValue());
				flag = "6";
			}
				
		} else if (questionKWanswerList.size() > 1) {
			if (answerProbOrder.get(0).getValue() >= threshold4) {
				QuestionAnswerResultBean qar = new QuestionAnswerResultBean(userQuestion, answerProbOrder.get(0).getKey(), answerProbOrder.get(0).getValue());
				questionAnswerResultBeanList.add(qar);
				handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
				handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.ANSWER.getValue());
				flag = "7";
			} else {
				int j = 1;
				for (int i = 0; i < answerProbOrder.size(); i++) {
					if (questionKWanswerList.contains(answerProbOrder.get(i).getKey())) {
						questionList.add(answerQuestion.get(answerProbOrder.get(i).getKey()));
						j++;
						QuestionAnswerResultBean qar = new QuestionAnswerResultBean(answerQuestion.get(answerProbOrder.get(i).getKey()), answerProbOrder.get(i).getKey(), answerProbOrder.get(i).getValue());
						questionAnswerResultBeanList.add(qar);
					}
					if (j > threshold2)
						break;
				}
				handleChatBean.setIsMatchKnowledge(MatchKnowledge.YES.getValue());
				handleChatBean.setQuestionOrAnswer(QuestionOrAnswer.QUESTION.getValue());
				flag = "8";
			}
		}
		handleChatBean.setQuestionAnswerResultBeanSet(questionAnswerResultBeanList);
		handleChatBean.setFlag(flag);
		return handleChatBean;
	}
	
	private DebugBean debugContent(double[] darray,String userQuestion, double threshold, List<String> segList, Instances newTrain, String orgId, String fuzzyMatch) throws Exception {
		double threshold1 = threshold;// 无关键词阀值概率
//		List<QuestionAndAnswer> csvList = wekaModel.readCsv(orgId);
		List<QuestionAndAnswer> csvList = wekaModel.readCsvNew(orgId);
		Map<String, String> answerQuestion = new HashMap<String, String>();
		ArrayList<String> Answer = new ArrayList<String>();
		Map<String, String> KWanswerList = new HashMap<String, String>();

		Set<String> questionKWanswer = new HashSet<String>();
		Map<String, Double> answerProb = new HashMap<String, Double>();
		ArrayList<String> thresholdAnswer = new ArrayList<String>();
		for (QuestionAndAnswer qa : csvList) {
			if (answerQuestion.containsKey(qa.getAnswer())) {
				if (answerQuestion.get(qa.getAnswer()).length() < qa.getQuestion().length())
					answerQuestion.replace(qa.getAnswer(), qa.getQuestion());
			} else {
				answerQuestion.put(qa.getAnswer(), qa.getQuestion());
			}
			if (!Answer.contains(qa.getAnswer()))
				Answer.add(qa.getAnswer());

			List<String> KWperAnswer = Arrays.asList(qa.getKeywords().split("，"));
			for (String KW : KWperAnswer) {
				if (KWanswerList.containsKey(KW)) {
					KWanswerList.replace(KW, KWanswerList.get(KW) + ",,," + qa.getAnswer());
				} else {
					KWanswerList.put(KW, qa.getAnswer());
				}
			}
		}

		for (String word : segList) {
			if (KWanswerList.containsKey(word)) {
				String kwanswer[] = KWanswerList.get(word).split(",,,");
				for (int i = 0; i < kwanswer.length; i++)
					questionKWanswer.add(kwanswer[i]);
			}

		}

		List<String> questionKWanswerList = new ArrayList<String>(questionKWanswer);
		for (int i = 0; i < Answer.size(); i++) {
			answerProb.put(Answer.get(i).toString(), darray[i]);
		}
		// 排序
		List<Map.Entry<String, Double>> answerProbOrder = new ArrayList<Map.Entry<String, Double>>(
				answerProb.entrySet());
		Collections.sort(answerProbOrder, new Comparator<Map.Entry<String, Double>>() {
			public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
				return (o2.getValue().compareTo(o1.getValue()));
			}
		});
		DebugBean debugBean = new DebugBean();
		List<Map.Entry<String, Double>> answerProbOrderTen = new ArrayList<Map.Entry<String, Double>>();
		if(answerProbOrder!=null && answerProbOrder.size()>0) {
			if(answerProbOrder.size()<=10) {
				debugBean.setAnswerThresholdList(answerProbOrder);
			} else {
				for(int i=0;i<10;i++) {
					answerProbOrderTen.add(answerProbOrder.get(i));
				}
				debugBean.setAnswerThresholdList(answerProbOrderTen);
			}
		}
		
		debugBean.setKeywordAnswerList(questionKWanswerList);
		return debugBean;
	}
	
	//用户提出的问题的分词是否有匹配到关键字
	protected List<String> questionMatchKeywords(List<String> segList, String orgId) throws IOException,Exception {
			List<String> matchKeyWordList = new ArrayList<String>();  //匹配到到关键词
			List<String> keywordList = wekaModel.getKeyWords(orgId);
			if(keywordList!=null && keywordList.size()>0) {
				if(segList!=null && segList.size()>0) {
					for(String word : segList) {
//						keywordList.contains(word);
						for(String keyword : keywordList) {
							if(word.equals(keyword)) {
								matchKeyWordList.add(keyword);
							}
						}
					}
				}
			}
			return matchKeyWordList;
	}
	
	//判断分词是否是stopword
	protected boolean isExistStopWord(String word, String orgId) throws Exception {
		List<String> stopwordList = wekaModel.readStopWordCsv(orgId);
		return stopwordList.contains(word);
	}
	
	private String visitTuling(String userQuestion, String accountId) {
		Map<String, String> params = Maps.newHashMap();
		params.put("key", tulingApiKEY);
		params.put("info", userQuestion);
		params.put("userid", accountId);
		ProxyInfo proxyInfo = new ProxyInfo();
		proxyInfo.setHostname(proxyHostName);
		proxyInfo.setPort(proxyPort);
		proxyInfo.setScheme(proxyScheme);
		log.info("访问图灵接口："+TULING_URL+",key="+tulingApiKEY+",info:"+userQuestion+",userid:"+accountId);
		String result = HttpUtils.post(TULING_URL, params, proxyInfo);
		JSONObject json = JSONObject.parseObject(result);
		String answer = json.getString("text");
		String code = json.getString("code");
		log.info("访问图灵接口返回值："+result);
		return answer;
	}
	
	private boolean isExistsModelFile(String orgId) {
		String trainsformerModelName = MessageFormat.format(modelTrainarffName, orgId);
		String trainsFormerModelNamefilepath = wekaModel.getPath(trainsformerModelName, orgId);
		String classifierModelName = MessageFormat.format(modelClassifierDir, orgId);
		String classifierModelNamefilepath = wekaModel.getPath(classifierModelName, orgId);
		boolean trainsbo = isExistsFile(trainsFormerModelNamefilepath);
		boolean classifierbo = isExistsFile(classifierModelNamefilepath);
		if(trainsbo && classifierbo) {
			return true;
		} else {
			return false;
		}
	}
	 
	private boolean isExistsFile(String sPath) { 
		boolean isExists = false;
	    File file = new File(sPath);  
	    if (file.isFile() && file.exists()) {  
	    	isExists = true;
	    }  
	    return isExists;
	}  
	
	public static void main(String[] args) {
//		try {
//			HanLP.Config.enableDebug();
//			List<String> keywordList = wekaModel.getKeyWords();
//			definedKeywords(keywordList);
//			List<String> segList = new ArrayList<String>();
//			StringBuffer sb = new StringBuffer();
//			List<Term> termList = HanLP.segment(questionBean.getUserQuestion());
//			for(Term term:termList) {
//				if(!isExistStopWord(term.word)) {
//					sb.append(term.word+" ");
//					segList.add(term.word);
//				}
//			}
//			log.info("用户输入问题分词结果:" + sb.toString());
//			Instances newTrain = getNewTrains(sb.toString());
//			double[] classifierValue = clasifierValue(newTrain);
//			Map<String, Object> result = getQuestionOrAnswer(classifierValue, questionBean.getThreshold(), segList, newTrain);
//
//			return WebUtils.createSuccResult(result);
//		} catch (Exception e) {
//			log.error("", e);
//			return WebUtils.createErrorResult();
//		}
//		Map<String, String> params = Maps.newHashMap();
//		params.put("key", "7e4c928fc6be41cb9452f1229e3a0045");
//		params.put("info", "今天上海天气如何");
//		params.put("userid", "123");
//		ProxyInfo proxyInfo = new ProxyInfo();
//		proxyInfo.setHostname("qhcs-proxy-stg-paic.com.cn");
//		proxyInfo.setPort(80);
//		proxyInfo.setScheme("http");
//		String result = HttpUtils.post(TULING_URL, params, null);
//		JSONObject json = JSONObject.parseObject(result);
//		String v = json.getString("text");
//		String code = json.getString("code");
		String regex = "\"\\w*?\"";//正则表达式匹配串
        String str,str2;
//        String strOri = "haha\"123\"hehe\"4567\"hihi";//待处理字符串
//        String strOri2 = "\"\"保单贷\"\"就是以寿险保单的现";
        String strOri2 = "\"我\"是\"中国人\"";
//        String strOri2 = "\"我们目前已推出的贷款产品有保单贷。其他产品正在陆续上线，欲了解更多的产品信息请致电95511。或输入\"保单贷介绍\"了解更多保单贷详情。\"";
//        System.out.println(strOri2.replaceAll("\"\"", "\""));
        strOri2 = strOri2.replaceAll("\"\"", "\"");
        String orginal= "\"haha\"123\"hehe\"4567\"hihi\"";
        String replaced = strOri2.replaceAll("\"(.*?)\"", "“$1”");
        System.out.println(replaced);
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(strOri2);
        while(matcher.find())
        {
            str = matcher.group();
            str2 = str;
            str2 = str2.replaceAll("\"", "");//去掉前后引号
            str2 = "“"+str2+"”"; //前后添上中文引号
            strOri2 = strOri2.replace(str, str2);            
        }
//        System.out.println(strOri2);//输出结果
        String kwstr = "";
        String[] keywordArray = kwstr.split("，");
		if(keywordArray.length>0) {
			
		}
        
	}

}
