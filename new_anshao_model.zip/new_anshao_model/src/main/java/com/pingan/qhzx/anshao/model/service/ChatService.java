package com.pingan.qhzx.anshao.model.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pingan.qhzx.anshao.model.common.bean.UnknowQuestionBean;
import com.pingan.qhzx.anshao.model.dao.ansirqa.ChatMapper;
import com.pingan.qhzx.anshao.model.dto.ansirqa.UnknowQuestionDTO;

@Service
public class ChatService implements IChatService {
	
	@Autowired
	private ChatMapper chatMapper;

	@Override
	@Transactional
	public void insertUnknowQuestion(List<UnknowQuestionBean> unknowQuestionBeanList) {
		List<UnknowQuestionDTO> unknowQuestionDTOlist = new ArrayList<UnknowQuestionDTO>();
		if(unknowQuestionBeanList!=null && unknowQuestionBeanList.size()>0) {
			for(UnknowQuestionBean unknowQuestionBean:unknowQuestionBeanList) {
				UnknowQuestionDTO unknowQuestionDTO = new UnknowQuestionDTO();
				unknowQuestionDTO.setQuestionDate(unknowQuestionBean.getQuestionDate());
				unknowQuestionDTO.setCreatedDate(new Date());
				unknowQuestionDTO.setAccountId(unknowQuestionBean.getAccountId()==null?"":unknowQuestionBean.getAccountId());
				unknowQuestionDTO.setOrgId(unknowQuestionBean.getOrgId());
				unknowQuestionDTO.setQuestionContent(unknowQuestionBean.getQuestionContent());
				unknowQuestionDTO.setQuestionSource(unknowQuestionBean.getQuestionSource());
				unknowQuestionDTOlist.add(unknowQuestionDTO);
			}
		}
		chatMapper.insertUnknowQuestion(unknowQuestionDTOlist);
	}
	
}
