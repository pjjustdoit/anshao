package com.pingan.qhzx.anshao.model.web.bean;

import java.io.Serializable;

public class QuestionAndAnswer implements Serializable {
//    private String label;

    /**
	 * 
	 */
	private static final long serialVersionUID = 3185674691750125270L;

	/**
	 * 
	 */

	private String answer;

    private String keywords;
    
    private String question;

//	public String getLabel() {
//		return label;
//	}
//
//	public void setLabel(String label) {
//		this.label = label;
//	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}
}
