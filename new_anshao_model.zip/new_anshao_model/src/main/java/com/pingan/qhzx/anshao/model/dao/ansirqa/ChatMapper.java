package com.pingan.qhzx.anshao.model.dao.ansirqa;

import java.util.List;

import com.pingan.qhzx.anshao.model.common.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.model.dto.ansirqa.UnknowQuestionDTO;

public interface ChatMapper  extends BaseMapper {

	void insertUnknowQuestion(List<UnknowQuestionDTO> unknowQuestionDTOlist);

}
