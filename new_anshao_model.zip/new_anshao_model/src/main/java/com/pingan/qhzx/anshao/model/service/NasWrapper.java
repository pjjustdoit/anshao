package com.pingan.qhzx.anshao.model.service;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class NasWrapper implements INasWrapper {

	@Value("{sys.nas.dir}")
	private String basePath;

	private String getPath(String filePath) {
		return basePath + filePath;
	}
	
	@Override
	public File createFile(String filePath) {
		try {
			File file = new File(getPath(filePath));
			if (!file.getParentFile().exists()) {
				file.getParentFile().mkdirs();
			}
			if (!file.exists()) {
				file.createNewFile();
			}
			return file;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
