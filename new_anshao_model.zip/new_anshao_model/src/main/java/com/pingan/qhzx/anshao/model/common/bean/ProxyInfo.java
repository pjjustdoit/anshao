package com.pingan.qhzx.anshao.model.common.bean;

public class ProxyInfo {
	
	private String hostname;   //域名
	private int port;          //端口
	private String scheme;     //协议
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getScheme() {
		return scheme;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	
	
}
