package com.pingan.qhzx.anshao.model.common.utils;

import com.google.common.base.Charsets;
import com.pingan.qhzx.anshao.model.common.bean.ProxyInfo;
import com.pingan.qhzx.anshao.model.common.ex.ServiceException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 
 */
public class HttpUtils {

    private static final Logger log = LoggerFactory.getLogger(HttpUtils.class);

    public static String post(String url, Map<String, String> params, ProxyInfo proxyInfo) {

        CloseableHttpClient httpClient = HttpClients.createDefault();

        try {
            HttpPost httpost = createHttpPost(url, params, proxyInfo);
            CloseableHttpResponse response = httpClient.execute(httpost);
            HttpEntity httpEntity = response.getEntity();
            return EntityUtils.toString(httpEntity, Charsets.UTF_8.name());
        } catch (Exception e) {
            log.error("", e);
            throw new ServiceException("网络错误", e.getLocalizedMessage());
        }
    }

    private static HttpPost createHttpPost(String url, Map<String, String> params, ProxyInfo proxyInfo) throws UnsupportedEncodingException, URISyntaxException {
        // 依次是代理地址，代理端口号，协议类型
        HttpPost httpost = new HttpPost(url);
        if(proxyInfo != null) {
        	setProxy(httpost, proxyInfo);
        }
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
        Set<String> keySet = params.keySet();
        for (String key : keySet) {
            nvps.add(new BasicNameValuePair(key, params.get(key)));
        }
        httpost.setEntity(new UrlEncodedFormEntity(nvps, Charsets.UTF_8.name()));
        return httpost;
    }

    private static void setProxy(HttpPost httpost, ProxyInfo proxyInfo) {
           HttpHost proxy = new HttpHost(proxyInfo.getHostname(), proxyInfo.getPort(), proxyInfo.getScheme());
           RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
           httpost.setConfig(config);
    }
   
    private static HttpPost createHttpJsonPost(String url, String json) throws UnsupportedEncodingException, URISyntaxException {
        HttpPost httpost = new HttpPost(url);
        // setProxy(httpost);
        StringEntity entity = new StringEntity(json);
        entity.setContentEncoding(Charsets.UTF_8.name());
        entity.setContentType("application/json");
        httpost.setEntity(entity);
        return httpost;
    }

    public static String httpsPost(String url, Map<String, String> params, ProxyInfo proxyInfo) {
        try {
            CloseableHttpClient httpClient = SSLHttpClient.getSSLHttpClient();
            HttpPost httpost = createHttpPost(url, params, proxyInfo);
            CloseableHttpResponse response = httpClient.execute(httpost);
            HttpEntity httpEntity = response.getEntity();
            return EntityUtils.toString(httpEntity, Charsets.UTF_8.name());
        } catch (Exception e) {
            log.error("", e);
            throw new ServiceException("网络错误", e.getLocalizedMessage());
        }
    }

    public static String httpsJsonPost(String url, String json) {
        CloseableHttpClient httpClient = SSLHttpClient.getSSLHttpClient();
        try {
            HttpPost httpost = createHttpJsonPost(url, json);
            if (httpClient != null) {
                CloseableHttpResponse response = httpClient.execute(httpost);
                HttpEntity httpEntity = response.getEntity();
                return EntityUtils.toString(httpEntity, Charsets.UTF_8.name());
            }
        } catch (Exception e) {
            log.error("", e);
            throw new ServiceException("网络错误", e.getLocalizedMessage());
        }
        return null;
    }

}
