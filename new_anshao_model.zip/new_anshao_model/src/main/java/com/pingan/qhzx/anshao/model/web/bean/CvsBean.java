package com.pingan.qhzx.anshao.model.web.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author gushijie251
 *
 */
public class CvsBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private List<String> questionList  = new ArrayList<String>(); //--答案列表
	private List<String> keyWordList = new ArrayList<String>();//--关键子列表
	private List<String> answerList = new ArrayList<String>();//--问题列表
	public List<String> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<String> questionList) {
		this.questionList = questionList;
	}
	public List<String> getKeyWordList() {
		return keyWordList;
	}
	public void setKeyWordList(List<String> keyWordList) {
		this.keyWordList = keyWordList;
	}
	public List<String> getAnswerList() {
		return answerList;
	}
	public void setAnswerList(List<String> answerList) {
		this.answerList = answerList;
	}
	
	

}
