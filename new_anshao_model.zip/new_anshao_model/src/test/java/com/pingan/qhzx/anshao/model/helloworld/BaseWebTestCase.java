package com.pingan.qhzx.anshao.model.helloworld;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.TestExecutionListeners;

import javax.servlet.http.Cookie;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;

/**
 * Created by yuzilei869 on 16/8/4.
 */
@SARContextConfiguration(sarList = "ansirqa")
@TestExecutionListeners({ZJPTTestExecutionListener.class})
public class BaseWebTestCase extends BaseSARTest {
    protected static final Logger log = LoggerFactory.getLogger(BaseWebTestCase.class);
    public static String TOKEN = UUID.randomUUID().toString();

    private Joiner.MapJoiner joiner = Joiner.on("&").withKeyValueSeparator("=").useForNull("");

    @Override
    protected String handleWebRequest(MockHttpServletRequest request, MockHttpServletResponse response) throws Exception {
        return super.handleWebRequest(request, response);
    }

    protected JSONObject requestTo(String uri, Map<String, Object> map) {
        String join = joiner.join(map);
        return requestTo(uri, join);
    }

    protected JSONObject requestTo(String uri, String formParams) {
        JSONObject result = null;
        try {
            MockHttpServletRequest mockRequest = this.createMockRequest(uri, formParams);
            mockRequest.setCookies(CookiesStore.cookies);
            MockHttpServletResponse mockResponse = this.createMockResponse();
            String s = this.handleWebRequest(mockRequest, mockResponse);
            CookiesStore.setCookies(mockResponse.getCookies());
            log.info("result-->{}", s);
            result = com.alibaba.fastjson.JSON.parseObject(s);
        } catch (Exception e) {
            log.error("", e);
        }

        log.info("result-->\n{}", JSON.toJSONString(result, true));
        return result;
    }

    private static class CookiesStore {
        public static Cookie[] cookies;

        static void setCookies(Cookie[] cookies) {
            HashSet<Cookie> set = Sets.newHashSet();
            if (null != CookiesStore.cookies) {
                set.addAll(Lists.newArrayList(CookiesStore.cookies));
            }
            if (null != cookies)
                set.addAll(Lists.newArrayList(cookies));
            CookiesStore.cookies = set.toArray(new Cookie[set.size()]);
        }
    }
}
