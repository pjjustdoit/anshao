package com.pingan.qhzx.anshao.hanlp;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.dictionary.CustomDictionary;
import com.hankcs.hanlp.seg.Segment;
import com.hankcs.hanlp.seg.common.Term;
import com.paic.pafa.web.BaseController;
import com.pingan.qhzx.anshao.model.common.utils.WebUtils;

@Controller
public class TestController extends BaseController {

    private static final Logger log = LoggerFactory.getLogger(TestController.class);
    
   // @Autowired
    //private ITestService testService;

    @ResponseBody
//	@ESA("ansirqa.test")
    @RequestMapping("/test.do")
    public JSONObject test(@RequestParam("testParam") String variable, HttpServletRequest request, HttpServletResponse response) {
        try {
        	HanLP.Config.enableDebug();
        	List<Term> termList = HanLP.segment("商品和服务");
        	System.out.println(termList);
        	String str="自定义";
        	Segment segment = HanLP.newSegment().enableCustomDictionary(true);
            CustomDictionary.add("商品和");
            List<Term> termList2 = HanLP.segment("商品和服务");
        	System.out.println(termList2);

        	return WebUtils.createSuccResult();
        } catch (Exception e) {
            log.error("", e);
            return WebUtils.createErrorResult();
        }

    }

}
