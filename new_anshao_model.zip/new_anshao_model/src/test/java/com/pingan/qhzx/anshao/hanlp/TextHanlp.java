package com.pingan.qhzx.anshao.hanlp;

import java.util.Map;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.model.helloworld.BaseWebTestCase;

public class TextHanlp extends BaseWebTestCase {
	private static final Logger logger = LoggerFactory.getLogger(TextHanlp.class);

	// @Test
	public void test1() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("orgName", "");
		JSONObject result = requestTo("/handlp/getKeywordList", map);

		logger.info("{}", JSON.toJSONString(result, true));

	}

	// 把Question写入文件
	// @Test
	public void test2() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("orgName", "");
		JSONObject result = requestTo("/handlp/writerQuestionToCsv", map);

		logger.info("{}", JSON.toJSONString(result, true));

	}

	@Test
	public void test3() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("orgName", "");
		JSONObject result = requestTo("/handlp/addMchtCorpusCtxList", map);

		logger.info("{}", JSON.toJSONString(result, true));

	}

	//@Test
	public void test4() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("keyWord", "");
		JSONObject result = requestTo("/handlp/selectListByKeyWord", map);

		logger.info("{}", JSON.toJSONString(result, true));

	}
}
