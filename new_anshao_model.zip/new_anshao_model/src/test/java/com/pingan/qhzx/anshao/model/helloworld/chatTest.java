package com.pingan.qhzx.anshao.model.helloworld;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.model.common.utils.RedisProvider;
import com.pingan.qhzx.anshao.model.common.utils.RedisService;

public class chatTest extends BaseWebTestCase{

	@Autowired
	private RedisService redisService;
	
	@Test
	public void test1(){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("orgId", "test1");
		map.put("userQuestion", "多少钱");
		map.put("fuzzyMatch", "1");
		map.put("threshold", 0.2);
		JSONObject result = requestTo("chatInRedis/answer/", map);
		
//		JSONObject result = requestTo("chatInRedis/resetRedisByQuestion/", map);//--初始化
		
	}
	
	

	
}
