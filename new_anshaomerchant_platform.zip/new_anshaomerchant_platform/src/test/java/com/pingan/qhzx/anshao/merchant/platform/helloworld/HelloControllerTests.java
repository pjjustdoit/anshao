package com.pingan.qhzx.anshao.merchant.platform.helloworld;

import java.util.UUID;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="anshaomerchant_platform")
public class HelloControllerTests  extends BaseSARTest{

	@Test
	public void test1() throws Exception{
		String result=this.handleWebRequest(this.createMockRequest("/test"
				, "testParam="+UUID.randomUUID().toString().replaceAll("-", ""))
				,this.createMockResponse());
		logger.info(result);
	}
	
}
