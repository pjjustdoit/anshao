package com.pingan.qhzx.anshao.merchant.platform.chat;

import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Charsets;
import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.google.common.hash.HashCode;
import com.google.common.hash.Hashing;
import com.pingan.qhzx.anshao.merchant.platform.answer.TestAnswer;
import org.junit.Test;

import java.io.IOException;
import java.util.Map;

/**
 * Created by yuzilei022 on 16/10/13.
 */
public class TestChat extends TestAnswer {
    boolean isCreateNew = true;

    @Test
    public void testChat() {
        try {
            super.testAnswer();
        } catch (IOException e) {
            log.error("", e);
        }
    }

    @Override
    protected String chat(String s) {
        Map<String, Object> map = Maps.newTreeMap();
        map.put("orgCode", "ZGPA");
        map.put("questionNo", "1");
        map.put("custId", "1");
        map.put("newSession", isCreateNew);
        isCreateNew = false;
        map.put("version", 1);
        map.put("questionCtx", s);
        StringBuilder sb = new StringBuilder(200);
        StringBuilder join = Joiner.on("&").withKeyValueSeparator("=").appendTo(sb, map).append("SH_00001");
        logger.info("queryString=" + join.toString());
        HashCode hashCode = Hashing.md5().hashString(join, Charsets.UTF_8);
        map.put("sign", hashCode);
        JSONObject jsonObject = requestTo("/mcht/robot/ansir", map);
        return jsonObject.getJSONObject("data").getString("answer");
    }
}
