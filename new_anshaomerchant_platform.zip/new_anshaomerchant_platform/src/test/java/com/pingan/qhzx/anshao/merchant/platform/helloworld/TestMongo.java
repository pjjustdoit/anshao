package com.pingan.qhzx.anshao.merchant.platform.helloworld;

import com.pingan.qhzx.anshao.merchant.platform.base.BaseWebTestCase;

/**
 * Created by yuzilei022 on 16/9/23.
 */
public class TestMongo extends BaseWebTestCase {
}
