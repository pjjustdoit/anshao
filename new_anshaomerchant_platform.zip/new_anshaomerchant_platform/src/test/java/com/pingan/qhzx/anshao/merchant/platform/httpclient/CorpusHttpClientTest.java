package com.pingan.qhzx.anshao.merchant.platform.httpclient;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Charsets;
import com.google.common.collect.Maps;
import com.google.common.hash.Hashing;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: ZHANGSHAN193
 * Date: 16-9-9
 * Time: 下午3:28
 * To change this template use File | Settings | File Templates.
 */
public class CorpusHttpClientTest extends BaseHttpClientTest{

    String[] industryArray = {"1","2","3","4"};

    @Before
    public void login(){
        getCommonLoginToken();
    }

    /**
     * 新增语料
     */
    @Test
    public void testAdd() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> params = Maps.newHashMap();

        params.put("zskClassifyId", 100); // 98 99 100
        params.put("exactMatchFlag", "1");  // 1=是 0=否
        params.put("question", "包邮的地方有哪些99");
        params.put("answer", "北上南广深99");
        params.put("keyWord", "包邮,地方99");
        params.put("expireDate", "2016-10-28");

        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/add", buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));
    }

    /**
     * 获取语料详情
     */
    @Test
    public void testDetail() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> params = Maps.newHashMap();

        params.put("mchtCorpusCtxId", 757);

        //   sign(map);
        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/update/detail", buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));

    }
    @Test
    public void testUpdate() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> params = Maps.newHashMap();

        params.put("mchtCorpusCtxId", 857);
        params.put("zskClassifyId", 98);
//        params.put("exactMatchFlag", 0);  // 1=是 0=否
//        params.put("question", "question question");
//        params.put("answer", "wa ha ha");
//        params.put("keyWord", "ha");
        params.put("expireDate", "2011-12-18");
//        params.put("effectiveFlag", 0); // 1=是 0=否

        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/update", buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));

    }
    /**
     * 批量更新
     */
    @Test
    public void testBatchUpdate() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> params = Maps.newHashMap();

        params.put("zskClassifyId", 98);
//        params.put("exactMatchFlag", 0);  // 1=是 0=否
//        params.put("question", "单如何修");

  //      params.put("queryStartDate", "2016-10-12");
   //     params.put("queryEndDate", "2016-10-13");

        // targetField:目标字段 exactMatchFlag＝精确匹配 zskClassifyId＝分类 expireDate 有效期
        // fieldValue：对应修改的值 String 日期格式 yyyy-MM-dd
        params.put("targetField", "zskClassifyId");
        params.put("fieldValue", "101");

        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/batchUpdate", buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));

    }

    @Test
    public void testCorpusQuery() {
        Map<String, Object> params = Maps.newHashMap();

    //    params.put("zskClassifyId", 98);
//        params.put("exactMatchFlag", "0"); // 精确匹配 1=是 0=否
  //      params.put("queryStartDate", "2016-10-12");
 //       params.put("queryEndDate", "2016-10-13");
        params.put("question", "系统");
        params.put("currentPage", 1);
        params.put("pageSize", 10);
        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/query",buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));
    }

    @Test
    public void testDelete() {
        Map<String, Object> params = Maps.newHashMap();

        params.put("mchtCorpusCtxId", 759);

        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/delete",buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));
    }

    @Test
    public void testStat() {
        Map<String, Object> params = Maps.newHashMap();

        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/stat",buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));
    }

    @Test
    public void testStatusChange() {
        Map<String, Object> params = Maps.newHashMap();
        params.put("mchtCorpusCtxId", 757);
        params.put("effectiveFlag", "0");

        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/status/change",buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));
    }

    @Test
    public void testCorpusExporter() {
        Map<String, Object> params = Maps.newHashMap();

      //  params.put("zskClassifyId", 101);
        List<Integer> mchtCorpusCtxIdList = new ArrayList<Integer>();
        mchtCorpusCtxIdList.add(754);
        mchtCorpusCtxIdList.add(756);
        params.put("mchtCorpusCtxIdList", "754,756");
//        params.put("exactMatchFlag", "0"); // 精确匹配 1=是 0=否
        params.put("queryStartDate", "2016-10-12");
        params.put("queryEndDate", "2016-10-13");

        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/exporter",buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));
    }

    /**
     * 上传文件
     */
    @Test
    public void testCorpusImporter() {

        Map<String, Object> params = Maps.newHashMap();
        params.put("corpusFile","file:/Users/zhangshan193/Downloads/import2.xlsx");
        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/importer",buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));

        testDownloadFailedExcel();
    }

    @Test
    public void testDownloadFailedExcel(){
        Map<String, Object> params = Maps.newHashMap();
        JSONObject result = getAndPrintResponse("mcht/zsk/corpus/importer/downloadFailedExcel",buildCommonQueryString(params));
        System.out.println(JSON.toJSONString(result, true));
    }

    @Test
    public void testPattern(){
        String str = "file:c:/aa/bb" ;
        String filePath = str.replaceFirst("[Ff][iI][lL][eE]:","");
        System.out.println("1".matches("1|2|3|4|5"));
        System.out.println("2".matches("1|2|3|4|5"));
        System.out.println("3".matches("1|2|3|4|5"));
        System.out.println("4".matches("1|2|3|4|5"));
        System.out.println("5".matches("1|2|3|4|5"));
        System.out.println("----------------");
        System.out.println("11".matches("1|2|3|4|5"));
        System.out.println("23".matches("1|2|3|4|5"));
        System.out.println("12".matches("1|2|3|4|5"));
        System.out.println("123".matches("1|2|3|4|5"));
        System.out.println("***************************");
        System.out.println("1.0".replaceAll("\\.0*",""));
        System.out.println("1.00".replaceAll("\\.0*",""));
        System.out.println("1.".replaceAll("\\.0*",""));
        System.out.println("2.00000000".replaceAll("\\.0*",""));
        System.out.println("10.00".replaceAll("\\.0*",""));
        System.out.println("10".replaceAll("\\.0*",""));
    }

    @Test
    public void md5(){
        String str = "PLATFORM_mchtUserAuthSelected=1,4,5,6,7&orgId=1&roleDesc=前海征信内部&roleName=QHZX1_45357a5c731751a44000d1ba2c0e25fb";
        String str2 = "PLATFORM_mchtUserAuthSelected=1,4,5,6,7&orgId=1&roleDesc=%E5%89%8D%E6%B5%B7%E5%BE%81%E4%BF%A1%E5%86%85%E9%83%A8&roleName=QHZX1_45357a5c731751a44000d1ba2c0e25fb";
        //System.out.println(Hashing.md5().hashBytes(str.getBytes("ISO-8859-1")).toString());
        String md5Str = Hashing.md5().hashString(str2, Charsets.UTF_8).toString();
        System.out.println("md5:"+md5Str);

    }



}
