package com.pingan.qhzx.anshao.merchant.platform.corpus;

import com.alibaba.fastjson.*;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.merchant.platform.base.BaseWebTestCase;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangshan193 on 16/10/10.
 */
@TransactionConfiguration(defaultRollback = true)
@Transactional
public class CorpusTest extends BaseWebTestCase {

    @Before
    public void login() {
        Map<String, Object> map = Maps.newHashMap();
        System.out.println("--------------");
        map.put("userPwd", "e19d5cd5af0378da05f63f891c7467af");
        map.put("loginName", "chenlijuan");
        sign(map);
        JSONObject result = requestTo("/mcht/user/nologin/login", map);
        log.info("{}", JSON.toJSONString(result, true));
    }

    /**
     * 语料汇总
     */
    @Test
    public void testCorpusStat() {
     //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

     //   sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/ansirMerchant/mcht/zsk/corpus/stat", map);
        log.info("{}", JSON.toJSONString(result, true));

    }

    /**
     * 新增语料
     */
    @Test
    public void testAdd() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

        map.put("zskClassifyId", 98); // 98 99 100
        map.put("exactMatchFlag", "0");  // 1=是 0=否
        map.put("question", "订单如何修改");
        map.put("answer", "点击编辑即可");
        map.put("keyWord", "修改");
        map.put("expireDate", System.currentTimeMillis());
        //   sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/ansirMerchant/mcht/zsk/corpus/add", map);
        log.info("{}", JSON.toJSONString(result, true));
    }

    /**
     * 批量新增语料
     */
    @Test
    public void testAddList() {
        //   log.info("--->{}", TOKEN);


        for(int i=1;i<95;i++) {
            Map<String, Object> map = Maps.newHashMap();
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR,-100+i);
            map.put("zskClassifyId", 98); // 98 99 100
            map.put("exactMatchFlag", "0");  // 1=是 0=否
            map.put("question", "订单如何修改"+i);
            map.put("answer", "点击编辑即可"+i);
            map.put("keyWord", "修改"+i);
            map.put("expireDate", cal.getTimeInMillis());
            //   sign(map);
            com.alibaba.fastjson.JSONObject result = requestTo("/ansirMerchant/mcht/zsk/corpus/add", map);
            log.info("{}", JSON.toJSONString(result, true));
        }
    }

    /**
     * 批量更新
     */
    @Test
    public void testBatchUpdate() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

        map.put("zskClassifyId", 98);
        map.put("exactMatchFlag", 1);  // 1=是 0=否
        map.put("question", "a订单如何修改");

        map.put("queryStartDate", "2016-10-12");
        map.put("queryEndDate", "2016-10-12");

        // targetField:目标字段 exactMatchFlag＝精确匹配 zskClassifyId＝分类 expireDate 有效期
        // fieldValue：对应修改的值 String 日期格式 yyyy-MM-dd
        map.put("targetField", "expireDate");
        map.put("fieldValue", "2016-12-12");

        //   sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/mcht/zsk/corpus/batchUpdate", map);
        log.info("{}", JSON.toJSONString(result, true));

    }

    @Test
    public void testUpdate() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

        map.put("mchtCorpusCtxId", 303);
        map.put("zskClassifyId", 100);
        map.put("exactMatchFlag", 0);  // 1=是 0=否
        map.put("question", "question question");
        map.put("answer", "wa ha ha");
        map.put("keyWord", "ha");
        map.put("expireDate", System.currentTimeMillis()+1000*24*60*60);
        map.put("effectiveFlag", 0); // 1=是 0=否

        //   sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/mcht/zsk/corpus/update", map);
        log.info("{}", JSON.toJSONString(result, true));

    }

    /**
     * 删除语料
     */
    @Test
    public void testDelete() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

        map.put("mchtCorpusCtxId", 209);

        //   sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/mcht/zsk/corpus/delete", map);
        log.info("{}", JSON.toJSONString(result, true));

    }

    /**
     * 获取语料详情
     */
    @Test
    public void testDetail() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

        map.put("mchtCorpusCtxId", 303);

        //   sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/mcht/zsk/corpus/detail", map);
        log.info("{}", JSON.toJSONString(result, true));

    }

    /**
     * 分类查询
     */
    @Test
    public void testQuery() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

        map.put("zskClassifyId", 98);
        map.put("exactMatchFlag", "1"); // 精确匹配 1=是 0=否
        map.put("question", "如何修改");
        map.put("queryStartDate", "2016-07-06");
        map.put("queryEndDate", "2016-07-19");

        map.put("currentPage", 1);
        map.put("pageSize", 3);
           sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/mcht/zsk/corpus/query", map);
        log.info("{}", JSON.toJSONString(result, true));

    }

    /**
     * 批量导出
     */
    @Test
    public void testExporter() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

        map.put("zskClassifyId", "第  1");
        map.put("exactMatchFlag", "第  1"); // exactMatchFlag：精确匹配 1=是 0=否
        map.put("question", "第  1");
        map.put("queryStartDate", "第  1");
        map.put("queryEndDate", "第  1");
       // map.put("mchtCorpusCtxIdList", "[11,12,13]");

        //   sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/mcht/zsk/corpus/exporter", map);
        log.info("{}", JSON.toJSONString(result, true));

    }

    /**
     * 批量导入
     */
    @Test
    public void testImporter() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

        map.put("corpusFile", "第  1");

        //   sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/mcht/zsk/corpus/importer", map);
        log.info("{}", JSON.toJSONString(result, true));

    }

    /**
     * 变更状态
     */
    @Test
    public void testStatusChange() {
        //   log.info("--->{}", TOKEN);
        Map<String, Object> map = Maps.newHashMap();

        map.put("mchtCorpusCtxId", "第  1");
        map.put("effectiveFlag", "第  1"); // 是否有效 1=是 0=否（期望变更到的状态）
        //   sign(map);
        com.alibaba.fastjson.JSONObject result = requestTo("/mcht/zsk/corpus/status/change", map);
        log.info("{}", JSON.toJSONString(result, true));

    }



}
