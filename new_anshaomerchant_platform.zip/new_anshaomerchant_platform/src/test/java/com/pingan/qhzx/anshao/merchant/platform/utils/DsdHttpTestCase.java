package com.pingan.qhzx.anshao.merchant.platform.utils;

import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.cookie.CookieSpecProvider;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.impl.cookie.BestMatchSpecFactory;
import org.apache.http.impl.cookie.BrowserCompatSpecFactory;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Charsets;
import com.pingan.qhzx.anshao.merchant.platform.base.BaseWebTestCase;
import com.pingan.qhzx.anshao.platform.common.ex.ServiceException;

/**
 * Created by YUZILEI869 on 2015-12-24.
 */
public class DsdHttpTestCase extends BaseWebTestCase {

	static CookieStore cookieStore = null;

	static HttpClientContext context = null;

	protected static final Logger log = LoggerFactory.getLogger(DsdHttpTestCase.class);

	protected String domain = "http://127.0.0.1:8082/ansirMerchant";

	protected boolean isSetProxy = false;

	protected JSONObject exec(String path, Map<String, Object> params) {
		JSONObject result = null;
		try {
			sign(params);
			result =  com.alibaba.fastjson.JSON.parseObject(post(domain + path, params));
		} catch (Exception e) {
			log.error("", e);
		}
		
		return result;
	}

	public String post(String url, Map<String, Object> params) {

		CloseableHttpClient httpClient = HttpClients.custom().setDefaultCookieStore(cookieStore).build();

		try {
			HttpPost httpost = createHttpPost(url, params);
			CloseableHttpResponse response = httpClient.execute(httpost);
			HttpEntity httpEntity = response.getEntity();

			if (response.getFirstHeader("Set-Cookie") != null
					&& !StringUtils.isBlank(response.getFirstHeader("Set-Cookie").toString())) {
				// cookie store
				setCookieStore(response);
				// setContext
				setContext();
			}

			return EntityUtils.toString(httpEntity);
		} catch (Exception e) {
			log.error("", e);
			throw new ServiceException("网络错误", e.getLocalizedMessage());
		}
	}

	private HttpPost createHttpPost(String url, Map<String, Object> params)
			throws UnsupportedEncodingException, URISyntaxException {
		// 依次是代理地址，代理端口号，协议类型
		HttpPost httpost = new HttpPost(url);
		if (isSetProxy) {
			setProxy(httpost);
		}
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		Set<String> keySet = params.keySet();
		for (String key : keySet) {
			nvps.add(new BasicNameValuePair(key, String.valueOf(params.get(key))));
		}
		httpost.setEntity(new UrlEncodedFormEntity(nvps, Charsets.UTF_8.name()));
		return httpost;
	}

	private void setProxy(HttpPost httpost) {
		HttpHost proxy = new HttpHost("10.17.171.11", 8080, "http");
		RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
		httpost.setConfig(config);
	}

	public static void setCookieStore(HttpResponse httpResponse) {

		// JSESSIONID
		String setCookie = httpResponse.getFirstHeader("Set-Cookie").getValue();

		System.out.println("----setCookieStore");
		cookieStore = new BasicCookieStore();
		String JSESSIONID = setCookie.substring("ansir_session_key=".length(), setCookie.indexOf(";"));
		System.out.println("JSESSIONID:" + JSESSIONID);
		// 新建一个Cookie
		BasicClientCookie cookie = new BasicClientCookie("ansir_session_key", JSESSIONID);
		cookie.setVersion(0);
		cookie.setDomain("127.0.0.1");
		cookie.setPath("/ansirMerchant");
		cookieStore.addCookie(cookie);
	}

	public static void setContext() {
		System.out.println("----setContext");
		context = HttpClientContext.create();
		Registry<CookieSpecProvider> registry = RegistryBuilder.<CookieSpecProvider> create()
				.register(CookieSpecs.BEST_MATCH, new BestMatchSpecFactory())
				.register(CookieSpecs.BROWSER_COMPATIBILITY, new BrowserCompatSpecFactory()).build();
		context.setCookieSpecRegistry(registry);
		context.setCookieStore(cookieStore);
	}
}
