package com.pingan.qhzx.anshao.merchant.platform.qa;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.qhzx.anshao.merchant.platform.base.BaseWebTestCase;
import com.pingan.qhzx.anshao.platform.common.bean.qa.SynchronizationQuestionBean;
import com.pingan.qhzx.anshao.platform.common.dto.qa.SynchronizationQuestionDTO;
import com.pingan.qhzx.anshao.platform.common.service.model.api.IAnsirAPI;
import com.pingan.qhzx.anshao.platform.common.service.qa.ISynchronizationQuestionService;

public class TestSynchronizationQuestion extends BaseWebTestCase {
	@Autowired
	private ISynchronizationQuestionService synchronizationQuestionService;

	@Autowired
	private IAnsirAPI ansirAPI;

	// @Test
	public void test() {
		SynchronizationQuestionDTO synchronizationQuestionDTO = new SynchronizationQuestionDTO();
		synchronizationQuestionDTO.setSyncStatus("2");// 状态为"更新中"
		Calendar calendar = Calendar.getInstance();
		Date endDate = calendar.getTime();
		synchronizationQuestionDTO.setEndDate(endDate);
		synchronizationQuestionDTO.setUpdatedDate(endDate);
		calendar.add(Calendar.DATE, -3);
		Date startDate = calendar.getTime();
		synchronizationQuestionDTO.setStartDate(startDate);
		synchronizationQuestionService.updateSyncSatus(synchronizationQuestionDTO);
	}

	@Test
	public void test1() {
		String syncStatus = "3";
		Integer batchNo = -1;
		try {
			log.info("****************unknown question sync start*****************");
			batchNo = synchronizationQuestionService.unknowQuestions();
			List<SynchronizationQuestionBean> list = synchronizationQuestionService.seltQaSerListByOrgIdSerNo(batchNo);
			Boolean flag = ansirAPI.ansirUnknowQuestionList(list);
			if (flag) {
				// 同步成功，状态改为"1"
				syncStatus = "1";
			}
		} catch (Exception e) {
			log.error("unknown question sync false", e);
		} finally {
			if (batchNo != -1) {
				SynchronizationQuestionDTO synchronizationQuestionDTO = new SynchronizationQuestionDTO();
				synchronizationQuestionDTO.setBatchNo(batchNo);
				synchronizationQuestionDTO.setSyncStatus(syncStatus);
				synchronizationQuestionDTO.setUpdatedDate(new Date());
				synchronizationQuestionService.updateSyncSatuByBatchNo(synchronizationQuestionDTO);
			}
			log.info("****************unknown question sync end*****************");
		}
	}
}
