package com.pingan.qhzx.anshao.merchant.platform.base;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Charsets;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.hash.Hashing;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.TestExecutionListeners;

import javax.servlet.http.Cookie;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by yuzilei869 on 16/8/4.
 */
@SARContextConfiguration(sarList = "anshaomerchant_platform", protocols = "jetty,dubbo")
@TestExecutionListeners({ SarTestExecutionListener.class })
public class BaseWebTestCase extends BaseSARTest {
	protected static final Logger log = LoggerFactory.getLogger(BaseWebTestCase.class);

	@Value("${web.security.sign.suffix}")
	protected String securitySignSuffix;
	@Value("${web.security.sign.prefix}")
	private String securitySignPrefix;

	private Joiner.MapJoiner joiner = Joiner.on("&").withKeyValueSeparator("=").useForNull("");

	@Override
	protected String handleWebRequest(MockHttpServletRequest request, MockHttpServletResponse response)
			throws Exception {
		return super.handleWebRequest(request, response);
	}

	protected JSONObject requestTo(String uri, Map<String, Object> map) {
		String join = joiner.join(map);
		return requestTo(uri, join);
	}

	protected JSONObject requestTo(String uri, String formParams) {
		JSONObject result = null;
		try {
			MockHttpServletRequest mockRequest = this.createMockRequest(uri, formParams);
			mockRequest.setCookies(CookiesStore.cookies);
			log.info("json===:" + JSON.toJSONString(CookiesStore.cookies));
			MockHttpServletResponse mockResponse = this.createMockResponse();
			String s = this.handleWebRequest(mockRequest, mockResponse);
			CookiesStore.setCookies(mockResponse.getCookies());
			log.info("result-->{}", s);
			result = JSON.parseObject(s);
		} catch (Exception e) {
			log.error("", e);
		}

		log.info("result-->\n{}", JSON.toJSONString(result, true));
		return result;
	}

	private static class CookiesStore {
		public static Cookie[] cookies;

		static void setCookies(Cookie[] cookies) {
			HashSet<Cookie> set = Sets.newHashSet();
			if (null != CookiesStore.cookies) {
				set.addAll(Lists.newArrayList(CookiesStore.cookies));
			}
			if (null != cookies)
				set.addAll(Lists.newArrayList(cookies));
			CookiesStore.cookies = set.toArray(new Cookie[set.size()]);
		}
	}

	protected void sign(Map<String, Object> json) {
		TreeMap<String, Object> treeMap = new TreeMap<String, Object>(json);
		StringBuilder sb = new StringBuilder();
		Iterator<String> iterator = treeMap.keySet().iterator();
		while (iterator.hasNext()) {
			String key = iterator.next();
			sb.append(key).append("=").append(treeMap.get(key)).append("&");
		}
		if (sb.length() > 0) {
			sb.deleteCharAt(sb.length() - 1);
		}
		sb.insert(0, securitySignPrefix);
		sb.append(securitySignSuffix);
		log.info(sb.toString());
		String s = Hashing.md5().hashString(sb.toString(), Charsets.UTF_8).toString();
		json.put("sign", s);
		log.info("json--->{}", json);
	}
}
