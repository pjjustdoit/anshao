package com.pingan.qhzx.anshao.merchant.platform.wx;

import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.qhzx.anshao.merchant.platform.base.BaseWebTestCase;
import com.pingan.qhzx.anshao.platform.common.service.wxhome.IWxHomeService;

public class TestWx extends BaseWebTestCase {
	
	@Autowired
	private IWxHomeService wxHomeService;
	
	@Test
	public void testAcceptMessage() {
		try {
			HttpServletRequest req = null;
			HttpServletResponse response = null;
			Map<String, String> acceptMessagemMap = wxHomeService.acceptMessage(req);
			String sendMessageXml = wxHomeService.sendMessage(acceptMessagemMap, "11");
			//发送xml的格式信息给微信服务器，服务器转发给用户
			PrintWriter printWriter = response.getWriter();
			printWriter.print(sendMessageXml);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
