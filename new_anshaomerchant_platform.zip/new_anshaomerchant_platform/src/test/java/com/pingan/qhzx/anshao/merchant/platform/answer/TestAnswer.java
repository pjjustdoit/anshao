package com.pingan.qhzx.anshao.merchant.platform.answer;

import com.google.common.collect.Lists;
import com.pingan.qhzx.anshao.merchant.platform.base.BaseWebTestCase;
import com.pingan.qhzx.anshao.merchant.platform.robot.IRobotFacade;
import com.pingan.qhzx.anshao.platform.common.service.model.api.IAnsirAPI;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Date;

/**
 * Created by yuzilei022 on 16/10/8.
 */
public class TestAnswer extends BaseWebTestCase {
    @Autowired
    private IRobotFacade IRobotFacade;
    @Autowired
    private IAnsirAPI api;

    @Test
    public void testAnswer() throws IOException {
        MyApplet f = new MyApplet();
        f.setBounds(100, 100, 800, 250);
        f.setVisible(true);
        f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        f.addWindowListener(new WindowAdapter() {
            public void windowClosed(WindowEvent e) {
                System.exit(0);
            }
        });

        System.in.read();
    }

    protected String chat(String s) {
        Request request = new Request();
        request.setQuestionNo(System.currentTimeMillis() + "");
        request.setQuestionCtx(s);
        request.setOrgCode("ZGPA");
        request.setCustId("1");
        request.setSubmitDate(new Date());
        Response chat = IRobotFacade.chat(request);
        return chat.getAnswer();
    }

    @Test
    public void testCreateModel() {
        api.createModel(Lists.newArrayList("knowledge"));
    }

    protected class MyApplet extends JFrame {

        public MyApplet() throws HeadlessException {
            Container contentPane = getContentPane();

            JLabel label = new JLabel("请输入问题：", SwingConstants.CENTER);
            final JTextField jft = new JTextField();
            contentPane.setLayout(new GridLayout(5, 2));
            contentPane.add(label);
            contentPane.add(jft);

            JButton jb = new JButton();
            jb.setText("send");
            contentPane.add(jb);
            JLabel label1 = new JLabel("回答：", SwingConstants.CENTER);
            contentPane.add(label1);
            final JTextField as = new JTextField();
            contentPane.add(as);

            callChat("", as);

            jb.addActionListener(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String text = jft.getText();
                    callChat(text, as);
                }
            });
        }

        private void callChat(String text, JTextField as) {
            String chat = chat(text);
            as.setText(chat);
        }
    }
}
