package com.pingan.qhzx.anshao.merchant.platform.reportStatistics;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.merchant.platform.utils.DsdHttpTestCase;

/**
 * 测试类 测试：登录安少商户管理平台->报表统计
 * 
 * @author LIUPENGLIANG375 创建时间：2016年10月9日 下午3:00:20
 */
@TransactionConfiguration(defaultRollback = true)
@Transactional
public class TestReportStatistics extends DsdHttpTestCase {

	@Before
	public void test() {
		Map<String, Object> map = Maps.newHashMap();

		map.put("loginName", "chenlijuan");
		map.put("userPwd", "7afe538efec10188a5a027c79f627dbf");
		JSONObject result = exec("/mcht/user/nologin/login", map);
		log.info("{}", JSON.toJSONString(result, true));

	}

	// 流量汇总查询
	//@Test
	public void test1() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("classifyName", "新增分类实验");
		JSONObject result = exec("/mcht/traffic/stat", map);
		log.info("{}", JSON.toJSONString(result, true));
	}

	// 流量查询
	//@Test
	public void test2() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("queryStartDate", "2016-10-10");
		map.put("queryEndDate", "2016-10-24");
		JSONObject result = exec("/mcht/traffic/query", map);
		log.info("{}", JSON.toJSONString(result, true));
	}

	// 流量导出
	// @Test
	public void test3() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("queryStartDate", "2016-09-28");
		map.put("queryEndDate", "2016-10-29");
		map.put("serialType", "");
		JSONObject result = exec("/mcht/traffic/exporter", map);
		log.info("{}", JSON.toJSONString(result, true));
	}

	// 流量详细导出
	//@Test
	public void test4() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("queryStartDate", "2016-09-28");
		map.put("queryEndDate", "2016-10-20");
		JSONObject result = exec("/mcht/traffic/detailExporter", map);
		log.info("{}", JSON.toJSONString(result, true));
	}

	// 验证问答接口
	@Test
	public void test5() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("queryStartDate", "2016-09-28");
		map.put("queryEndDate", "2016-10-10");
		JSONObject result = exec("/mcht/traffic/stat/qaTest", map);
		log.info("{}", JSON.toJSONString(result, true));
	}
}
