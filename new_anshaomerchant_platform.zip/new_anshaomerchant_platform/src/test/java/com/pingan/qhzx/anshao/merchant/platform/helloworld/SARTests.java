package com.pingan.qhzx.anshao.merchant.platform.helloworld;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;



@SARContextConfiguration(sarList="anshaomerchant_platform",protocols="jetty")
public class SARTests extends BaseSARTest{

	
	@Test
	public void iz() throws Throwable{
		
		System.in.read();
	}
	
}
