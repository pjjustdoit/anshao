package com.pingan.qhzx.anshao.merchant.platform.knowledge;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.merchant.platform.utils.DsdHttpTestCase;

/**
 * 测试类 测试：商户管理平台->知识库管理->分类管理
 * 
 * @author LIUPENGLIANG375 创建时间：2016年9月27日 下午1:40:23
 */
@TransactionConfiguration(defaultRollback = true)
@Transactional
public class TestKnowledgeBase extends DsdHttpTestCase {

	@Before
	public void login() {
		Map<String, Object> map = Maps.newHashMap();

		map.put("loginName", "chenlijuan");
		map.put("userPwd", "e19d5cd5af0378da05f63f891c7467af");
		JSONObject result = exec("/mcht/user/nologin/login", map);
		log.info("{}", JSON.toJSONString(result, true));

	}

	// 新增分类
	// @Test
	public void test1() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("classifyName", "新增分类实验");
		JSONObject result = exec("/mcht/zsk/classify/add", map);
		log.info("{}", JSON.toJSONString(result, true));
	}

	// 更新分类
	@Test
	public void test2() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("classifyName", "修xsd分adaytftd类");
		map.put("zskClassifyId", 135);
		JSONObject result = exec("/mcht/zsk/classify/update", map);
		log.info("{}", JSON.toJSONString(result, true));
	}

	// 删除分类
	// @Test
	public void test3() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("zskClassifyId", 136);
		JSONObject result = exec("/mcht/zsk/classify/delete", map);
		log.info("{}", JSON.toJSONString(result, true));
	}

	// 获取分类详细
	// @Test
	public void test4() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("zskClassifyId", 124);
		JSONObject result = exec("/mcht/zsk/classify/detail", map);
		log.info("{}", JSON.toJSONString(result, true));
	}

	// 分类查询
	// @Test
	public void test5() {
		Map<String, Object> map = Maps.newHashMap();
		// map.put("classifyName", "商");
		JSONObject result = exec("/mcht/zsk/classify/query", map);
		log.info("{}", JSON.toJSONString(result, true));
	}

	// 分类查询
	// @Test
	public void test6() {
		Map<String, Object> map = Maps.newHashMap();
		JSONObject result = exec("/mcht/zsk/classify/list", map);
		log.info("{}", JSON.toJSONString(result, true));
	}
}
