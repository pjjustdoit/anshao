package com.pingan.qhzx.anshao.merchant.platform.base;

import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.pizza.Pizza;
import com.pingan.pafa.pizza.log4j.PizzaDefaultLogger;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.support.AbstractTestExecutionListener;
import org.springframework.util.StringUtils;

/**
 * Created by yuzilei869 on 16/8/4.
 */
public class SarTestExecutionListener extends AbstractTestExecutionListener {

    public void beforeTestClass(TestContext testContext) throws Exception {
        PizzaDefaultLogger.getLogger();
        System.setProperty("papp.esa.http.export.enable", "true");
        SARContextConfiguration config = testContext.getTestClass().getAnnotation(SARContextConfiguration.class);
        Class<?> testClass = testContext.getTestClass();
        while (config == null) {
            testClass = testClass.getSuperclass();
            if (testClass.equals(Object.class)) {
                break;
            }
            config = testClass.getAnnotation(SARContextConfiguration.class);
        }

        if (config != null) {
            String[] temp = config.protocols();
            if (temp != null && temp.length > 0) {
                System.setProperty("papp.protocols", StringUtils.arrayToDelimitedString(temp, ","));
            }

            temp = config.sarList();
            if (temp != null && temp.length > 0) {
                System.setProperty("papp.sar.list", StringUtils.arrayToDelimitedString(temp, ","));
            }

            String pizzaConfigFile = config.pizzaConfigFile();
            if (pizzaConfigFile != null && pizzaConfigFile.length() > 0) {
                System.setProperty(Pizza.KEY_CONFIG_FILE, pizzaConfigFile);
            }
        }

    }
}
