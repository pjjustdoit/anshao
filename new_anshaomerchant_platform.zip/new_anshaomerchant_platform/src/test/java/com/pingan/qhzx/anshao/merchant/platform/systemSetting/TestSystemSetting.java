package com.pingan.qhzx.anshao.merchant.platform.systemSetting;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.merchant.platform.httpclient.BaseHttpClientTest;

/**
 * 测试类 测试：登录安少商户管理平台->系统设置
 * 
 * @author LIUPENGLIANG375 创建时间：2016年9月28日 下午1:55:27
 */
@TransactionConfiguration(defaultRollback = true)
@Transactional
public class TestSystemSetting extends BaseHttpClientTest {

	@Before
	public void login() {
		getCommonLoginToken();
	}

	// 机器人配置Detail
	// @Test
	public void test1() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("orgCode", "shCode");
		map.put("orgName", "shName");
		JSONObject result = getAndPrintResponse("mcht/system/robotDetail", buildCommonQueryString(map));
		System.out.println(JSON.toJSONString(result, true));
	}

	// 机器人设置
	@Test
	public void test2() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("robotName", "小冰");
		map.put("fuzzyMatchThreshold", 0);
		map.put("fuzzyMatchSwitch", 1);
		map.put("welcomeLang", "您好，我是小冰，很高兴见到你！");
		map.put("defaultAnswer", "不好意思，这个我不知道哦！");
		JSONObject result = getAndPrintResponse("mcht/system/robotSetting", buildCommonQueryString(map));
		System.out.println(JSON.toJSONString(result, true));
	}
}
