package com.pingan.qhzx.anshao.merchant.platform.corpus;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.merchant.platform.base.BaseWebTestCase;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtCorpusCtxMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.service.corpus.IMchtCorpusService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Calendar;
import java.util.Map;

/**
 * Created by zhangshan193 on 16/10/12.
 */
public class CorpusMapperTest extends BaseWebTestCase {

    @Autowired
    private IMchtCorpusService mchtCorpusService;

    @Autowired
    private MchtCorpusCtxMapper mchtCorpusCtxMapper;

    @Test
    public void addList(){
        for(int i=1;i<99;i++){
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR,-100+i);
            MchtCorpusCtx mchtCorpusCtx = new MchtCorpusCtx();
            mchtCorpusCtx.setExpireDate(cal.getTime());
            mchtCorpusCtx.setUpdatedBy("QHZX");
            mchtCorpusCtx.setUpdatedDate(cal.getTime());
            mchtCorpusCtx.setCreatedBy("QHZX");
            mchtCorpusCtx.setCreatedDate(cal.getTime());
            mchtCorpusCtx.setZskClassifyId(98);
            mchtCorpusCtx.setOrgId(32);
            mchtCorpusCtx.setExactMatchFlag("0");
            mchtCorpusCtx.setQuestion("订单如何修改"+i);
            mchtCorpusCtx.setAnswer("点击编辑即可"+i);
            mchtCorpusCtx.setKeyWord("编辑");
            mchtCorpusCtx.setEffectiveFlag("1");
            mchtCorpusCtxMapper.insertSelective(mchtCorpusCtx);
        }

    }



}
