package com.pingan.qhzx.anshao.merchant.platform.web.controller.robot;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.merchant.platform.robot.IRobotFacade;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import com.pingan.qhzx.anshao.platform.common.web.common.CommonController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by yuzilei022 on 16/9/26.
 */
@Controller
@RequestMapping("/mcht/robot")
public class RobotChatController extends CommonController {

    @Autowired
    private IRobotFacade IRobotFacade;

    @RequestMapping("/ansir")
    @ResponseBody
    public JSONObject knowledge(Request req, HttpServletRequest request) {
        req.setRequest(request);
        Response chat = IRobotFacade.chat(req);
        return chat.createJson();
    }
}
