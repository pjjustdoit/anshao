package com.pingan.qhzx.anshao.merchant.platform.web.controller.knowledge;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.merchant.platform.web.common.AnshaoMerchPtCommonController;
import com.pingan.qhzx.anshao.platform.common.bean.knowledge.ZskClassifyPageDTO;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;
import com.pingan.qhzx.anshao.platform.common.dto.pg.ZskClassify;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.ex.ServiceException;
import com.pingan.qhzx.anshao.platform.common.service.IKnowledgeBaseService;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;

/**
 * 商户管理平台->知识库管理->分类管理
 * 
 * @author LIUPENGLIANG375 创建时间：2016年9月27日 下午12:52:17
 */

@Controller
@RequestMapping("/mcht/zsk")
public class KnowledgeBaseController extends AnshaoMerchPtCommonController {

	@Autowired
	private IKnowledgeBaseService knowledgeBaseService;

	Logger logger = Logger.getLogger(KnowledgeBaseController.class);

	// 从session获得Org
	// private Org getOrg(HttpServletRequest request) {
	// return getUserInfo(request).getOrg();
	// }

	// 从session获得MchtUser
	private MchtUser getMchtUser(HttpServletRequest request) {
		return getUserInfo(request).getMchtUser();
	}

	/**
	 * 新增分类
	 * 
	 * @param request
	 * @param zskClassify
	 * @return JSONObject
	 */
	@RequestMapping("/classify/add")
	@ResponseBody
	public JSONObject addClassify(HttpServletRequest request, ZskClassify zskClassify) {
		try {
			if (StringUtils.isBlank(zskClassify.getClassifyName())) {
				logger.error("参数异常" + "zskClassify:" + JSON.toJSONString(zskClassify));
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			zskClassify.setOrgId(orgId);
			// 同一个商户下classifyName不能重复
			Boolean flag = isRepeat(zskClassify);
			if (flag) {
				logger.error("新增分类错误信息：" + "同一个商户下classifyName不能重复");
				return WebUtils.createErrorResult(ResponseEnum.THE_SAME_CLASSIFY_NAME);
			}
			zskClassify.setCreatedBy(mchtUser.getUserName());
			zskClassify.setCreatedDate(new Date());
			zskClassify.setUpdatedBy(mchtUser.getUserName());
			zskClassify.setUpdatedDate(new Date());
			knowledgeBaseService.addClassify(zskClassify);
			logger.debug("新增分类成功");
			return WebUtils.createSuccResult();
		} catch (ServiceException e) {
			logger.error("新增分类错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.WRITE_CSV_FILE_FAILED);
		} catch (Exception e) {
			logger.error("新增分类错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	// 验证classifyName是否重复
	public Boolean isRepeat(ZskClassify zskClassify) {
		Boolean flag = false;
		List<ZskClassify> list = knowledgeBaseService.selectClassifyList(zskClassify);
		if (list != null && list.size() > 0) {
			flag = true;
		}
		return flag;
	}

	/**
	 * 更新分类
	 * 
	 * @param request
	 * @param zskClassify
	 * @return JSONObject
	 */
	@RequestMapping("/classify/update")
	@ResponseBody
	public JSONObject updateClassify(HttpServletRequest request, ZskClassify zskClassify) {
		try {
			if (StringUtils.isBlank(zskClassify.getClassifyName()) || null == zskClassify.getZskClassifyId()) {
				logger.error("参数异常" + "zskClassify:" + JSON.toJSONString(zskClassify));
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			zskClassify.setOrgId(orgId);
			// 同一个商户下classifyName不能重复
			Boolean flag = isRepeat(zskClassify);
			if (flag) {
				logger.error("更新分类错误信息：" + "同一个商户下classifyName不能重复");
				return WebUtils.createErrorResult(ResponseEnum.THE_SAME_CLASSIFY_NAME);
			}
			List<Integer> zskClassifyIdList = selectZskClassifyIdListByOrgId(orgId);
			if (!isBelong(zskClassifyIdList, zskClassify.getZskClassifyId())) {
				logger.error("该用户只能修改属于自己知识库分类" + "orgId" + orgId);
				return WebUtils.createErrorResult(ResponseEnum.CAN_NOT_DELETE);
			}
			zskClassify.setUpdatedBy(mchtUser.getUserName());
			zskClassify.setUpdatedDate(new Date());
			knowledgeBaseService.updateClassify(zskClassify);
			logger.debug("更新分类成功");
			return WebUtils.createSuccResult();
		} catch (ServiceException e) {
			logger.error("更新分类错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.WRITE_CSV_FILE_FAILED);
		} catch (Exception e) {
			logger.error("更新分类错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	/**
	 * 删除分类
	 * 
	 * @param request
	 * @param zskClassifyId
	 * @return JSONObject
	 */
	@RequestMapping("/classify/delete")
	@ResponseBody
	public JSONObject deleteClassify(HttpServletRequest request, Integer zskClassifyId) {
		try {
			if (null == zskClassifyId) {
				logger.error("参数异常" + "zskClassifyId:" + JSON.toJSONString(zskClassifyId));
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			List<Integer> zskClassifyIdList = selectZskClassifyIdListByOrgId(orgId);
			Boolean flag = isBelong(zskClassifyIdList, zskClassifyId);
			if (!flag) {
				logger.error("该用户只能删除属于自己知识库分类" + "orgId" + orgId + "zskClassifyId:" + zskClassifyId);
				return WebUtils.createErrorResult(ResponseEnum.CAN_NOT_DELETE);
			}
			MchtCorpusCtx mchtCorpusCtx = new MchtCorpusCtx();
			mchtCorpusCtx.setZskClassifyId(zskClassifyId);
			mchtCorpusCtx.setOrgId(orgId);
			if (isHasRelate(mchtCorpusCtx)) {
				logger.error("该zskClassifyId在商户语料表中有对应的数据，不能删除！" + "orgId" + orgId + "zskClassifyId:" + zskClassifyId);
				return WebUtils.createErrorResult(ResponseEnum.THIS_ZSK_CLASSIFY_CAN_NOT_BE_DELETED);
			}
			knowledgeBaseService.deleteClassify(mchtCorpusCtx);
			logger.debug("删除分类成功" + zskClassifyId);
			return WebUtils.createSuccResult();
		} catch (ServiceException e) {
			logger.error("删除分类错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.WRITE_CSV_FILE_FAILED);
		} catch (Exception e) {
			logger.error("删除分类错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	// 根据orgId获取知识库分类表主键list
	private List<Integer> selectZskClassifyIdListByOrgId(Integer orgId) {
		List<ZskClassify> zskClassifyList = knowledgeBaseService.selectZskClassifyListByOrgId(orgId);
		List<Integer> zskClassifyIdList = new ArrayList<Integer>();
		for (ZskClassify zskClassify : zskClassifyList) {
			zskClassifyIdList.add(zskClassify.getZskClassifyId());
		}
		return zskClassifyIdList;
	}

	// 判断zskClassifyId属于该在orgId
	private Boolean isBelong(List<Integer> zskClassifyIdList, Integer zskClassifyId) {
		Boolean flag = false;
		if (null != zskClassifyIdList && zskClassifyIdList.size() > 0 && zskClassifyIdList.contains(zskClassifyId)) {
			flag = true;
		}
		return flag;
	}

	// 判断zskClassifyId在商户语料表中是否有对应的数据
	private Boolean isHasRelate(MchtCorpusCtx mchtCorpusCtx) {
		Boolean flag = false;
		List<MchtCorpusCtx> mchtCorpusCtxList = knowledgeBaseService.selectMchtCorpusCtxList(mchtCorpusCtx);
		if (null != mchtCorpusCtxList && mchtCorpusCtxList.size() > 0) {
			flag = true;
		}
		return flag;
	}

	/**
	 * 获取分类详细
	 * 
	 * @param request
	 * @param zskClassifyId
	 * @return JSONObject
	 */
	@RequestMapping("/classify/update/detail")
	@ResponseBody
	public JSONObject detailClassify(HttpServletRequest request, Integer zskClassifyId) {
		try {
			if (null == zskClassifyId) {
				logger.error("参数异常" + "zskClassifyId:" + JSON.toJSONString(zskClassifyId));
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			List<Integer> zskClassifyIdList = selectZskClassifyIdListByOrgId(orgId);
			Boolean flag = isBelong(zskClassifyIdList, zskClassifyId);
			if (!flag) {
				logger.error("该用户只能查询属于自己知识库分类" + "orgId" + orgId + "zskClassifyId:" + zskClassifyId);
				return WebUtils.createErrorResult(ResponseEnum.CAN_NOT_DELETE);
			}
			ZskClassify zskClassify = knowledgeBaseService.detailClassify(zskClassifyId);
			return WebUtils.createSuccResult(zskClassify);
		} catch (Exception e) {
			logger.error("获取分类详细错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	/**
	 * 分类查询
	 * 
	 * @param request
	 * @param zskClassifyPageDTO
	 * @return JSONObject
	 */
	@RequestMapping("/classify/query")
	@ResponseBody
	public JSONObject queryClassifyList(HttpServletRequest request, ZskClassifyPageDTO zskClassifyPageDTO) {
		try {
			// if (StringUtils.isBlank(zskClassifyPageDTO.getClassifyName())) {
			// logger.error("参数异常" + "zskClassify:" +
			// JSON.toJSONString(zskClassifyPageDTO));
			// return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			// }
			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			zskClassifyPageDTO.setOrgId(orgId);
			PageInfo<ZskClassify> zskClassifyPageList = knowledgeBaseService.queryClassifyList(zskClassifyPageDTO);
			Map<String, Object> data = Maps.newHashMap();
			data.put("list", zskClassifyPageList.getList());
			data.put("currentPage", zskClassifyPageList.getPageNum());
			data.put("totalCount", zskClassifyPageList.getTotal());
			return WebUtils.createSuccResult(data);
		} catch (Exception e) {
			logger.error("分类查询错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

}
