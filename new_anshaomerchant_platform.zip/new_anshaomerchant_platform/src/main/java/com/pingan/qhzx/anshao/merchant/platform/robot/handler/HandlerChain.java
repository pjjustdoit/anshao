package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.pingan.qhzx.anshao.merchant.platform.robot.biz.QaCaller;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;

import java.util.List;

/**
 * Created by yuzilei022 on 16/9/26.
 */
public class HandlerChain {
    private final List<Handler> handlers;
    private final QaCaller caller;
    private int curIndex = 0;

    public HandlerChain(List<Handler> handlers, QaCaller caller) {
        this.handlers = handlers;
        this.caller = caller;
    }

    public void nextHandle(Request request, Response response) {
        while (true) {
            if (this.curIndex != this.handlers.size()) {
                Handler handler = this.handlers.get(this.curIndex++);
                handler.doHandler(request, response, this);
                return;
            }
            // chain top
            caller.doFinal(request, response);
            return;
        }
    }
}
