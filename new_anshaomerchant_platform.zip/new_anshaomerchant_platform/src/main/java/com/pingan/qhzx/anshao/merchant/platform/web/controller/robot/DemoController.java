package com.pingan.qhzx.anshao.merchant.platform.web.controller.robot;

import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Charsets;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.google.common.hash.HashCode;
import com.google.common.hash.Hashing;
import com.paic.mock.web.MockHttpServletRequest;
import com.pingan.qhzx.anshao.merchant.platform.robot.IRobotFacade;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import com.pingan.qhzx.anshao.platform.common.web.common.CommonController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by yuzilei022 on 16/10/17.
 */
@Controller
@RequestMapping("/mcht/robot")
public class DemoController extends CommonController {
    private static final Logger logger = LoggerFactory.getLogger(DemoController.class);
    @Autowired
    private IRobotFacade robotFacade;
    @Value("${mcht.demo.orgCode}")
    private String orgCode;
    @Value("${mcht.demo.authCode}")
    private String authCode;

    @RequestMapping("/demo")
    @ResponseBody
    public JSONObject demo(Request req, HttpServletRequest request) {
        req.setOrgCode(orgCode);
        req.setCustId("1");
        req.setQuestionNo(System.currentTimeMillis() + "");
        final Map<String, String> map = Maps.newTreeMap();
        MockHttpServletRequest mockHttpServletRequest = new MockHttpServletRequest(request.getServletContext(), "POST", request.getRequestURI()) {

            @Override
            public Map getParameterMap() {
                return Maps.transformValues(map, new Function<String, String[]>() {
                    @Override
                    public String[] apply(String s) {
                        return new String[]{s};
                    }
                });
            }
        };

        map.put("orgCode", orgCode);
        map.put("questionNo", req.getQuestionNo());
        map.put("custId", "1");
        map.put("newSession", req.getNewSession().toString());
        map.put("version", "1");
        map.put("questionCtx", req.getQuestionCtx());
        StringBuilder sb = new StringBuilder(200);
        StringBuilder join = Joiner.on("&").withKeyValueSeparator("=").useForNull("").appendTo(sb, map).append(authCode);
        HashCode hashCode = Hashing.md5().hashString(join, Charsets.UTF_8);
        map.put("sign", hashCode.toString());
        for (Map.Entry<String, String> entry : map.entrySet()) {
            mockHttpServletRequest.addParameter(entry.getKey(), entry.getValue() == null ? "" : entry.getValue().toString());
        }
        req.setRequest(mockHttpServletRequest);
        Response chat = robotFacade.chat(req);
        return chat.createJson();
    }
}
