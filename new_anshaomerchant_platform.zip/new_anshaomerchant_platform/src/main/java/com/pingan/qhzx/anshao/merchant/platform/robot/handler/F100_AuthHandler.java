package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.google.common.base.Charsets;
import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.google.common.hash.Hashing;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by yuzilei022 on 16/9/26.
 */
@Order(100)
public class F100_AuthHandler implements Handler {

    public static final Joiner.MapJoiner JOINER = Joiner.on("&").withKeyValueSeparator("=").useForNull("");

    private static final Logger logger = LoggerFactory.getLogger(F100_AuthHandler.class);

    public void doHandler(Request request, Response response, HandlerChain chain) {
        Org org = request.getOrg();
        if (!checkSign(request)) {
            response.setResponseEnum(ResponseEnum.ORG_AUTH_FAILURE);
            return;
        }
        if ("2".equals(org.getOrgStatus()) || DateTime.now().isAfter(new DateTime(org.getExpireDate()))) {
            response.setResponseEnum(ResponseEnum.ORG_INVALID);
            return;
        }
        chain.nextHandle(request, response);
    }

    private boolean checkSign(Request request) {
        String sign = calcSign(request.getRequest(), request.getOrg());
        String actual = request.getRequest().getParameter("sign");
        boolean equals = StringUtils.equals(actual, sign);
        if (!equals) {
            logger.info("sign is {} ,Actual：{}", sign, actual);
        }
        return equals;
    }

    private String calcSign(HttpServletRequest request, Org org) {
        Map<String, String> map = buildParamsMap(request);
        // sort params&values
        StringBuilder queryString = buildQueryString(map).append(org.getAuthCode());
        logger.info("queryString={}", queryString);
        String md5Str = Hashing.md5().hashString(queryString.toString(), Charsets.UTF_8).toString();
        return md5Str;
    }

    private Map<String, String> buildParamsMap(HttpServletRequest request) {
        Map<String, String> map = Maps.newTreeMap();
        for (Map.Entry<String, String[]> stringEntry : request.getParameterMap().entrySet()) {
            if ("sign".equals(stringEntry.getKey())) {
                continue;
            }
            String paramValue = stringEntry.getValue()[0];
            if (paramValue.length() != 0) {
                map.put(stringEntry.getKey(), paramValue);
            } else {
                map.put(stringEntry.getKey(), "");
            }
        }
        return map;
    }

    private StringBuilder buildQueryString(Map<String, String> map) {
        StringBuilder queryString = new StringBuilder(200);
        JOINER.appendTo(queryString, map);
        return queryString;
    }
}
