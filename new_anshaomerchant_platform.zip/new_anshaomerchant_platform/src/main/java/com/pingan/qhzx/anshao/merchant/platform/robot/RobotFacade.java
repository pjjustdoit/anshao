package com.pingan.qhzx.anshao.merchant.platform.robot;

import com.pingan.qhzx.anshao.merchant.platform.robot.biz.IHandlerFactory;
import com.pingan.qhzx.anshao.merchant.platform.robot.biz.QaCaller;
import com.pingan.qhzx.anshao.merchant.platform.robot.handler.HandlerChain;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by yuzilei022 on 16/9/26.
 */
@Component
public class RobotFacade implements IRobotFacade {

    @Autowired
    private IHandlerFactory filterFactory;

    @Autowired
    private QaCaller caller;

    @Override
    public Response chat(Request request) {
        Response response = new Response();
        HandlerChain chain = filterFactory.createChain(caller);
        chain.nextHandle(request, response);
        return response;
    }

}
