package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.pingan.pafa.redis.cache.RedisCache;
import com.pingan.pafa.redis.map.RedisMapBean;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.AnswerParser;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import com.pingan.qhzx.anshao.platform.common.service.traffic.ITrafficService;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;

/**
 * Created by yuzilei022 on 16/10/14.
 */
@Order(180)
public class F180_UnKnownRecHandler implements Handler {

    private static final Logger logger = LoggerFactory.getLogger(F180_UnKnownRecHandler.class);

    @Autowired
    @Qualifier("unknownQaMap")
    private RedisMapBean<String, AnswerParser> unknownQaMap;
    @Autowired
    private ITrafficService trafficService;

    @Value("${user.answer.timeout}")
    private Integer answerTimeout;

    @Value("${user.answer.timeoutMax}")
    private Integer answerTimeoutMax;

    @Autowired
    @Qualifier("multiAnswerCache")
    private RedisCache<AnswerParser> cacheBean;

    @Override
    public void doHandler(Request request, Response response, HandlerChain chain) {
        AnswerParser parser = unknownQaMap.get(buildKey(request));
        if (parser != null) {
            if (isAnswerTimeout(parser)) { //回答超时
                trafficService.recUnknownQa(parser, "timeout");
                request.setNewSession(true);
                unknownQaMap.remove(buildKey(request));
                return;
            }
            if (notSelectQuestion(request, parser)) {//未命中
                trafficService.recUnknownQa(parser, "unselected");
                response.setAnswer(request.getMchtRobot().getDefaultAnswer());
                unknownQaMap.remove(buildKey(request));
                return;
            }
            if (isOverMaxTimeout(parser)) {
                trafficService.recUnknownQa(parser, "timeout");
            }
        }
        callNextHandler(request, response, chain);
    }

    private boolean isOverMaxTimeout(AnswerParser parser) {
        DateTime lastAnswerTime = new DateTime(parser.getAnswerDate());
        return lastAnswerTime.plusSeconds(answerTimeoutMax).isBeforeNow();
    }

    private void callNextHandler(Request request, Response response, HandlerChain chain) {
        chain.nextHandle(request, response);
        putCurrentQa2Cache(request);
    }

    private void putCurrentQa2Cache(Request request) {
        AnswerParser answerParser = cacheBean.get(buildKey(request));
        if (answerParser != null && answerParser.isMulti()) {
            unknownQaMap.put(buildKey(request), answerParser);
            return;
        }
        unknownQaMap.remove(buildKey(request));
    }

    private boolean notSelectQuestion(Request request, AnswerParser parser) {
        return isAnswerLastQa(parser) && !parser.hasAnswer(request.getQuestionCtx());
    }

    /**
     * 判断是否在时效内<5秒
     *
     * @param parser
     * @return
     */
    private boolean isAnswerLastQa(AnswerParser parser) {
        DateTime lastAnswerTime = new DateTime(parser.getAnswerDate());
        return lastAnswerTime.plusSeconds(answerTimeout).isAfterNow();
    }

    /**
     * 在5秒与半小时之间
     *
     * @param parser
     * @return
     */
    private boolean isAnswerTimeout(AnswerParser parser) {
        DateTime lastAnswerTime = new DateTime(parser.getAnswerDate());
        return lastAnswerTime.plusSeconds(answerTimeout).isBeforeNow() &&
                lastAnswerTime.plusSeconds(answerTimeoutMax).isAfterNow();
    }

    private String buildKey(Request request) {
        return request.getOrgCode() + ":" + request.getCustId();
    }
}
