package com.pingan.qhzx.anshao.merchant.platform.web.controller.wx.msg;

import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Charsets;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.google.common.hash.HashCode;
import com.google.common.hash.Hashing;
import com.paic.mock.web.MockHttpServletRequest;
import com.pingan.qhzx.anshao.merchant.platform.robot.IRobotFacade;
import com.pingan.qhzx.anshao.merchant.platform.web.common.AnshaoMerchPtCommonController;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import com.pingan.qhzx.anshao.platform.common.service.wxhome.IWxHomeService;
import com.pingan.qhzx.anshao.platform.common.utils.SignUtil;

/**
 * Created by peijian280 on 17/2/8.
 */
@Controller
@RequestMapping("/wx")
public class WxHomeController extends AnshaoMerchPtCommonController {
	
	private static final Logger log = LoggerFactory.getLogger(WxHomeController.class);
	
	@Autowired
	private IWxHomeService wxHomeService;
	
	@Autowired
    private IRobotFacade robotFacade;
    @Value("${mcht.demo.orgCode}")
    private String orgCode;
    @Value("${mcht.demo.authCode}")
    private String authCode;
	
	@RequestMapping(value="acceptMessage", method={RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public void acceptMessage(HttpServletRequest request, HttpServletResponse response) {
		log.info("entry wx chat, date:"+new Date());
		boolean isGet = request.getMethod().toLowerCase().equals("get");
		try {
			PrintWriter out = response.getWriter();
			if(isGet) {
				String wxVerifyResult = verifyToken(request);
				out.println(wxVerifyResult);
			} else {
				log.info("entry wx message");
				Map<String, String> acceptMessagemMap = wxHomeService.acceptMessage(request);
				String answer = invokeOpenDemo(request, acceptMessagemMap);
				String sendMessageXml = wxHomeService.sendMessage(acceptMessagemMap, answer);
				out.print(sendMessageXml);
			}
			out.close();
			out = null;
		} catch(Exception e) {
			log.error("error:"+e.getMessage());
		}
		log.info("entry wx chat end, date:"+new Date());
	}
	
	private String verifyToken(HttpServletRequest request) {
		// 微信加密签名  
        String signature = request.getParameter("signature");  
        // 时间戳  
        String timestamp = request.getParameter("timestamp");  
        // 随机数  
        String nonce = request.getParameter("nonce");  
        // 随机字符串  
        String echostr = request.getParameter("echostr");  
        //通过检验signature对请求进行校验，若校验成功则原样返回echostr，表示接入成功，否则接入失败
        if(SignUtil.checkSignature(signature, timestamp, nonce)) {
        	return echostr;
        }
        return "";
	}
	
	private String invokeOpenDemo(HttpServletRequest request, Map<String, String> acceptMessagemMap) {
		log.info("entry open demo");
		String content = acceptMessagemMap.get("Content");
		Map<String, String> contentMap = splitContent(content);
		Request req = new Request();
		if(contentMap.get("newSession").equals("true")) {
			req.setNewSession(true);
		} else {
			req.setNewSession(false);
		}
        req.setOrgCode(orgCode);
        req.setCustId("1");
        req.setQuestionNo(System.currentTimeMillis() + "");
        req.setQuestionCtx(contentMap.get("Content"));
        final Map<String, String> map = Maps.newTreeMap();
        MockHttpServletRequest mockHttpServletRequest = new MockHttpServletRequest(request.getServletContext(), "POST", request.getRequestURI()) {

            @Override
            public Map getParameterMap() {
                return Maps.transformValues(map, new Function<String, String[]>() {
                    @Override
                    public String[] apply(String s) {
                        return new String[]{s};
                    }
                });
            }
        };

        map.put("orgCode", orgCode);
        map.put("questionNo", req.getQuestionNo());
        map.put("custId", "1");
        map.put("newSession", contentMap.get("newSession"));
        map.put("version", "1");
        map.put("questionCtx", acceptMessagemMap.get("Content"));
        StringBuilder sb = new StringBuilder(200);
        StringBuilder join = Joiner.on("&").withKeyValueSeparator("=").useForNull("").appendTo(sb, map).append(authCode);
        HashCode hashCode = Hashing.md5().hashString(join, Charsets.UTF_8);
        map.put("sign", hashCode.toString());
        for (Map.Entry<String, String> entry : map.entrySet()) {
            mockHttpServletRequest.addParameter(entry.getKey(), entry.getValue() == null ? "" : entry.getValue().toString());
        }
        req.setRequest(mockHttpServletRequest);
        Response chat = robotFacade.chat(req);
        log.info("chat result:"+chat.createJson().toJSONString());
        String answer = chat.getAnswer();
        log.info("answer:"+answer);
        return answer;
	}
	
	//根据用户首次输入newSession必须true，后面都是false设定的
	private Map<String, String> splitContent(String content) {
		Map<String, String> map = Maps.newHashMap();
//		if(content.contains("@")) {
//			String[] str = content.split("@");
//			if(str.length>1) {
//				map.put("Content", str[0]);
//				map.put("newSession", str[1]);
//			} else {
//				map.put("Content", str[0]);
//				map.put("newSession", "false");
//			}
//			
//		} else {
//			map.put("Content", content);
//			map.put("newSession", "false");
//		}
		map.put("Content", content);
		map.put("newSession", "false");
		return map; 
	}

}
