//package com.pingan.qhzx.anshao.merchant.platform.robot.job;
//
//import com.paic.pafa.job.TimerJob;
//import com.pingan.pafa.redis.map.RedisMap;
//import com.pingan.qhzx.anshao.platform.common.job.BaseJob;
//import com.pingan.qhzx.anshao.platform.common.service.model.bean.AnswerParser;
//import com.pingan.qhzx.anshao.platform.common.service.traffic.ITrafficService;
//import org.joda.time.DateTime;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.beans.factory.annotation.Value;
//
//import java.util.Map;
//
///**
// * Created by yuzilei022 on 16/10/18.
// */
//public class AutoRecordUnknownQaJob extends BaseJob {
//
//
//    private static final Logger logger = LoggerFactory.getLogger(AutoRecordUnknownQaJob.class);
//    @Autowired
//    @Qualifier("unknownQaMap")
//    private RedisMap<String, AnswerParser> cacheBean;
//    @Autowired
//    private ITrafficService trafficService;
//
//    @Value("${user.answer.timeout}")
//    private Integer answerTimeout = 300;
//
//    @Override
//    protected void invoke() {
//        logger.info("===========启动未知问题写入数据库===========");
//        for (Map.Entry<String, AnswerParser> entry : cacheBean.entrySet()) {
//            AnswerParser parser = entry.getValue();
//            if (isAnswerTimeout(parser)) {
//                trafficService.recUnknownQa(parser, "timeout");
//                cacheBean.remove(entry.getKey());
//            }
//        }
//        logger.info("===========结束未知问题写入数据库===========");
//    }
//
//    private boolean isAnswerTimeout(AnswerParser parser) {
//        return new DateTime(parser.getAnswerDate()).plusSeconds(answerTimeout).isBeforeNow();
//    }
//
//    @TimerJob(cronExpression = "${job.AutoRecordUnknownQaJob.cron}")
//    @Override
//    public void execute() {
//        super.execute();
//    }
//}
