package com.pingan.qhzx.anshao.merchant.platform.web.controller.user;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.platform.common.web.common.controller.user.UserCommonController;
import com.pingan.qhzx.anshao.platform.common.web.form.RoleForm;

/**
 * Created by yuzilei869 on 16/7/21.
 */
@Controller
@RequestMapping("/mcht/user")
public class UserController extends UserCommonController {
	
	@RequestMapping("/upd/roleSelect")
	@ResponseBody
	public JSONObject updateUserRoleSelect(RoleForm roleForm, HttpServletRequest request) {
		return super.updateUserRoleSelect(roleForm, request);
	}

	@RequestMapping("/add/roleSelect")
	@ResponseBody
	public JSONObject addUserRoleSelect(RoleForm roleForm, HttpServletRequest request) {
		return super.updateUserRoleSelect(roleForm, request);
	}
	
	@RequestMapping("/add/org/select/list")
    @ResponseBody
	public JSONObject addSelectList(HttpServletRequest request) {
		return super.selectList(request);
	}
	
	@RequestMapping("/upd/org/select/list")
    @ResponseBody
	public JSONObject updSelectList(HttpServletRequest request) {
		return super.selectList(request);
	}
}
