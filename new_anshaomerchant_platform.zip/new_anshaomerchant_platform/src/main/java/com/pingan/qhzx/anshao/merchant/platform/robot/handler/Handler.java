package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;

/**
 * Created by yuzilei022 on 16/9/26.
 */
public interface Handler {

    void doHandler(Request request, Response response, HandlerChain chain);
}
