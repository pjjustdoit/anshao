//package com.pingan.qhzx.anshao.merchant.platform.robot.job;
//
//import com.paic.pafa.job.TimerJob;
//import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtCorpusCtxMapper;
//import com.pingan.qhzx.anshao.platform.common.dao.pg.OrgMapper;
//import com.pingan.qhzx.anshao.platform.common.job.BaseJob;
//
//import org.slf4j.Logger;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
///**
// * Created by zhangshan193 on 16/9/30.
// */
//@Component
//public class SetCorpusStatusJob extends BaseJob
//{
//    private static final Logger log = org.slf4j.LoggerFactory.getLogger(SetCorpusStatusJob.class);
//
//    @Autowired
//    private MchtCorpusCtxMapper mchtCorpusCtxMapper;
//
//    @TimerJob(cronExpression = "${job.SetCorpusStatusJob.cron}")
//    @Override
//    public void execute() {
//        super.execute();
//    }
//
//    @Override
//    protected void invoke() {
//        try {
//            log.info("****************updateCorpusStatus更新中*****************");
//            mchtCorpusCtxMapper.updateCorpusStatus("0");
//            log.info("****************updateCorpusStatus更新完成*****************");
//        } catch (Exception e) {
//            log.error("", e);
//        }
//    }
//}
