package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.alibaba.fastjson.JSON;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;

/**
 * Created by yuzilei022 on 16/9/26.
 */
@Order(20)
public class F020_LoggerHandler implements Handler {

    private static final Logger log = LoggerFactory.getLogger(F020_LoggerHandler.class);

    public void doHandler(Request request, Response response, HandlerChain chain) {
        log.info("[request]={}", JSON.toJSON(request));
        chain.nextHandle(request, response);
        log.info("[response]={}", JSON.toJSON(response));
    }
}
