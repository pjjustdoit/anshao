package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import org.springframework.core.annotation.Order;

/**
 * Created by yuzilei022 on 16/10/13.
 */
@Order(160)
public class F160_WelcomeHandler implements Handler {

    @Override
    public void doHandler(Request request, Response response, HandlerChain chain) {
        if (request.getNewSession()) {
            response.setAnswer(request.getMchtRobot().getWelcomeLang());
            return;
        }
        chain.nextHandle(request, response);
        if (request.getNewSession()) {
            response.setAnswer(request.getMchtRobot().getWelcomeLang());
            return;
        }
    }
}
