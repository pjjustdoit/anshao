package com.pingan.qhzx.anshao.merchant.platform.web.controller.role;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.platform.common.enums.DicCodeEnum;
import com.pingan.qhzx.anshao.platform.common.web.common.controller.role.RoleCommonController;
import com.pingan.qhzx.anshao.platform.common.web.form.RoleForm;

/**
 * Created by yuzilei869 on 16/7/21.
 */
@Controller
@RequestMapping("/mcht/role")
public class RoleController extends RoleCommonController {

	@RequestMapping("/add/role/info")
	@ResponseBody
	public JSONObject roleAddInfo(RoleForm roleForm, HttpServletRequest request) {
		roleForm.setOperateType(DicCodeEnum.OPERATE_TYPE_ADD.getCode());
		return super.roleInfo(roleForm, request);
	}

	@RequestMapping("/upd/role/info")
	@ResponseBody
	public JSONObject roleUpdInfo(RoleForm roleForm, HttpServletRequest request) {
		roleForm.setOperateType(DicCodeEnum.OPERATE_TYPE_UPD.getCode());
		return super.roleInfo(roleForm, request);
	}
	
    @RequestMapping("/add/org/select/list")
    @ResponseBody
	public JSONObject addSelectList(HttpServletRequest request) {
    	return super.selectList(request);
    }
    
    @RequestMapping("/upd/org/select/list")
    @ResponseBody
	public JSONObject updSelectList(HttpServletRequest request) {
    	return super.selectList(request);
    }
}
