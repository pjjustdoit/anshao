package com.pingan.qhzx.anshao.merchant.platform.web.controller.corpus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.merchant.platform.web.common.AnshaoMerchPtCommonController;
import com.pingan.qhzx.anshao.platform.common.bean.UserSessionBean;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusOutline;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;
import com.pingan.qhzx.anshao.platform.common.dto.pg.ZskClassify;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.IKnowledgeBaseService;
import com.pingan.qhzx.anshao.platform.common.service.corpus.IMchtCorpusService;
import com.pingan.qhzx.anshao.platform.common.service.model.CorpusSyncService;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;
import com.pingan.qhzx.anshao.platform.common.web.form.MchtCorpusCtxForm;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 语料控制器
 * Created by zhangshan193 on 16/9/30.
 */

@Controller
@RequestMapping("/mcht/zsk/corpus")
public class CorpusController extends AnshaoMerchPtCommonController {

    private static final Logger logger = LoggerFactory.getLogger(CorpusController.class);

    @Autowired
    private IMchtCorpusService mchtCorpusService;

    @Autowired
    private CorpusSyncService corpusSyncService;
    
	@Autowired
	private IKnowledgeBaseService knowledgeBaseService;

    /**
     * 语料汇总
     * @return
     */
    @RequestMapping("/stat")
    @ResponseBody
    public JSONObject stat(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request){
        if(mchtCorpusCtxForm == null  ){
            return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
        }
        Map<String,Object> resultMap = new HashedMap();

        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());
            MchtCorpusOutline mchtCorpusCtx = mchtCorpusService.getMchtCorpusOutlineByOrgId(mchtCorpusCtxForm.getOrgId());
            if(mchtCorpusCtx == null){
                resultMap.put("corpusInitNum", 0);
                resultMap.put("corpusTotalNum", 0);
                resultMap.put("corpusSurplusNum", 0);
                resultMap.put("corpusUseNum", 0);
            }else {
                resultMap.put("corpusInitNum", mchtCorpusCtx.getCorpusInitNum());
                resultMap.put("corpusTotalNum", mchtCorpusCtx.getCorpusTotalNum());
                resultMap.put("corpusSurplusNum", mchtCorpusCtx.getCorpusSurplusNum());
                resultMap.put("corpusUseNum", mchtCorpusCtx.getCorpususenum());
            }
            return WebUtils.createSuccResult(resultMap);
        }catch(Exception e){
            logger.error("stat occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.UNKNOWN_ERROR);
        }
    }

    /**
     * 新增语料
     * @param mchtCorpusCtxForm
     * @return
     */
    @RequestMapping("/add")
    @ResponseBody
    public JSONObject add(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request){
        if(mchtCorpusCtxForm == null  ){
            return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
        }
        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());
            mchtCorpusCtxForm.setCreatedBy(userSessionBean.getLoginName());
            mchtCorpusCtxForm.setUpdatedBy(userSessionBean.getLoginName());           
            JSONObject result = mchtCorpusService.addCorpus(mchtCorpusCtxForm);
            
            corpusSyncService.syncCorpus(userSessionBean.getOrgId());
            return result;
        }catch (IllegalArgumentException e){
            logger.error("add occured illegal argument exception,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.EXPIRE_DATE_ILLEGAL);
        }catch(Exception e){
            logger.error("add occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.UNKNOWN_ERROR);
        }

    }


    /**
     * 批量更新语料
     * @param mchtCorpusCtxForm
     * @return
     */
    @RequestMapping("/batchUpdate")
    @ResponseBody
    public JSONObject batchUpdate(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request){
        if(mchtCorpusCtxForm == null  ){
            return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
        }
        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setCreatedBy(userSessionBean.getLoginName());
            mchtCorpusCtxForm.setUpdatedBy(userSessionBean.getLoginName());
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());

            JSONObject result = mchtCorpusService.batchUpdate(mchtCorpusCtxForm);
            corpusSyncService.syncCorpus(userSessionBean.getOrgId());
            return result;

        }catch(Exception e){
            logger.error("batchUpdate occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.UNKNOWN_ERROR);
        }

    }

    /**
     * 更新语料
     * @param mchtCorpusCtxForm
     * @return
     */
    @RequestMapping("/update")
    @ResponseBody
    public JSONObject update(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request){
        if(mchtCorpusCtxForm == null  ){
            return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
        }
        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setCreatedBy(userSessionBean.getLoginName());
            mchtCorpusCtxForm.setUpdatedBy(userSessionBean.getLoginName());
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());
            
            JSONObject result = mchtCorpusService.update(mchtCorpusCtxForm);
            corpusSyncService.syncCorpus(userSessionBean.getOrgId());
            return result;
        }catch(Exception e){
            logger.error("update occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.UNKNOWN_ERROR);
        }
    }

    /**
     * 删除语料
     * @param mchtCorpusCtxForm
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public JSONObject delete(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request){
        if(mchtCorpusCtxForm == null || mchtCorpusCtxForm.getMchtCorpusCtxId() == null ){
            return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
        }
        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setUpdatedBy(userSessionBean.getLoginName());
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());            
            
            JSONObject result = mchtCorpusService.delete(mchtCorpusCtxForm);
            corpusSyncService.syncCorpus(userSessionBean.getOrgId());
            return result;
        }catch(Exception e){
            logger.error("delete occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.UNKNOWN_ERROR);
        }
    }

    /**
     * 获取语料详情
     * @param mchtCorpusCtxForm
     * @return
     */
    @RequestMapping("/update/detail")
    @ResponseBody
    public JSONObject detail(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request){
        if(mchtCorpusCtxForm == null || mchtCorpusCtxForm.getMchtCorpusCtxId() == null ){
            return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
        }
        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());
            MchtCorpusCtx mchtCorpusCtx = mchtCorpusService.getMchtCorpusCtxById(mchtCorpusCtxForm.getMchtCorpusCtxId());
            return WebUtils.createSuccResult(mchtCorpusCtx);
        }catch(Exception e){
            logger.error("detail occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.UNKNOWN_ERROR);
        }
    }


    /**
     * 分类查询语料
     * @param mchtCorpusCtxForm
     * @return
     */
    @RequestMapping("/query")
    @ResponseBody
    public JSONObject query(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request){
        if(mchtCorpusCtxForm == null  ){
            return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
        }
        if(mchtCorpusCtxForm.getPageSize() == null || mchtCorpusCtxForm.getPageSize() == 0){
            mchtCorpusCtxForm.setPageSize(10);
        }
        if(mchtCorpusCtxForm.getCurrentPage() == null || mchtCorpusCtxForm.getCurrentPage() == 0){
            mchtCorpusCtxForm.setCurrentPage(1);
        }
        Map<String,Object> resultMap = null;
        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());
            resultMap = mchtCorpusService.selectByParams(mchtCorpusCtxForm);
        }catch(Exception e){
            logger.error("query occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.UNKNOWN_ERROR);
        }
        if(resultMap == null){
            resultMap = new HashMap<String,Object>();
        }
        return WebUtils.createSuccResult(resultMap);
    }

    
	/**
	 * 查询当前商户下的classifyList
	 * 
	 * @param request
	 * @return JSONObject
	 */
	@RequestMapping("/query/classify/list")
	@ResponseBody
	public JSONObject queryClassifylistByOrgId(HttpServletRequest request) {
		ZskClassify zskClassify = new ZskClassify();
		MchtUser mchtUser = getUserInfo(request).getMchtUser();
		Integer orgId = mchtUser.getOrgId();
		zskClassify.setOrgId(orgId);
		try {
			List<ZskClassify> list = knowledgeBaseService.selectClassifyList(zskClassify);
			Map<String, Object> data = Maps.newHashMap();
			data.put("list", list);
			logger.debug("分查询当前商户下的classifyList" + JSON.toJSONString(list));
			return WebUtils.createSuccResult(data);
		} catch (Exception e) {
			logger.error("查询当前商户下的classifyList错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

    /**
     * 批量导出语料
     * @param mchtCorpusCtxForm
     * @return
     */
    @RequestMapping("/exporter")
    public void exporter(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletResponse resonse,HttpServletRequest request){
        if(mchtCorpusCtxForm == null  ){
            logger.info("invalid params");
        }
        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());
            mchtCorpusService.exportByParams(mchtCorpusCtxForm,resonse);
        }catch(Exception e){
            logger.error("exporter occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
        }
    }

    /**
     * 批量导入语料
     * @param mchtCorpusCtxForm
     * @return
     */
    @RequestMapping("/importer")
    @ResponseBody
    public JSONObject importer(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request){
        if(mchtCorpusCtxForm == null  ){
            return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
        }
        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setUpdatedBy(userSessionBean.getLoginName());
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());
            
            JSONObject result = mchtCorpusService.importMchtCorpusCtx(mchtCorpusCtxForm,request);
            corpusSyncService.syncCorpus(userSessionBean.getOrgId());
            return result;
        }catch(Exception e){
            logger.error("importer occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.UNKNOWN_ERROR);
        }
    }

    /**
     * 下载导入失败语料
     * @param request
     * @param response
     */
    @RequestMapping("/importer/downloadFailedExcel")
    public void downloadFailedExcel(HttpServletRequest request,HttpServletResponse response){
        try{
            mchtCorpusService.downloadFailedExcel(request,response);
        }catch(Exception e){
            logger.error("downloadFailedExcel occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
        }
    }

    @RequestMapping("/status/change")
    @ResponseBody
    public JSONObject statusChange(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request){
        if(mchtCorpusCtxForm == null || mchtCorpusCtxForm.getMchtCorpusCtxId() == null || mchtCorpusCtxForm.getEffectiveFlag() == null){
            return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
        }
        try{
            UserSessionBean userSessionBean = getUserInfo(request);
            mchtCorpusCtxForm.setOrgId(userSessionBean.getOrgId());
            mchtCorpusCtxForm.setUpdatedBy(userSessionBean.getLoginName());
            mchtCorpusService.statusChange(mchtCorpusCtxForm);
            corpusSyncService.syncCorpus(userSessionBean.getOrgId());
            return WebUtils.createSuccResult();
        }catch(Exception e){
            logger.error("detail occured unknown error,{},{}",e.getMessage(),e);
            logger.error("{}",e);
            return WebUtils.createErrorResult(ResponseEnum.UNKNOWN_ERROR);
        }
    }
}
