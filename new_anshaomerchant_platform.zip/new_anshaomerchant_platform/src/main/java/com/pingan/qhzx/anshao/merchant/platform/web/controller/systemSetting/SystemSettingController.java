package com.pingan.qhzx.anshao.merchant.platform.web.controller.systemSetting;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.merchant.platform.web.common.AnshaoMerchPtCommonController;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtRobot;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.systemSetting.ISystemSettingService;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;

/**
 * 登录安少商户管理平台->系统设置
 * 
 * @author LIUPENGLIANG375 创建时间：2016年9月28日 下午4:03:11
 */
@Controller
@RequestMapping("/mcht/system")
public class SystemSettingController extends AnshaoMerchPtCommonController {

	@Autowired
	private ISystemSettingService systemSettingService;

	Logger logger = Logger.getLogger(SystemSettingController.class);

	// 从session获得MchtUser
	private MchtUser getMchtUser(HttpServletRequest request) {
		return getUserInfo(request).getMchtUser();
	}

	// 从session获得Org
	private Org getOrg(HttpServletRequest request) {
		return getUserInfo(request).getOrg();
	}

	/**
	 * 机器人配置Detail
	 * 
	 * @param request
	 * @return JSONObject
	 */
	@RequestMapping("/robotDetail")
	@ResponseBody
	public JSONObject robotDetail(HttpServletRequest request) {
		try {
			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			MchtRobot robotDetail = systemSettingService.robotDetail(orgId);
			if (robotDetail == null) {
				return WebUtils.createSuccResult(ResponseEnum.NO_ROBOT_SETTING);
			}
			return WebUtils.createSuccResult(robotDetail);
		} catch (Exception e) {
			logger.error("机器人配置Detail错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	/**
	 * 机器人设置(如果当前商户下没有机器人，新增一个。)
	 * 
	 * @param request
	 * @param mchtRobot
	 * @return JSONObject
	 */
	@RequestMapping("/robotSetting")
	@ResponseBody
	public JSONObject robotSetting(HttpServletRequest request, MchtRobot mchtRobot) {
		try {
			BigDecimal fuzzyMatchThreshold = mchtRobot.getFuzzyMatchThreshold();
			if (StringUtils.isBlank(mchtRobot.getRobotName()) || fuzzyMatchThreshold == null
					|| mchtRobot.getFuzzyMatchSwitch() == null || StringUtils.isBlank(mchtRobot.getWelcomeLang())
					|| StringUtils.isBlank(mchtRobot.getDefaultAnswer())) {
				logger.error("参数异常" + "orgPageDTO:" + JSON.toJSONString(mchtRobot));
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			// 模糊匹配阈值除以100再入库
			mchtRobot.setFuzzyMatchThreshold(fuzzyMatchThreshold.divide(new BigDecimal("100"), 2,
					RoundingMode.HALF_UP));
			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			MchtRobot robotDetail = systemSettingService.robotDetail(orgId);
			mchtRobot.setUpdatedBy(mchtUser.getUserName());
			mchtRobot.setUpdatedDate(new Date());

			// 如果当前商户下没有机器人，新增一个。
			if (robotDetail == null) {
				mchtRobot.setOrgId(orgId);
				mchtRobot.setRobotCode(getOrg(request).getOrgCode());
				mchtRobot.setCreatedBy(mchtUser.getUserName());
				mchtRobot.setCreatedDate(new Date());
				systemSettingService.createRobot(mchtRobot);
			} else {
				mchtRobot.setMchtRobotId(robotDetail.getMchtRobotId());
				systemSettingService.robotSetting(mchtRobot);
			}
			return WebUtils.createSuccResult();
		} catch (Exception e) {
			logger.error("机器人设置错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
}
