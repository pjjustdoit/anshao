package com.pingan.qhzx.anshao.merchant.platform.robot.biz;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.paic.pafa.appclient.ServiceResults;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.model.api.IAnsirAPI;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.AnswerParser;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by yuzilei022 on 16/9/27.
 */
@Component
public class QaCaller {
    private static final Logger logger = LoggerFactory.getLogger(QaCaller.class);
    @Autowired
    private IAnsirAPI api;

    public void doFinal(Request request, Response response) {
        logger.info("request[{}]={}", request.getSerialNo(), JSON.toJSONString(request));
        ServiceResults results = api.answer(createRequestMap(request));
        fillResponse(request, response, results);
        logger.info("response[{}]={}", request.getSerialNo(), JSON.toJSONString(response));
    }

    private Map<String, Object> createRequestMap(Request request) {
        Map<String, Object> maps = Maps.newHashMapWithExpectedSize(20);
        maps.put("userQuestion", request.getQuestionCtx());
        maps.put("accountId", request.getCustId());
        maps.put("questionId", request.getQuestionNo());
        // maps.put("questionFlag", request);
        // maps.put("questionFlagId", );
        maps.put("orgId", request.getOrgCode());
        maps.put("questionDate", request.getSubmitDate().getTime());
        maps.put("threshold", request.getMchtRobot().getFuzzyMatchThreshold());
        maps.put("fuzzyMatch", request.getMchtRobot().getFuzzyMatchSwitch() ? "1" : "0");
        return maps;
    }

    private void fillResponse(Request request, Response response, ServiceResults results) {
        AnswerParser answerParser = new AnswerParser(results, request);
        response.setAnswerParser(answerParser);
        if (answerParser.isSuccess()) {
            response.setAnswer(answerParser.getAnswer());
            return;
        }
        //error proc
        response.put("sourceMsg", answerParser.getCode() + "|" + answerParser.getMessage());
        QAErrorCode errorCode = QAErrorCode.resolve(answerParser.getCode());
        if (errorCode != null) {
            if (errorCode.isDefaultAnswer()) {
                response.setAnswer(request.getMchtRobot().getDefaultAnswer());
            }
            response.setResponseEnum(errorCode.getResponseEnum());
            return;
        }
        response.setResponseEnum(ResponseEnum.ANSIR_QA_ERROR);
        return;

    }


    enum QAErrorCode {
        RESULT_1("1", ResponseEnum.UNKNOWN_ERROR),//机构代码为空
        RESULT_4("4", ResponseEnum.UNKNOWN_ERROR),//内部错误
        RESULT_20000("20000", ResponseEnum.MODEL_NOT_EXISTS, true),//模型未创建
        ;

        static Map<String, QAErrorCode> errorCodeMap = Maps.newHashMapWithExpectedSize(QAErrorCode.values().length);

        static {
            for (QAErrorCode errorCode : QAErrorCode.values()) {
                errorCodeMap.put(errorCode.getCode(), errorCode);
            }
        }

        private String code;
        private ResponseEnum responseEnum;
        private boolean defaultAnswer;

        QAErrorCode(String code, ResponseEnum responseEnum) {
            this.code = code;
            this.responseEnum = responseEnum;
        }

        QAErrorCode(String code, ResponseEnum responseEnum, boolean defaultAnswer) {
            this.code = code;
            this.responseEnum = responseEnum;
            this.defaultAnswer = defaultAnswer;
        }

        public static QAErrorCode resolve(String code) {
            return errorCodeMap.get(code);
        }

        public String getCode() {
            return code;
        }

        public ResponseEnum getResponseEnum() {
            return responseEnum;
        }

        public boolean isDefaultAnswer() {
            return defaultAnswer;
        }
    }

}
