//package com.pingan.qhzx.anshao.merchant.platform.robot.job;
//
//import com.paic.pafa.job.TimerJob;
//import com.pingan.pafa.redis.lock.RedisLock;
//import com.pingan.pafa.redis.lock.RedisLockFactory;
//import com.pingan.pafa.redis.map.RedisMapBean;
//import com.pingan.qhzx.anshao.platform.common.job.BaseJob;
//import com.pingan.qhzx.anshao.platform.common.service.model.bean.QaCountBean;
//import com.pingan.qhzx.anshao.platform.common.service.traffic.ITrafficService;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.stereotype.Component;
//
//import java.util.Map;
//import java.util.Set;
//
///**
// * Created by yuzilei022 on 16/10/24.
// */
//@Component
//public class AutoDeductCacheTrafficJob extends BaseJob {
//
//    private static final Logger logger = LoggerFactory.getLogger(AutoDeductCacheTrafficJob.class);
//    @Autowired
//    @Qualifier("orgQaCounter")
//    private RedisMapBean<String, QaCountBean> orgQaCounter;
//
//    @Autowired
//    @Qualifier("lock_factory")
//    private RedisLockFactory lockFactory;
//
//    @Autowired
//    private ITrafficService trafficService;
//
//    @TimerJob(cronExpression = "${job.AutoDeductCacheTrafficJob.cron}")
//    @Override
//    public void execute() {
//        super.execute();
//    }
//
//    @Override
//    protected void invoke() {
//        Set<Map.Entry<String, QaCountBean>> entries = orgQaCounter.entrySet();
//        for (Map.Entry<String, QaCountBean> entry : entries) {
//            RedisLock lock = lockFactory.getLock("deduct:orgId:" + entry.getKey(), 600);
//            boolean b = lock.tryLock(500);
//            if (!b) {
//                continue;
//            }
//            try {
//                QaCountBean qaCountBean = orgQaCounter.get(entry.getKey());
//                logger.info("rec deduct ,org {} deduct:{},datetime:{}", entry.getKey(), qaCountBean.getCounter(), qaCountBean.getCreateDate());
//                if (qaCountBean.getCounter() > 0) {
//                    trafficService.updateOrgTrafficAndInitCache(Integer.valueOf(entry.getKey()), qaCountBean);
//                    orgQaCounter.put(entry.getKey(), qaCountBean);
//                }
//            } finally {
//                lock.unlock();
//            }
//
//        }
//    }
//}
