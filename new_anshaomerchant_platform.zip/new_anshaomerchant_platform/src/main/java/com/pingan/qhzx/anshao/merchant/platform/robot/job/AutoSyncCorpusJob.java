//package com.pingan.qhzx.anshao.merchant.platform.robot.job;
//
//import com.google.common.base.Function;
//import com.google.common.collect.Lists;
//import com.paic.pafa.job.TimerJob;
//import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
//import com.pingan.qhzx.anshao.platform.common.job.BaseJob;
//import com.pingan.qhzx.anshao.platform.common.service.IOrgService;
//import com.pingan.qhzx.anshao.platform.common.service.model.api.IAnsirAPI;
//import com.pingan.qhzx.anshao.platform.common.service.qa.IQuestionsAndAnswersService;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import java.util.List;
//
///**
// * Created by yuzilei022 on 16/10/11.
// */
//@Component
//public class AutoSyncCorpusJob extends BaseJob {
//    private static final Logger logger = LoggerFactory.getLogger(AutoSyncCorpusJob.class);
//    @Autowired
//    private IQuestionsAndAnswersService answersService;
//
//    @Autowired
//    private IOrgService orgService;
//
//    @Autowired
//    private IAnsirAPI api;
//
//    @Override
//    protected void invoke() {
//        logger.info("=========同步知识库开始==============");
//        List<Org> orgs = orgService.queryOrgInExpire();
//        for (Org org : orgs) {
//            logger.info("生成csv：{}", org.getOrgCode());
//            answersService.writerQAToCsv(org);
//        }
//        List<String> orgCodes = Lists.transform(orgs, new Function<Org, String>() {
//            @Override
//            public String apply(Org org) {
//                return org.getOrgCode();
//            }
//        });
//        logger.info("同步机构表：{}", orgCodes);
//        api.createModel(orgCodes);
//        logger.info("=========同步知识库结束==============");
//    }
//
//    @TimerJob(cronExpression = "${job.AutoSyncCorpusJob.cron}")
//    @Override
//    public void execute() {
//        super.execute();
//    }
//}
