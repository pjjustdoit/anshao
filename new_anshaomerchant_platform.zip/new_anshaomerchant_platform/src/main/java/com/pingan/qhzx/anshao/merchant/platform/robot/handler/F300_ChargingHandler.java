package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.pingan.pafa.redis.queue.RedisQueueBean;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.dto.pg.TrafficAccount;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import com.pingan.qhzx.anshao.platform.common.service.traffic.ITrafficService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;

import java.util.Date;

/**
 * Created by yuzilei022 on 16/10/18.
 */
@Order(300)
public class F300_ChargingHandler implements Handler {

    @Autowired
    @Qualifier("serialQueue")
    private RedisQueueBean<MchtTrafficSerial> serialRedisQueue;

    @Autowired
    private ITrafficService trafficService;

    @Override
    public void doHandler(Request request, Response response, HandlerChain chain) {
        //验证商户流量是否充足
        if (!validOrgTrafficEnough(request)) {
            response.setResponseEnum(ResponseEnum.AVAILABLE_TRAFFIC_NOT_ENOUGH);
            return;
        }
        chain.nextHandle(request, response);
        if (response.getAnswerParser().isSuccess()) {
            charging(request);
        }
    }

    private boolean validOrgTrafficEnough(Request request) {
        //后续优化从缓存中读取 流量信息
        Org org = request.getOrg();
        TrafficAccount account = trafficService.selectMchtTrafficAccountByOrgId(org.getOrgId());
        return account.getTrafficRemainNum() > 0;
    }

    /**
     * 计费
     *
     * @param request
     */
    private void charging(Request request) {
        MchtTrafficSerial serial = new MchtTrafficSerial();
        serial.setTargetId(request.getQaSerialId());
        serial.setCreatedBy(request.getOrgCode());
        Date now = new Date();
        serial.setCreatedDate(now);
        serial.setOrgId(request.getOrg().getOrgId());
        serial.setOccurDate(now);
        serial.setOccurNum(1l);
        serial.setSerialDesc("智能问答");
        serial.setSerialType("O");
        serial.setChargingStatus("0");
        serialRedisQueue.push(serial);
    }
}
