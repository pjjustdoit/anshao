package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtRobot;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.IOrgService;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import com.pingan.qhzx.anshao.platform.common.service.traffic.ITrafficService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;

import java.util.Date;

/**
 * Created by yuzilei022 on 16/9/26.
 */
@Order(10)
public class F010_InitHandler implements Handler {

    @Autowired
    private ITrafficService trafficService;
    @Autowired
    private IOrgService orgService;

    public void doHandler(Request request, Response response, HandlerChain chain) {
        String serialNo = generateTxnId();
        request.setSerialNo(serialNo);
        request.setSubmitDate(new Date());
        response.setSerialNo(serialNo);
        response.setAnswerDate(new Date());
        response.setCustId(request.getCustId());
        response.setQuestionCtx(request.getQuestionCtx());
        response.setQuestionNo(request.getQuestionNo());
        Org org = orgService.queryOrgByOrgCode(request.getOrgCode());
        if (org == null) {
            response.setResponseEnum(ResponseEnum.ORG_INVALID);
            return;
        }
        request.setOrg(org);
        MchtRobot mchtRobot = trafficService.selectRobotByOrgCode(request.getOrgCode());
        if (mchtRobot == null) {
            response.setResponseEnum(ResponseEnum.ROBOT_CONFIG_ERROR);
            return;
        }
        request.setMchtRobot(mchtRobot);
        chain.nextHandle(request, response);
    }

    private String generateTxnId() {
        return trafficService.generateSerialNo();
    }
}
