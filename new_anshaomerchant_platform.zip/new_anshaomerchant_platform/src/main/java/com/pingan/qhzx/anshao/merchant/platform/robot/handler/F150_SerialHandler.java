package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.pingan.qhzx.anshao.platform.common.dto.pg.QaSerial;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.AnswerParser;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import com.pingan.qhzx.anshao.platform.common.service.traffic.ITrafficService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;

import java.util.Date;

/**
 * Created by yuzilei022 on 16/9/26.
 */
@Order(150)
public class F150_SerialHandler implements Handler {

    @Autowired
    private ITrafficService trafficService;

    public void doHandler(Request request, Response response, HandlerChain chain) {
        Long qaSerialId = trafficService.selectQaSerialId();
        request.setQaSerialId(qaSerialId);
        chain.nextHandle(request, response);
        createSerial(request, response);
    }

    private void createSerial(Request request, Response response) {
        QaSerial qaSerial = createQASerial(request, response);
        trafficService.record(qaSerial);
    }

    private QaSerial createQASerial(Request request, Response response) {
        QaSerial qaSerial = new QaSerial();
        qaSerial.setQaSerialId(request.getQaSerialId());
        qaSerial.setOrgId(request.getOrg().getOrgId());
        qaSerial.setCustId(request.getCustId());
        qaSerial.setAnswer(response.getAnswer());
        Date now = new Date();
        qaSerial.setAnwserDate(now);
        qaSerial.setFuzzymatch(request.getMchtRobot().getFuzzyMatchSwitch() ? "1" : "0");
        qaSerial.setOrgCode(request.getOrgCode());
        qaSerial.setSerialNo(request.getSerialNo());
        qaSerial.setThreshold(request.getMchtRobot().getFuzzyMatchThreshold() + "");
        qaSerial.setQuestion(request.getQuestionCtx());
        qaSerial.setQuestionNo(request.getQuestionNo());
        qaSerial.setSubmitDate(request.getSubmitDate());
        AnswerParser answerParser = response.getAnswerParser();
        if (answerParser != null) {
            qaSerial.setAnsirMatchFlag(answerParser.isMatch());
            qaSerial.setResponseSource(answerParser.getSource());
        }
        qaSerial.setCreatedBy(request.getOrgCode());
        qaSerial.setUpdatedBy(request.getOrgCode());
        qaSerial.setCreatedDate(now);
        qaSerial.setUpdatedDate(now);
        return qaSerial;
    }
}
