package com.pingan.qhzx.anshao.merchant.platform.robot;

import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;

/**
 * Created by yuzilei022 on 16/10/13.
 */
public interface IRobotFacade {
    Response chat(Request request);
}
