package com.pingan.qhzx.anshao.merchant.platform.web.controller.user;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.platform.common.web.common.controller.user.LoginCommonController;
import com.pingan.qhzx.anshao.platform.common.web.form.PasswordForm;

/**
 * Created by yuzilei869 on 16/7/21.
 */
@Controller
@RequestMapping("/mcht/user")
public class LoginController extends LoginCommonController {

	@RequestMapping("/nologin/password/change")
	@ResponseBody
	public JSONObject changePwd(PasswordForm form, HttpServletRequest request) {
		return super.changePwd(form, request);
	}
}
