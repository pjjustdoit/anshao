package com.pingan.qhzx.anshao.merchant.platform.robot.handler;

import com.pingan.pafa.redis.cache.RedisCache;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.AnswerParser;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Request;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;

/**
 * Created by yuzilei022 on 16/9/29.
 */
@Order(200)
public class F200_MultiAnswerHandler implements Handler {

    @Autowired
    @Qualifier("multiAnswerCache")
    private RedisCache<AnswerParser> cacheBean;

    @Value("${user.answer.timeout}")
    private Integer answerTimeout;

    @Override
    public void doHandler(Request request, Response response, HandlerChain chain) {
        AnswerParser answerParser = cacheBean.get(buildKey(request));
        if (answerParser != null) {
            cacheBean.remove(buildKey(request));
            if (answerParser.hasAnswer(request.getQuestionCtx())) {
                response.setAnswer(answerParser.getAnswer());
                response.setResponseEnum(ResponseEnum.SUCCESS);
                return;
            }
        }
        chain.nextHandle(request, response);
        answerParser = response.getAnswerParser();
        if (null != answerParser && answerParser.isMulti()) {
            cacheBean.set(buildKey(request), answerParser, answerTimeout);
        }
    }

    private String buildKey(Request request) {
        return request.getOrgCode() + ":" + request.getCustId();
    }
}
