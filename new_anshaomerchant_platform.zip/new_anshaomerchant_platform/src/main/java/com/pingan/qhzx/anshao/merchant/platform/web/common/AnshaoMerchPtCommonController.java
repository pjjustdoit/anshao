package com.pingan.qhzx.anshao.merchant.platform.web.common;

import javax.servlet.http.HttpServletRequest;

import com.pingan.qhzx.anshao.platform.common.bean.UserSessionBean;
import com.pingan.qhzx.anshao.platform.common.utils.SessionUtils;
import com.pingan.qhzx.anshao.platform.common.web.common.CommonController;



/**
 * Created by yuzilei869 on 16/7/21.
 */

public abstract class AnshaoMerchPtCommonController extends CommonController {

	public UserSessionBean getUserInfo(HttpServletRequest request) {
		SessionUtils sessionUtils = new SessionUtils(request.getSession());
		return sessionUtils.getUserInfo();
	}

}
