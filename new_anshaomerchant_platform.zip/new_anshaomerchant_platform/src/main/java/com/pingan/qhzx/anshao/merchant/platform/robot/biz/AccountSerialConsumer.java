package com.pingan.qhzx.anshao.merchant.platform.robot.biz;

import com.alibaba.fastjson.JSON;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;
import com.pingan.pafa.redis.queue.ConsumeListener;
import com.pingan.pafa.redis.queue.RedisQueue;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerial;
import com.pingan.qhzx.anshao.platform.common.service.traffic.ITrafficService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Created by yuzilei022 on 16/10/10.
 */
@Service("accountSerialConsumer")
public class AccountSerialConsumer implements ConsumeListener<MchtTrafficSerial> {

    public static final Logger log = LoggerFactory.getLogger(AccountSerialConsumer.class);

    @Autowired
    private ITrafficService trafficService;
    @Autowired
    @Qualifier("lock_factory")
    private RedisLockFactory lockFactory;

    @Autowired
    @Qualifier("serialQueue")
    private RedisQueue<MchtTrafficSerial> serialRedisQueue;

    @Value("${account.consume.recThreshold}")
    private Integer recThreshold;

    @Override
    public void onReceiveMessages(MchtTrafficSerial mchtTrafficSerial) {
        RedisLock lock = lockFactory.getLock("deduct:orgId:" + mchtTrafficSerial.getOrgId(), 600);
        boolean b = lock.tryLock(500);
        if (!b) {
            serialRedisQueue.push(mchtTrafficSerial);
            return;
        }
        try {
            mchtTrafficSerial.setBeforeNum(0l);
            mchtTrafficSerial.setAfterNum(0l);
            trafficService.saveOrgTrafficSerial(mchtTrafficSerial, recThreshold);
        } catch (Exception e) {
            log.error("写入流水失败！" + JSON.toJSONString(mchtTrafficSerial), e);
            //serialRedisQueue.push(mchtTrafficSerial);
        } finally {
            lock.unlock();
        }
    }
}
