package com.pingan.qhzx.anshao.merchant.platform.web.controller.reportStatistics;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.merchant.platform.web.common.AnshaoMerchPtCommonController;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.dto.pg.QaSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.TrafficAccount;
import com.pingan.qhzx.anshao.platform.common.dto.reportStatistics.SelectTrafficDTO;
import com.pingan.qhzx.anshao.platform.common.dto.reportStatistics.SelectTrafficPageDTO;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.enums.SerialTypeEnum;
import com.pingan.qhzx.anshao.platform.common.service.qa.IQuestionsAndAnswersService;
import com.pingan.qhzx.anshao.platform.common.service.traffic.IReportStatisticsService;
import com.pingan.qhzx.anshao.platform.common.utils.ExcelExporterUtils;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;

/**
 * 登录安少商户管理平台->报表统计
 * 
 * @author LIUPENGLIANG375 创建时间：2016年10月9日 下午2:38:46
 */
@Controller
@RequestMapping("/mcht/traffic")
public class ReportStatisticsController extends AnshaoMerchPtCommonController {
	Logger logger = Logger.getLogger(ReportStatisticsController.class);
	@Value("${csv.qa.path}")
	private String filePath;
	@Autowired
	private IReportStatisticsService reportStatisticsService;

	@Autowired
	private IQuestionsAndAnswersService questionsAndAnswersService;

	// 从session获得MchtUser
	private MchtUser getMchtUser(HttpServletRequest request) {
		return getUserInfo(request).getMchtUser();
	}

	// 从session获得Org
	private Org getOrg(HttpServletRequest request) {
		return getUserInfo(request).getOrg();
	}

	/**
	 * 流量汇总查询
	 * 
	 * @param request
	 * @return JSONObject
	 */
	@RequestMapping("/stat")
	@ResponseBody
	public JSONObject selectTrafficAccount(HttpServletRequest request) {
		try {
			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			TrafficAccount trafficAccount = reportStatisticsService.selectTrafficAccount(orgId);
			return WebUtils.createSuccResult(trafficAccount);
		} catch (Exception e) {
			logger.error("流量汇总查询错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	/**
	 * 流量查询
	 * 
	 * @param HttpServletRequest
	 * @param SelectTrafficPageDTO
	 * @return JSONObject
	 */
	@RequestMapping("/query")
	@ResponseBody
	public JSONObject selectTrafficAccountListPage(HttpServletRequest request, SelectTrafficPageDTO selectTrafficPageDTO) {
		try {
			// 转换开始时间
			String startDate = selectTrafficPageDTO.getQueryStartDate();
			if (StringUtils.isNotBlank(startDate)) {
				selectTrafficPageDTO.setStartDate(strToDate(startDate));
			}

			// 转换结束时间
			String endDate = selectTrafficPageDTO.getQueryEndDate();
			if (StringUtils.isNotBlank(endDate)) {
				selectTrafficPageDTO.setEndDate(addOneDate(strToDate(endDate)));
			}
			String serialType = selectTrafficPageDTO.getSerialType();
			if (StringUtils.isNotBlank(serialType)) {
				if (!StringUtils.equals(serialType, "I") && !StringUtils.equals(serialType, "O")) {
					logger.error("参数异常" + "serialType只能是I或者O:" + serialType);
					return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
				}
			}

			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			selectTrafficPageDTO.setOrgId(orgId);
			PageInfo<MchtTrafficSerial> mchtTrafficSerialPageList = reportStatisticsService
					.selectMchtTrafficSerialListPage(selectTrafficPageDTO);
			List<MchtTrafficSerial> list = mchtTrafficSerialPageList.getList();
			Map<String, Object> data = Maps.newHashMap();
			data.put("list", list);
			data.put("currentPage", mchtTrafficSerialPageList.getPageNum());
			data.put("totalCount", mchtTrafficSerialPageList.getTotal());
			return WebUtils.createSuccResult(data);
		} catch (Exception e) {
			logger.error("流量查询错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	// String类型的时间转换成Date类型
	private Date strToDate(String strDate) throws ParseException {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date date = df.parse(strDate);
		return date;
	}

	// 把日期往后增加一天
	private Date addOneDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		return calendar.getTime();
	}

	/**
	 * 流量导出
	 * 
	 * @param response
	 * @param request
	 * @param selectTrafficPageDTO
	 * @return JSONObject
	 */
	@RequestMapping("/exporter")
	@ResponseBody
	public JSONObject exporterTrafficAccountList(HttpServletResponse response, HttpServletRequest request,
			SelectTrafficDTO selectTrafficDTO) {
		try {
			// 转换开始时间
			String startDate = selectTrafficDTO.getQueryStartDate();
			if (StringUtils.isNotBlank(startDate)) {
				selectTrafficDTO.setStartDate(strToDate(startDate));
			}

			// 转换结束时间
			String endDate = selectTrafficDTO.getQueryEndDate();
			if (StringUtils.isNotBlank(endDate)) {
				selectTrafficDTO.setEndDate(addOneDate(strToDate(endDate)));
			}
			String serialType = selectTrafficDTO.getSerialType();
			if (StringUtils.isNotBlank(serialType)) {
				if (!StringUtils.equals(serialType, "I") && !StringUtils.equals(serialType, "O")) {
					logger.error("参数异常" + "serialType只能是I或者O:" + serialType);
					return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
				}
			}

			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			selectTrafficDTO.setOrgId(orgId);
			List<MchtTrafficSerial> mchtTrafficSerialList = reportStatisticsService
					.selectTrafficAccountList(selectTrafficDTO);
			for (MchtTrafficSerial mchtTrafficSerial : mchtTrafficSerialList) {
				String code = mchtTrafficSerial.getSerialType();
				SerialTypeEnum serialTypeEnum = SerialTypeEnum.getInstance(code);
				mchtTrafficSerial.setSerialType(serialTypeEnum.getDesc());
			}
			try {
				String excelName = "流量";
				ArrayList<ExcelExporterUtils.FiledDefine> objects = setTitleAndField();
				exportExcel(response, mchtTrafficSerialList, excelName, objects);
			} catch (IOException e) {
				logger.error("导出Excel错误信息：" + e.getMessage(), e);
				return WebUtils.createErrorResult(ResponseEnum.EXPORT_FILE_FAILED);
			}
			return null;
		} catch (Exception e) {
			logger.error("流量查询错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	// 设置导出流量Excel的标题和对应的字段
	public ArrayList<ExcelExporterUtils.FiledDefine> setTitleAndField() {
		ArrayList<ExcelExporterUtils.FiledDefine> objects = Lists.newArrayList(
				// 标题与字段一一对应
				new ExcelExporterUtils.FiledDefine("日期", "createdDate", ExcelExporterUtils.FiledType.DATE),
				new ExcelExporterUtils.FiledDefine("流量类型", "serialType", ExcelExporterUtils.FiledType.STRING),
				new ExcelExporterUtils.FiledDefine("数目", "occurNum", ExcelExporterUtils.FiledType.STRING),
				new ExcelExporterUtils.FiledDefine("描述", "serialDesc", ExcelExporterUtils.FiledType.STRING));
		return objects;
	}

	// 导出Excel
	public <T> void exportExcel(HttpServletResponse response, List<T> list, String excelName,
			ArrayList<ExcelExporterUtils.FiledDefine> objects) throws IOException {

		String fileName = createFileName(excelName);
		response.setContentType("applicatoin/octet-stream");
		ByteArrayOutputStream export = ExcelExporterUtils.export(list, objects);

		byte[] in = export.toByteArray();
		ServletOutputStream stream = response.getOutputStream();
		response.setHeader("Content-disposition", "attachment; filename="
				+ new String(fileName.getBytes("utf-8"), "ISO8859-1"));
		response.setHeader("Content-Length", String.valueOf(in.length));
		StreamUtils.copy(in, stream);
		stream.flush();
	}

	// 生成带时间戳的文件名称
	private String createFileName(String excelName) {
		StringBuilder sb = new StringBuilder(excelName);
		sb.append(DateTime.now().toString("yyyyMMddHHmmss")).append(".xls");
		return sb.toString();
	}

	/**
	 * 流量详细导出
	 * 
	 * @param response
	 * @param request
	 * @param selectTrafficDTO
	 * @return JSONObject
	 */
	@RequestMapping("/detailExporter")
	@ResponseBody
	public JSONObject detailExporter(HttpServletResponse response, HttpServletRequest request,
			SelectTrafficDTO selectTrafficDTO) {
		try {
			// 转换开始时间
			String startDate = selectTrafficDTO.getQueryStartDate();
			if (StringUtils.isNotBlank(startDate)) {
				selectTrafficDTO.setStartDate(strToDate(startDate));
			}

			// 转换结束时间
			String endDate = selectTrafficDTO.getQueryEndDate();
			if (StringUtils.isNotBlank(endDate)) {
				selectTrafficDTO.setEndDate(addOneDate(strToDate(endDate)));
			}

			MchtUser mchtUser = getMchtUser(request);
			Integer orgId = mchtUser.getOrgId();
			selectTrafficDTO.setOrgId(orgId);
			List<QaSerial> qaSerialList = reportStatisticsService.selectQaSerialList(selectTrafficDTO);
			try {
				String excelName = "流量详细";
				ArrayList<ExcelExporterUtils.FiledDefine> objects = setQaSerialTitleAndField();
				exportExcel(response, qaSerialList, excelName, objects);
			} catch (IOException e) {
				logger.error("导出Excel错误信息：" + e.getMessage(), e);
				return WebUtils.createErrorResult(ResponseEnum.EXPORT_FILE_FAILED);
			}
			return null;
		} catch (Exception e) {
			logger.error("流量详细查询错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	// 设置导出流量详情Excel的标题和对应的字段
	public ArrayList<ExcelExporterUtils.FiledDefine> setQaSerialTitleAndField() {
		ArrayList<ExcelExporterUtils.FiledDefine> objects = Lists.newArrayList(
				// 标题与字段一一对应
				new ExcelExporterUtils.FiledDefine("时间", "submitDate", ExcelExporterUtils.FiledType.DATE),
				new ExcelExporterUtils.FiledDefine("用户账号", "custId", ExcelExporterUtils.FiledType.STRING),
				new ExcelExporterUtils.FiledDefine("问题", "question", ExcelExporterUtils.FiledType.STRING),
				new ExcelExporterUtils.FiledDefine("答案", "answer", ExcelExporterUtils.FiledType.STRING));
		return objects;
	}

	@RequestMapping("stat/qaTest")
	@ResponseBody
	public JSONObject qaTest(HttpServletRequest request) {
		try {
			Org org = getOrg(request);
			questionsAndAnswersService.writerQAToCsv(org);
			return WebUtils.createSuccResult();
		} catch (Exception e) {
			logger.error("流量详细查询错误信息：" + e.getMessage(), e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
}
