package com.pingan.qhzx.anshao.merchant.platform.robot.biz;

import com.google.common.collect.Lists;
import com.google.common.reflect.ClassPath;
import com.pingan.qhzx.anshao.merchant.platform.robot.handler.Handler;
import com.pingan.qhzx.anshao.merchant.platform.robot.handler.HandlerChain;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.support.ApplicationObjectSupport;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * Created by yuzilei022 on 16/9/26.
 */
@Component
public class HandlerFactory extends ApplicationObjectSupport implements InitializingBean, IHandlerFactory {

    private List<Handler> handlers;

    public HandlerChain createChain(QaCaller caller) {
        return new HandlerChain(handlers, caller);
    }

    public void afterPropertiesSet() throws Exception {
        init();
        sort();
        autowire();
    }

    private void autowire() {
        AutowireCapableBeanFactory autowireCapableBeanFactory = this.getApplicationContext().getAutowireCapableBeanFactory();
        for (Handler handler : handlers) {
            autowireCapableBeanFactory.autowireBean(handler);
        }
    }

    private void sort() {
        Collections.sort(handlers, new Comparator<Handler>() {
            public int compare(Handler o1, Handler o2) {
                return getOrder(o1) - getOrder(o2);
            }

            private int getOrder(Handler o1) {
                Order order = o1.getClass().getAnnotation(Order.class);
                if (order != null) {
                    return order.value();
                }
                return 1000;
            }
        });
    }

    private void init() throws IOException, InstantiationException, IllegalAccessException {
        handlers = Lists.newArrayListWithCapacity(20);
        Set<ClassPath.ClassInfo> topLevelClassesRecursive = ClassPath.from(HandlerFactory.class.getClassLoader()).getTopLevelClassesRecursive("com.pingan.qhzx.anshao.merchant.platform.robot.handler");
        for (ClassPath.ClassInfo classInfo : topLevelClassesRecursive) {
            Class<?> load = classInfo.load();
            if (!load.isInterface() && Handler.class.isAssignableFrom(load)) {
                handlers.add((Handler) load.newInstance());
            }
        }
    }
}
