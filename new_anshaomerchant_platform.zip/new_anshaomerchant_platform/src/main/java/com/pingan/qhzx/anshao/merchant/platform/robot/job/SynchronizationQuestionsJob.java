//package com.pingan.qhzx.anshao.merchant.platform.robot.job;
//
//import com.paic.pafa.job.TimerJob;
//import com.pingan.qhzx.anshao.platform.common.bean.qa.SynchronizationQuestionBean;
//import com.pingan.qhzx.anshao.platform.common.dto.qa.SynchronizationQuestionDTO;
//import com.pingan.qhzx.anshao.platform.common.job.BaseJob;
//import com.pingan.qhzx.anshao.platform.common.service.model.api.IAnsirAPI;
//import com.pingan.qhzx.anshao.platform.common.service.qa.ISynchronizationQuestionService;
//import org.slf4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import java.util.Date;
//import java.util.List;
//
///**
// * 
// * @author LIUPENGLIANG375 创建时间：2016年10月17日 下午5:46:26
// */
//@Component
//public class SynchronizationQuestionsJob extends BaseJob {
//	private static final Logger log = org.slf4j.LoggerFactory.getLogger(SynchronizationQuestionsJob.class);
//
//	@Autowired
//	private ISynchronizationQuestionService synchronizationQuestionService;
//
//	@Autowired
//	private IAnsirAPI ansirAPI;
//
//	@TimerJob(cronExpression = "${job.SynchronizationQuestionsJob.cron}")
//	@Override
//	public void execute() {
//		super.execute();
//	}
//
//	@Override
//	protected void invoke() {
//		String syncStatus = "3";
//		Integer batchNo = -1;
//		try {
//			log.info("****************unknown question sync start*****************");
//			batchNo = synchronizationQuestionService.unknowQuestions();
//			List<SynchronizationQuestionBean> list = synchronizationQuestionService.seltQaSerListByOrgIdSerNo(batchNo);
//			Boolean flag = ansirAPI.ansirUnknowQuestionList(list);
//			if (flag) {
//				// 同步成功，状态改为"1"
//				syncStatus = "1";
//			}
//		} catch (Exception e) {
//			log.error("unknown question sync false", e);
//		} finally {
//			if (batchNo != -1) {
//				SynchronizationQuestionDTO synchronizationQuestionDTO = new SynchronizationQuestionDTO();
//				synchronizationQuestionDTO.setBatchNo(batchNo);
//				synchronizationQuestionDTO.setSyncStatus(syncStatus);
//				synchronizationQuestionDTO.setUpdatedDate(new Date());
//				synchronizationQuestionService.updateSyncSatuByBatchNo(synchronizationQuestionDTO);
//			}
//			log.info("****************unknown question sync end*****************");
//		}
//	}
//}
