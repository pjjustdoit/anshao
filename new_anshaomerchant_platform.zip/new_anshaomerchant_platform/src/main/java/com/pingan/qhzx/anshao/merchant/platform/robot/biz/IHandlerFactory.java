package com.pingan.qhzx.anshao.merchant.platform.robot.biz;

import com.pingan.qhzx.anshao.merchant.platform.robot.handler.HandlerChain;

/**
 * Created by yuzilei022 on 16/9/26.
 */
public interface IHandlerFactory {
    HandlerChain createChain(QaCaller caller);
}
