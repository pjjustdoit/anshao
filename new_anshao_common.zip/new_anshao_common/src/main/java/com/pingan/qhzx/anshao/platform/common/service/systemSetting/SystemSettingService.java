package com.pingan.qhzx.anshao.platform.common.service.systemSetting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtRobotMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtRobot;

@Service
public class SystemSettingService implements ISystemSettingService {

	@Autowired
	private MchtRobotMapper mchtRobotMapper;

	@Override
	public MchtRobot robotDetail(Integer orgId) {
		return mchtRobotMapper.selectMchtRobotByOrgId(orgId);
	}

	@Override
	public void robotSetting(MchtRobot mchtRobot) {
		mchtRobotMapper.updateByPrimaryKeySelective(mchtRobot);
	}

	@Override
	public void createRobot(MchtRobot mchtRobot) {
		mchtRobotMapper.insertSelective(mchtRobot);
	}
}
