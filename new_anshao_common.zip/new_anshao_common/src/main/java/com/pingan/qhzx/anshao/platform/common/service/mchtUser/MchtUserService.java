package com.pingan.qhzx.anshao.platform.common.service.mchtUser;

import java.text.MessageFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.base.Charsets;
import com.google.common.hash.Hashing;
import com.pingan.qhzx.anshao.platform.common.bean.ValidResult;
import com.pingan.qhzx.anshao.platform.common.bean.user.UserSearchCondition;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtUserAuthMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtUserMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtUserRoleMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtUserRoleRelMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.OrgMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserAuth;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRole;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRoleRel;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MenuDTO;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.enums.DicCodeEnum;
import com.pingan.qhzx.anshao.platform.common.enums.ForceChangePwdEnum;
import com.pingan.qhzx.anshao.platform.common.enums.OrgTypeEnum;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.IRedisService;
import com.pingan.qhzx.anshao.platform.common.service.mail.IMailService;

@Service
public class MchtUserService implements IMchtUserService {
	
	@Value("${mail.content}")
	private String mailContent;
	
	@Value("${mail.title}")
	private String mailTitle;
	
	@Value("${mail.cc}")
	private String mailCC;
	
	@Autowired
	private MchtUserMapper mchtUserMapper;
	
	@Autowired
	private MchtUserRoleMapper mchtUserRoleMapper;
	
	@Autowired
	private MchtUserAuthMapper mchtUserAuthMapper;
	
	@Autowired
	private MchtUserRoleRelMapper mchtUserRoleRelMapper;
	
	@Autowired
	private IMailService mailService;
	
	@Autowired
	private IRedisService redisService;
	
	@Autowired
	private OrgMapper orgMapper;
	
	protected static final int MAX_LOGIN_ERROR_TIME = 4;
	
	/**
	 * 
	 * @param loginName
	 * @return
	 */
	@Override
	public MchtUser queryUserByLoginName(String loginName) {
		return mchtUserMapper.selectByLoginName(loginName);
	}
	
	@Override
	public List<MchtUserRole> queryByUserIdOrgId(Integer mchtUserId, Integer orgId) {
		return mchtUserRoleMapper.selectByUserIdOrgId(mchtUserId, orgId);
	}
	
	@Override
	public List<MchtUserAuth> queryAuthByOrgIdMchtUserId(Integer orgId, Integer mchtUserId) {
		return mchtUserAuthMapper.selectAuthByOrgIdMchtUserId(orgId, mchtUserId);
	}

	@Override
	public List<MenuDTO> queryMenu(Integer mchtUserRoleId) {
		
		List<MenuDTO> mchtUserAuthList = mchtUserAuthMapper.selectMenuByMchtUserRoleId(mchtUserRoleId);
//		List<MenuDTO> MenuList = null;
//		if (mchtUserAuthList != null && mchtUserAuthList.size() > 0) {
//			MenuList = buildMenu(mchtUserAuthList);
//		}
		return mchtUserAuthList;
	}
	
	/**
	 * 
	 */
	@Override
	public List<MenuDTO> querySAInnerMenu(String roleCode) {
		List<MenuDTO> mchtUserAuthList = mchtUserAuthMapper.querySAInnerMenu(roleCode);
		return mchtUserAuthList;
	}

	@Override
	public List<MenuDTO> queryAllOutMenu() {
		List<MenuDTO> mchtUserAuthList = mchtUserAuthMapper.selectAllOutMenuBy(OrgTypeEnum.PARTNER.getCode());
//		List<MenuDTO> MenuList = null;
//		if (mchtUserAuthList != null && mchtUserAuthList.size() > 0) {
//			MenuList = buildMenu(mchtUserAuthList);
//		}
		return mchtUserAuthList;
	}
	
	/**
	 * 用户增加
	 * 
	 * 
	 */
	@Transactional
	@Override
	public ValidResult userAdd(MchtUser mchtUser, Integer mchtUserRoleId, String loginNameSession,
			String roleCodeSession, Integer orgIdSession) {
		
		String userPwd = null;
		
		if (!DicCodeEnum.SUPER_ROLE.getCode().equals(roleCodeSession)) {
			// 非超级用户只能创建所属的机构的角色
			if (orgIdSession != mchtUser.getOrgId()) {
				return ValidResult.createValidResult(ResponseEnum.CANNOT_OPERATE_ORG_USER);
			}
		} else {
			// 超级用户只能新建一个外部机构的管理员
			if(userPartnerAddFlg(mchtUser.getOrgId())) {
				return ValidResult.createValidResult(ResponseEnum.USER_PARTERN_ONLY_ONE);
			}
		}
		// 检测登录名重复
		if (checkRepeat(mchtUser.getMchtUserId(), mchtUser.getLoginName(), null)) {
			return ValidResult.createValidResult(ResponseEnum.USER_EXIST);
		}
		
		// 检测邮箱重复
		if (checkRepeat(mchtUser.getMchtUserId(), null, mchtUser.getUserEmail())) {
			return ValidResult.createValidResult(ResponseEnum.EMAIL_EXIST);
		}
		
		// 角色权限（只能是自己创建的角色）
		if (!checkUserRole(loginNameSession, mchtUserRoleId)) {
			return ValidResult.createValidResult(ResponseEnum.ROLE_AUTH_FAILURE);
		}
		
		// 查询机构
		Org org = orgMapper.selectByPrimaryKey(mchtUser.getOrgId());
		if (org == null) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}
		
		String createdBy = loginNameSession;
		Date createdDate = new Date();
		
	    
		
		if (OrgTypeEnum.INTERNAL.getCode().equals(org.getOrgType())) {
			// 内部机构用户
			mchtUser.setForceChangePwdFlag(ForceChangePwdEnum.NO.getCode());
			userPwd = "Hello1234";
		} else {
			// 外部合作伙伴用户
			mchtUser.setForceChangePwdFlag(ForceChangePwdEnum.YES.getCode());
			userPwd = RandomStringUtils.random(1, true, false) + RandomStringUtils.random(6, true, true)
					+ RandomStringUtils.random(1, false, true);
			// TODO 往初始化密码表插密码
			String mailcontent = MessageFormat.format(mailContent, mchtUser.getLoginName(), userPwd);

			mailService.mailListInsert(mchtUser.getUserEmail(), mailCC, "0", mailTitle, mailcontent, false, createdBy);
		}
		
		String userPwdMd5 = Hashing.md5().hashString(userPwd, Charsets.UTF_8).toString();
		
		// 创建用户
		mchtUser.setCreatedBy(createdBy);
		mchtUser.setUpdatedBy(createdBy);
		mchtUser.setCreatedDate(createdDate);
		mchtUser.setUpdatedDate(createdDate);
		mchtUser.setUserPwd(userPwdMd5);
		mchtUserMapper.insert(mchtUser);
		
		// 用户角色关系表
		MchtUserRoleRel mchtUserRoleRel = new MchtUserRoleRel();
		
		mchtUserRoleRel.setOrgId(mchtUser.getOrgId());
		mchtUserRoleRel.setMchtUserId(mchtUser.getMchtUserId());
		mchtUserRoleRel.setMchtUserRoleId(mchtUserRoleId);
		mchtUserRoleRel.setCreatedBy(createdBy);
		mchtUserRoleRel.setCreatedDate(createdDate);
		
		mchtUserRoleRelMapper.insert(mchtUserRoleRel);
		
		return ValidResult.createSuccessResult();
	}
	
	/**
	 * 用户编辑
	 * @param mchtUser
	 * @param mchtUserRoleId
	 * @param mchtUserIdSession
	 * @param roleCodeSession
	 * @param orgIdSession
	 * @return
	 */
	@Transactional
	@Override
	public ValidResult userUpd(MchtUser mchtUser, Integer mchtUserRoleId, String loginNameSession,
			String roleCodeSession, Integer orgIdSession) {

		if (!DicCodeEnum.SUPER_ROLE.getCode().equals(roleCodeSession)) {
			// 非超级用户只能编辑所属的机构的角色
			if (orgIdSession != mchtUser.getOrgId()) {
				return ValidResult.createValidResult(ResponseEnum.CANNOT_OPERATE_ORG_USER);
			}
		}

		MchtUser mchtUserSelect = mchtUserMapper.selectByPrimaryKey(mchtUser.getMchtUserId());
		if (mchtUserSelect == null) {
			// 用户不存在
			return ValidResult.createValidResult(ResponseEnum.USER_NOT_EXIST);
		}

		if (!loginNameSession.equals(mchtUserSelect.getCreatedBy())) {
			// 只能编辑自己创建的用户
			return ValidResult.createValidResult(ResponseEnum.USER_OPERATE_AUTH_FAILURE);
		}

		// 检测登录名重复
		if (checkRepeat(mchtUser.getMchtUserId(), mchtUser.getLoginName(), null)) {
			return ValidResult.createValidResult(ResponseEnum.USER_EXIST);
		}

		// 检测邮箱重复
		if (checkRepeat(mchtUser.getMchtUserId(), null, mchtUser.getUserEmail())) {
			return ValidResult.createValidResult(ResponseEnum.EMAIL_EXIST);
		}

		// 角色权限（只能是自己创建的角色）
		if (!checkUserRole(loginNameSession, mchtUserRoleId)) {
			return ValidResult.createValidResult(ResponseEnum.ROLE_AUTH_FAILURE);
		}
		String createdBy = loginNameSession;
		Date createdDate = new Date();
		// 编辑用户
		mchtUser.setUpdatedBy(createdBy);
		mchtUser.setUpdatedDate(createdDate);
		mchtUserMapper.updateByPrimaryKeySelective(mchtUser);
		
		// 删插
		mchtUserRoleRelMapper.deleteBy(mchtUser.getMchtUserId());
		
		MchtUserRoleRel mchtUserRoleRel = new MchtUserRoleRel();
		mchtUserRoleRel.setMchtUserId(mchtUser.getMchtUserId());
		mchtUserRoleRel.setMchtUserRoleId(mchtUserRoleId);
		mchtUserRoleRel.setOrgId(mchtUser.getOrgId());
		mchtUserRoleRel.setCreatedBy(createdBy);
		mchtUserRoleRel.setCreatedDate(createdDate);
		
		mchtUserRoleRelMapper.insert(mchtUserRoleRel);
		
		return ValidResult.createSuccessResult();
	}

	@Override
	public MchtUser queryUpdateSelectList(Integer mchtUserId) {
		return mchtUserMapper.queryUpdateSelectList(mchtUserId);
	}

	/**
	 * 用户列表
	 * 普通用户可查询到所属机构和自己创建的用户
	 * 超级用户可以查询到所有用户
	 * @param currentPage
	 * @param pageSize
	 * @param orgId
	 * @param loginNameSession
	 * @param roleCodeSession
	 */
	@Override
	public PageInfo<MchtUser> getMchtUserList(Integer currentPage, Integer pageSize, Integer orgId, String loginNameSession,
			String roleCodeSession, UserSearchCondition userSearchCondition) {
		PageHelper.startPage(currentPage, pageSize);
		List<MchtUser> mchtUserList = null;
		if (DicCodeEnum.SUPER_ROLE.getCode().equals(roleCodeSession)) {
			mchtUserList = mchtUserMapper.queryAllUserList(userSearchCondition);
		} else {
			userSearchCondition.setOrgId(orgId);
			userSearchCondition.setLoginNameSession(loginNameSession);
			mchtUserList = mchtUserMapper.queryUserList(userSearchCondition);
		}
		
		return new PageInfo<MchtUser>(mchtUserList);
	}

//	private List<MenuDTO> buildMenu(List<MchtUserAuth> mchtUserAuthList) {
//
//		List<MenuDTO> MenuDTOList = new ArrayList<MenuDTO>();
//
//		for (int i = 0; i < mchtUserAuthList.size(); i++) {
//			MchtUserAuth mchtUserAuth = mchtUserAuthList.get(i);
//			if (mchtUserAuth.getParentAuthId() == null) {
//				MenuDTO menuDTO = userAuthToMenu(mchtUserAuth);
//				Integer parentAuthId = menuDTO.getAuthId();
//				childMenu(mchtUserAuthList, parentAuthId, menuDTO);
//				MenuDTOList.add(menuDTO);
//			}
//		}
//
//		return MenuDTOList;
//	}
	
//	private MenuDTO childMenu(List<MchtUserAuth> mchtUserAuthList, Integer parentAuthId
//			, MenuDTO menuDTO) {
//		List<MenuDTO> childList = new ArrayList<MenuDTO>();
//		for (int i = 0; i < mchtUserAuthList.size(); i++) {
//			MchtUserAuth mchtUserAuth = mchtUserAuthList.get(i);
//			if (mchtUserAuth.getParentAuthId() == parentAuthId) {
//				MenuDTO child = userAuthToMenu(mchtUserAuth);
//				childMenu(mchtUserAuthList, child.getAuthId(), child);
//				childList.add(child);
//			}
//		}
//		menuDTO.setChild(childList);
//		return menuDTO;
//	}
	
//	private MenuDTO userAuthToMenu(MchtUserAuth mchtUserAuth) {
//		
//		MenuDTO menuDTO = new MenuDTO();
//		
//		menuDTO.setAuthId(mchtUserAuth.getMchtUserAuthId());
//		menuDTO.setAuthName(mchtUserAuth.getAuthName());
//		menuDTO.setAuthCtx(mchtUserAuth.getAuthCtx());
//		menuDTO.setOrderBy(mchtUserAuth.getOrderBy());
//		menuDTO.setParentAuthId(mchtUserAuth.getParentAuthId());
//		menuDTO.setAuthClass(mchtUserAuth.getAuthClass());
//		return menuDTO;
//	}

	@Override
	public ValidResult loginValidUser(String loginName, String password) {
		String identifier = null;
		MchtUser user = queryUserByLoginName(loginName);
		if (null == user) {
			return ValidResult.createValidResult(ResponseEnum.USER_NOT_EXIST);
		}
		identifier = user.getMchtUserId().toString() + user.getLoginName();
		// check password
		int errorTime = getLoginErrorTime(identifier);
		if (errorTime >= MAX_LOGIN_ERROR_TIME) {
			return ValidResult.createValidResult(ResponseEnum.LOGIN_PASSWORD_ERROR_LIMIT);
		}

		if (!StringUtils.equalsIgnoreCase(user.getUserPwd(), password)) {
			// wrong password,add error time
			errorTime = addLoginErrorTime(identifier);
			if (errorTime >= MAX_LOGIN_ERROR_TIME) {
				return ValidResult.createValidResult(ResponseEnum.LOGIN_PASSWORD_ERROR_LIMIT);
			}
			Map<String, String> map = new HashMap<String, String>();
			map.put("errorTime", String.valueOf(errorTime));
			return ValidResult.createValidResult(ResponseEnum.INVALID_LOGIN_PWD, map);
		}
		clearLoginErrorTime(identifier);
		ValidResult x = validUserState(user);
		if (!x.valid())
			return x;

		return new ValidResult().put("user", user);
	}

	protected Integer getLoginErrorTime(String identifier) {
		Integer errObj = redisService.getLoginErrorTimeCache().get(identifier);
		if (null == errObj) {
			return Integer.valueOf(0);
		}
		return Integer.parseInt(errObj.toString());
	}

	protected int addLoginErrorTime(String identifier) {
		int errTime = getLoginErrorTime(identifier);
		errTime++;
		redisService.getLoginErrorTimeCache().set(identifier, errTime);
		return errTime;
	}

	private void clearLoginErrorTime(String identifier) {
		redisService.getLoginErrorTimeCache().remove(identifier);
	}

	private ValidResult validUserState(MchtUser tUser) {
		
		if (!DicCodeEnum.USER_STATUS_WORKING.getCode().equals(tUser.getUserStatus())) {
			return ValidResult.createValidResult(ResponseEnum.USER_LEAVE_CANNOT_LOGIN);
		}
		
		if (ForceChangePwdEnum.YES.getCode().equals(tUser.getForceChangePwdFlag())) {
			return ValidResult.createValidResult(ResponseEnum.PWD_INITIAL_CHANGE);
		}
		return ValidResult.createValidResult(ResponseEnum.SUCCESS);
	}

	@Transactional
	@Override
	public ValidResult userStatusChange(Integer mchtUserId, String loginNameSession, String userStatus) {
		
		MchtUser mchtUser = mchtUserAuth(mchtUserId, loginNameSession);

		if (mchtUser == null) {
			return ValidResult.createValidResult(ResponseEnum.USER_OPERATE_AUTH_FAILURE);
		}

		Date updatedDate = new Date();
		mchtUser.setUserStatus(userStatus);
		mchtUser.setUpdatedBy(loginNameSession);
		mchtUser.setUpdatedDate(updatedDate);
		mchtUserMapper.updateByPrimaryKeySelective(mchtUser);
		
		return ValidResult.createSuccessResult();
	}
	
	@Transactional
	@Override
	public ValidResult userInitPwd(Integer mchtUserId, String loginNameSession) {
		MchtUser mchtUser = mchtUserAuth(mchtUserId, loginNameSession);
		if (mchtUser == null) {
			return ValidResult.createValidResult(ResponseEnum.USER_OPERATE_AUTH_FAILURE);
		}
		
		Org org = orgMapper.selectByUserId(mchtUserId);
		if (org == null) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}
		
		if (OrgTypeEnum.INTERNAL.getCode().equals(org.getOrgType())) {
			return ValidResult.createValidResult(ResponseEnum.USER_CAN_NOT_INIT_PWD);
		}
		
		String userPwd = RandomStringUtils.random(8, true, true);
		
		//TODO 往初始化密码表插密码
		String userPwdMd5 = Hashing.md5().hashString(userPwd, Charsets.UTF_8).toString();

		Date updatedDate = new Date();
		mchtUser.setForceChangePwdFlag(ForceChangePwdEnum.YES.getCode());
		mchtUser.setUserPwd(userPwdMd5);
		mchtUser.setUpdatedBy(loginNameSession);
		mchtUser.setUpdatedDate(updatedDate);
		mchtUserMapper.updateByPrimaryKeySelective(mchtUser);
		
		String mailcontent = MessageFormat.format(mailContent, mchtUser.getLoginName(), userPwd);
		
		mailService.mailListInsert(mchtUser.getUserEmail(), mailCC, "0",
				mailTitle, mailcontent, false, loginNameSession);
		
		return ValidResult.createSuccessResult();
	}
	
	@Override
	public MchtUser selectForPwdChange(String loginName, String password) {
		return mchtUserMapper.selectForPwdChange(loginName, password);
	}
	
	@Transactional
	@Override
	public void pwdChange(MchtUser user) {
		mchtUserMapper.updateByPrimaryKeySelective(user);
	}

	/**
	 * 判断用户是否有权限操作
	 * @return
	 */
	private MchtUser mchtUserAuth(Integer mchtUserId, String loginNameSession) {
		return mchtUserMapper.selectBy(mchtUserId, loginNameSession);
	}
	
	/**
	 * 检测重复
	 * @return
	 */
	private boolean checkRepeat(Integer mchtUserId, String loginName, String userEmail) {
		boolean result = false;
		MchtUser mchtUser = new MchtUser();
		mchtUser.setMchtUserId(mchtUserId);
		mchtUser.setLoginName(loginName);
		mchtUser.setUserEmail(userEmail);
		Long count = mchtUserMapper.checkRepeat(mchtUser);
		
		if (count > 0 ) {
			result = true;
		}
		return result;
	}
	
	/**
	 * 判断该角色是否是自己创建的
	 * @param loginNameSession
	 * @param mchtUserRoleId
	 * @return
	 */
	private boolean checkUserRole(String loginNameSession, Integer mchtUserRoleId) {
		boolean result = false;
		MchtUserRole mchtUserRole = mchtUserRoleMapper.selectByPrimaryKey(mchtUserRoleId);

		if (mchtUserRole != null) {
			if (mchtUserRole.getCreatedBy().equals(loginNameSession)) {
				result = true;
			}
		}
		return result;
	}
	
	/**
	 * 仅能给外部机构创建一个管理员用户
	 * 
	 * @return
	 */
	private boolean userPartnerAddFlg(Integer orgId) {
		boolean result = false;
		Long count = mchtUserMapper.queryUserPartnerCount(orgId);
		if (count > 0) {
			result = true;
		}
		return result;
	}
}
