package com.pingan.qhzx.anshao.platform.common.service.traffic;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.QaSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.TrafficAccount;
import com.pingan.qhzx.anshao.platform.common.dto.reportStatistics.SelectTrafficDTO;
import com.pingan.qhzx.anshao.platform.common.dto.reportStatistics.SelectTrafficPageDTO;

/**
 * 登录安少商户管理平台->报表统计
 * 
 * @author LIUPENGLIANG375 创建时间：2016年10月9日 下午2:46:43
 */
public interface IReportStatisticsService {

	/**
	 * 流量汇总查询
	 * 
	 * @param orgId
	 * @return TrafficAccount
	 */
	TrafficAccount selectTrafficAccount(Integer orgId);

	/**
	 * 流量查询(分页)
	 * 
	 * @param selectTrafficPageDTO
	 * @return PageInfo<MchtTrafficSerial>
	 */
	PageInfo<MchtTrafficSerial> selectMchtTrafficSerialListPage(SelectTrafficPageDTO selectTrafficPageDTO);

	/**
	 * 流量查询(不分页)
	 * 
	 * @param selectTrafficDTO
	 * @return List<MchtTrafficSerial>
	 */
	List<MchtTrafficSerial> selectTrafficAccountList(SelectTrafficDTO selectTrafficDTO);
	
	/**
	 * 流量详情查询
	 * 
	 * @param selectTrafficDTO
	 * @return List<MchtTrafficSerial>
	 */
	List<QaSerial> selectQaSerialList(SelectTrafficDTO selectTrafficDTO);
}
