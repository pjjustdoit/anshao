package com.pingan.qhzx.anshao.platform.common.web.common;

public class PageForm extends AppCommonForm {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7644096016518828261L;

	private Integer currentPage = 1;

    private Integer pageSize = 10;

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
    
    
}
