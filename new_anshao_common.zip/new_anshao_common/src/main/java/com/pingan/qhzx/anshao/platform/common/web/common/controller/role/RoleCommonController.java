package com.pingan.qhzx.anshao.platform.common.web.common.controller.role;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.bean.UserSessionBean;
import com.pingan.qhzx.anshao.platform.common.bean.ValidResult;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserAuth;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRole;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MenuDTO;
import com.pingan.qhzx.anshao.platform.common.enums.DicCodeEnum;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.role.IRoleService;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;
import com.pingan.qhzx.anshao.platform.common.web.common.PageForm;
import com.pingan.qhzx.anshao.platform.common.web.common.controller.AnshaoPtCommonController;
import com.pingan.qhzx.anshao.platform.common.web.form.RoleForm;

/**
 * Created by yuzilei869 on 16/7/21.
 */
public class RoleCommonController extends AnshaoPtCommonController {

	private static final Logger log = LoggerFactory.getLogger(RoleCommonController.class);
	
	@Autowired
	private IRoleService roleService;

	/**
	 * 所属机构和自己创建的角色
	 * @param pageForm
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/list")
	public JSONObject roleList(PageForm pageForm, HttpServletRequest request) {
		try {
			HashMap<String, Object> data = new HashMap<String, Object>();

			UserSessionBean userSessionBean = getUserInfo(request);
			
			String loginNameSession = userSessionBean.getLoginName();
			
			String roleCodeSession = userSessionBean.getRoleCode();

			PageInfo<MchtUserRole> mchtUserRolePage = roleService.getMchtUserRoleList(pageForm.getCurrentPage(),
					pageForm.getPageSize(), userSessionBean.getOrgId(), loginNameSession,
					roleCodeSession);

			data.put("list", mchtUserRolePage.getList());
			data.put("totalCount", mchtUserRolePage.getTotal());
			data.put("currentPage", mchtUserRolePage.getPageNum());

			return WebUtils.createSuccResult(data);
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	@ResponseBody
	@RequestMapping("/del")
	public JSONObject roleDel(RoleForm roleForm, HttpServletRequest request) {
		try {

			if (roleForm.getMchtUserRoleId() == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			
			UserSessionBean userSessionBean = getUserInfo(request);
			
			String loginNameSession = userSessionBean.getLoginName();
			
			ValidResult validResult = roleService.roleDel(roleForm.getMchtUserRoleId(), loginNameSession);
			
			if (!validResult.valid()) {
				return validResult.toWebResult();
			}
			
			return WebUtils.createSuccResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	@ResponseBody
	@RequestMapping("/add/")
	public JSONObject roleAdd(RoleForm roleForm, HttpServletRequest request) {
		try {

			if (roleForm.getOrgId() == null
					|| StringUtils.isBlank(roleForm.getRoleName())
					|| StringUtils.isBlank(roleForm.getRoleDesc())
					|| StringUtils.isBlank(roleForm.getMchtUserAuthSelected())) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			
			UserSessionBean userSessionBean = getUserInfo(request);

			Integer mchtUserId = userSessionBean.getMchtUserId();
			
			String LoginNameSession = userSessionBean.getLoginName();
			
			Integer orgIdSession = userSessionBean.getOrgId();
			
			String roleCode = userSessionBean.getRoleCode();
			
			List<MchtUserAuth> auths = userSessionBean.getAuths();
			
			MchtUserRole userRole = new MchtUserRole();
			userRole.setOrgId(roleForm.getOrgId());
			userRole.setRoleName(roleForm.getRoleName());
			userRole.setRoleDesc(roleForm.getRoleDesc());
			
			ValidResult validResult = roleService.roleAdd(mchtUserId, orgIdSession, userRole,
					roleForm.getMchtUserAuthSelected(), roleCode, auths, LoginNameSession);
			
			if (!validResult.valid()) {
				return validResult.toWebResult();
			}
			
			return WebUtils.createSuccResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	public JSONObject roleUpdOrgChangeInfo(RoleForm roleForm, HttpServletRequest request) {
		try {
			ValidResult validResult;
			if (roleForm.getOrgId() == null
					|| roleForm.getMchtUserRoleId() == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}

			UserSessionBean userSessionBean = getUserInfo(request);
			String roleCodeSession = userSessionBean.getRoleCode();
			List<MenuDTO> menuListSession = userSessionBean.getMenus();


			validResult = roleService.roleUpdOrgChangeInfo(roleCodeSession, roleForm.getMchtUserRoleId(), roleForm.getOrgId(), menuListSession);
			
			return validResult.toWebResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	public JSONObject roleInfo(RoleForm roleForm, HttpServletRequest request) {
		try {
			ValidResult validResult;
			if (roleForm.getOrgId() == null
					&& roleForm.getMchtUserRoleId() == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}

			UserSessionBean userSessionBean = getUserInfo(request);
			String roleCodeSession = userSessionBean.getRoleCode();
			List<MenuDTO> menuListSession = userSessionBean.getMenus();
			String loginNameSession = userSessionBean.getLoginName();

			if (DicCodeEnum.OPERATE_TYPE_ADD.getCode().equals(roleForm.getOperateType())) {
				validResult = roleService.roleAddInfo(roleCodeSession, roleForm.getMchtUserRoleId(), roleForm.getOrgId(), menuListSession);
			} else {
				validResult = roleService.roleUpdInfo(roleCodeSession, roleForm.getMchtUserRoleId(), roleForm.getOrgId(), menuListSession, loginNameSession);
			}
			
			return validResult.toWebResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	@ResponseBody
	@RequestMapping("/upd/")
	public JSONObject roleUpd(RoleForm roleForm, HttpServletRequest request) {
		try {
			if (roleForm.getOrgId() == null
					|| roleForm.getMchtUserRoleId() == null
					|| StringUtils.isBlank(roleForm.getRoleName())
					|| StringUtils.isBlank(roleForm.getRoleDesc())
					|| StringUtils.isBlank(roleForm.getMchtUserAuthSelected())) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}

			UserSessionBean userSessionBean = getUserInfo(request);
			String loginNameSession = userSessionBean.getLoginName();
			String roleCodeSession = userSessionBean.getRoleCode();
			List<MchtUserAuth> auths = userSessionBean.getAuths();
			ValidResult validResult = roleService.roleUpdate(
					loginNameSession, roleForm.getMchtUserRoleId(),
					roleForm.getRoleName(), roleForm.getRoleDesc(),
					roleForm.getMchtUserAuthSelected(), auths, roleCodeSession, roleForm.getOrgId());
			
			return validResult.toWebResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
}
