package com.pingan.qhzx.anshao.platform.common.dao.pg;

import java.util.List;
import java.util.Map;

import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtxExt;

public interface MchtCorpusCtxMapper extends BaseMapper {
	int deleteByPrimaryKey(Long mchtCorpusCtxId);

	int insert(MchtCorpusCtx record);

	int insertSelective(MchtCorpusCtx record);

	MchtCorpusCtx selectByPrimaryKey(Long mchtCorpusCtxId);

	int updateByPrimaryKeySelective(MchtCorpusCtx record);

	int updateByPrimaryKey(MchtCorpusCtx record);
    /**
     * 根据orgId和ZskClassifyId商户语料list
     *
     * @param mchtCorpusCtx
     * @return List<MchtCorpusCtx>
     */
    List<MchtCorpusCtx> selectMchtCorpusCtxList(MchtCorpusCtx mchtCorpusCtx);

	/**
	 * 根据orgId和ZskClassifyId查询商户语料list
	 * 
	 * @param params
	 * @return List<MchtCorpusCtxExt>
	 */
	List<MchtCorpusCtxExt> selectByParams(Map<String,Object> params);

	/**
	 * 批量更新,更新的where条件为
     * zskClassifyId:分类id,
     * exactMatchFlag：精确匹配 1=是 0=否
     * question：内容问题
     * queryStartDate：修改日期区间开始
     * queryEndDate：修改日期区间结束
	 * @param params
	 *
	 * @return
	 */
	int batchUpdate(Map<String,Object> params);

	/**
	 * 根据orgId和effectiveFlag查询问答列表
	 * 
	 * @param mchtCorpusCtx
	 * @return List<MchtCorpusCtx>
	 */
	List<MchtCorpusCtx> selMchtCorListByorgIdEffect(MchtCorpusCtx mchtCorpusCtx);
	
	int updateCorpusStatus(String effectiveFlag);
}