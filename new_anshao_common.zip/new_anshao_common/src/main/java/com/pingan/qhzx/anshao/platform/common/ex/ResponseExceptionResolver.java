package com.pingan.qhzx.anshao.platform.common.ex;

import com.alibaba.fastjson.JSON;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.papp.web.exception.ResponseCodeExceptionResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by yuzilei022 on 16/8/1.
 */
public class ResponseExceptionResolver extends ResponseCodeExceptionResolver {

    private static final Logger log = LoggerFactory.getLogger(ResponseExceptionResolver.class);
    private static ModelAndView empty = new ModelAndView("emptyView");

    @Override
    protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        ResponseCodeException find = ResponseCodeException.toResponseCodeException(ex);
        if (find != null) {
            log.error("[error]!!!", ex);
            ModelMap model = new ModelMap();
            String msg = this.resolveMessage(find);
            model.put("code", find.getResponseCode());
            model.put("message", msg);
            model.put("ex", find.getMessage());
            String charset = this.getCharset(response);
            String respString = JSON.toJSONString(model);
            if (this.logger.isDebugEnabled()) {
                this.logger.debug("ResponseJSON=" + respString);
            }
            try {
                byte[] ioEx = respString.getBytes(charset);
                this.outputHttpResponse(ioEx, response);
            } catch (IOException var11) {
                this.logger.error("Output response error,cause:" + var11.getMessage());
            }
        }

        return empty;
    }
}
