package com.pingan.qhzx.anshao.platform.common.web.log;

import com.alibaba.fastjson.JSON;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.Serializable;

/**
 * Created by YUZILEI869 on 2016-01-27.
 */
public class SysLogAdvisor implements MethodInterceptor {

    private static final Logger log = LoggerFactory.getLogger("com.cs.dsd.web.access.txn.SysLogAdvisor");

    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
        RequestMapping declaredAnnotation = invocation.getMethod().getAnnotation(RequestMapping.class);
        if (declaredAnnotation == null) {
            return invocation.proceed();
        }
        log("request", invocation, invocation.getArguments());
        Object result = invocation.proceed();
        log("response", invocation, result);
        return result;
    }

    public void log(String prefix, MethodInvocation invocation, Object o) {
        try {
            log.info("[{}]:{}.{}-->{}", prefix, invocation.getThis().getClass().getSimpleName(), invocation.getMethod().getName(), JSON.toJSONString(o));
        } catch (Throwable e) {
            log.error("", e);
        }
    }

    public void log(String prefix, MethodInvocation invocation, Object[] objs) {
        try {
            for (int i = 0; i < objs.length; i++) {
                if (objs[i] instanceof Serializable) {
                    log.info("[{}]:{}.{}[{}]-->{}", prefix, invocation.getThis().getClass().getSimpleName(), invocation.getMethod().getName(), i, JSON.toJSONString(objs[i]));
                }
            }
        } catch (Throwable e) {
            log.error("", e);
        }
    }

}
