package com.pingan.qhzx.anshao.platform.common.dao.pg;

import com.pingan.qhzx.anshao.platform.common.dto.pg.DicDesc;
import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;

public interface DicDescMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer dicDescId);

    int insert(DicDesc record);

    int insertSelective(DicDesc record);

    DicDesc selectByPrimaryKey(Integer dicDescId);

    int updateByPrimaryKeySelective(DicDesc record);

    int updateByPrimaryKey(DicDesc record);
}