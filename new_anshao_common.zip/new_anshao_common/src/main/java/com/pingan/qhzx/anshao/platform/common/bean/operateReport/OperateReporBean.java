package com.pingan.qhzx.anshao.platform.common.bean.operateReport;

public class OperateReporBean {

	// 机构id
	private Integer orgId;

	// 机构代码
	private String orgCode;

	// 机构名称
	private String orgName;

	// 总流量
	private Long trafficTotalNum;

	// 已使用流量
	private Long trafficUseNum;

	// 剩余流量
	private Long trafficRemainNum;

	// 语料总量
	private Long corpusTotalNum;

	// 语料余量
	private Long corpusSurplusNum;

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public Long getTrafficTotalNum() {
		return trafficTotalNum;
	}

	public void setTrafficTotalNum(Long trafficTotalNum) {
		this.trafficTotalNum = trafficTotalNum;
	}

	public Long getTrafficUseNum() {
		return trafficUseNum;
	}

	public void setTrafficUseNum(Long trafficUseNum) {
		this.trafficUseNum = trafficUseNum;
	}

	public Long getTrafficRemainNum() {
		return trafficRemainNum;
	}

	public void setTrafficRemainNum(Long trafficRemainNum) {
		this.trafficRemainNum = trafficRemainNum;
	}

	public Long getCorpusTotalNum() {
		return corpusTotalNum;
	}

	public void setCorpusTotalNum(Long corpusTotalNum) {
		this.corpusTotalNum = corpusTotalNum;
	}

	public Long getCorpusSurplusNum() {
		return corpusSurplusNum;
	}

	public void setCorpusSurplusNum(Long corpusSurplusNum) {
		this.corpusSurplusNum = corpusSurplusNum;
	}
}
