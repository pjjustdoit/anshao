package com.pingan.qhzx.anshao.platform.common.service.traffic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtTrafficSerialMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.QaSerialMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.TrafficAccountMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.QaSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.TrafficAccount;
import com.pingan.qhzx.anshao.platform.common.dto.reportStatistics.SelectTrafficDTO;
import com.pingan.qhzx.anshao.platform.common.dto.reportStatistics.SelectTrafficPageDTO;

@Service
public class ReportStatisticsService implements IReportStatisticsService {

	@Autowired
	private TrafficAccountMapper trafficAccountMapper;

	@Autowired
	private MchtTrafficSerialMapper mchtTrafficSerialMapper;
	
	@Autowired
	private QaSerialMapper qaSerialMapper;

	@Override
	public TrafficAccount selectTrafficAccount(Integer orgId) {
		return trafficAccountMapper.selectByPrimaryKey(orgId);
	}

	@Override
	public PageInfo<MchtTrafficSerial> selectMchtTrafficSerialListPage(SelectTrafficPageDTO selectTrafficPageDTO) {
		// 设置页和页大小
		PageHelper.startPage(selectTrafficPageDTO.getCurrentPage(), selectTrafficPageDTO.getPageSize());
		SelectTrafficDTO selectTrafficDTO = new SelectTrafficDTO();
		selectTrafficDTO.setOrgId(selectTrafficPageDTO.getOrgId());
		selectTrafficDTO.setSerialType(selectTrafficPageDTO.getSerialType());
		selectTrafficDTO.setStartDate(selectTrafficPageDTO.getStartDate());
		selectTrafficDTO.setEndDate(selectTrafficPageDTO.getEndDate());
		List<MchtTrafficSerial> list = mchtTrafficSerialMapper.selectMchtTrafficSerialList(selectTrafficDTO);
		return new PageInfo<MchtTrafficSerial>(list);
	}

	@Override
	public List<MchtTrafficSerial> selectTrafficAccountList(SelectTrafficDTO selectTrafficDTO) {
		return mchtTrafficSerialMapper.selectMchtTrafficSerialList(selectTrafficDTO);
	}

	@Override
	public List<QaSerial> selectQaSerialList(SelectTrafficDTO selectTrafficDTO) {
		return qaSerialMapper.selectQaSerialList(selectTrafficDTO);
	}
}
