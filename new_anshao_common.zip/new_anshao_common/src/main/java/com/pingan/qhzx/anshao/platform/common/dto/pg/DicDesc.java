package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;

public class DicDesc extends BaseDTO {
    private Integer dicDescId;

    private String dicCode;

    private String dicDesc;

    public Integer getDicDescId() {
        return dicDescId;
    }

    public void setDicDescId(Integer dicDescId) {
        this.dicDescId = dicDescId;
    }

    public String getDicCode() {
        return dicCode;
    }

    public void setDicCode(String dicCode) {
        this.dicCode = dicCode == null ? null : dicCode.trim();
    }

    public String getDicDesc() {
        return dicDesc;
    }

    public void setDicDesc(String dicDesc) {
        this.dicDesc = dicDesc == null ? null : dicDesc.trim();
    }
}