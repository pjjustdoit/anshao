package com.pingan.qhzx.anshao.platform.common.service.model.bean;

import java.io.Serializable;

/**
 * Created by yuzilei022 on 16/10/8.
 */
public class Answer implements Serializable {

    private String answer;

    private  String classifierValue;

    private String question;

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getClassifierValue() {
        return classifierValue;
    }

    public void setClassifierValue(String classifierValue) {
        this.classifierValue = classifierValue;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}
