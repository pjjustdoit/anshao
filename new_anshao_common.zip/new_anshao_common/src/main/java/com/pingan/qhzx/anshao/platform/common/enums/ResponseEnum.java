package com.pingan.qhzx.anshao.platform.common.enums;

/**
 * Created by yuzilei869 on 16/7/20.
 */
public enum ResponseEnum {
    /**
     * =====================================
     * 0-99
     * =====================================
     */
    SUCCESS("0", "操作成功"),
    FAILURE("1", "操作失败"),
    INVALID_PARAMS("2", "非法参数"),
    INVALID_SIGN("3", "非法签名"),
    UNKNOWN_ERROR("4", "未知错误"),
    INNER_ERROR("9", "内部错误"),
    INVALID_LOGIN_PWD("10", "用户名密码不正确"),
    LOGIN_PASSWORD_ERROR_LIMIT("12", "密码出错4次被锁定、请一小时后再试"),
    INVALID_REG_NAME("13", "invalid name"),
    IDCARD_NOT_BELONG_TO_USER("14", "this id card doesn't belong to this user"),
    PWD_INITIAL_CHANGE("16", "登录成功！ 首次登录请修改初始密码"),
    PHONE_EXIST("20", "Phone exist"),
    PHONE_NOT_EXIST("21", "Phone don't exist"),
    PHONE_INVALID("22", "Invalid phone"),
    PHONE_SEND_OVER_LIMIT("23","This phone number is sent out of limit"),
    IDENTITYID_INVALID("25", "identity invalid"),
    IDENTITYID_SHOULD_BE_SAME("26", "identity should be same"),
    IDENTITYID_ILLEGAL("27", "identity illegal"),
    ADDRESS_IS_USING("28", "this address is using"),
    THE_SAME_CLASSIFY_NAME("29", "分类名称不可重复"),
    EXPORT_FILE_FAILED("30", "Excel导出失败"),
    CAN_NOT_DELETE("31", "该用户只能修改属于自己知识库分类"),
    THIS_ZSK_CLASSIFY_CAN_NOT_BE_DELETED("32", "当前分类有关联内容， 不可删除"),
    WRITE_CSV_FILE_FAILED("33", "CSV操作失败"),
    NO_ROBOT_SETTING("34", "当前商户没有机器人配置信息"),
    
    /**
     * =====================================
     * 100-199
     * =====================================
     */
    VCODE_PHONE_OVER_LIMIT("100", "sending vcode is over limit"),
    VCODE_IP_OVER_LIMIT("101", "sending vcode is over limit"),
    VCODE_FAULT_OVER_LIMIT("102", "fault vcode is over limit"),
    VCODE_TOO_MUCH("103", "Number of sending vcode is too much"),
    VCODE_NOT_EXIST("104", "Vcode don't exist"),
    VCODE_OVER_TIME("105", "Vcode over time"),
    VCODE_INCORRECT("106", "Vcode is incorrect"),
    VCODE_ERROR_MORE_THAN_MAX("107", "Vcode error times more than max"),
    VCODE_SENDING_FAIL("108", "failed to send vcode"),
    SECURITY_CODE_ERROR("110", "Security code error"),
    SECURITY_PWD_IRREGULAR("111", "Password is irregular"),
    TCODE_INVALID("112", "tCode invalid"),

    /**
     * =====================================
     * 200-399
     * =====================================
     */
    USERNAME_IS_EMPTY("201", "userName is empty!"),
    ID_CARD_NO_IS_EMPTY("202", "idCardNo is empty!"),
    IDCARDNO_HAS_BE_REGISTER("203", "idCardNo has be register!"),
    
    /**
     * =====================================
     * 400-420
     * =====================================
     */
    EXPIRE_DATE_ILLEGAL("400","有效期限必须为将来日期"),
    CLASSIFY_NAME_NOT_EXISTS("401","知识库分类名不存在"),
    CLASSIFY_ID_NOT_EXISTS("402","知识库分类不存在"),
    AUTH_CODE_HAS_EXISTS("403","授权码不可重复"),
    File_TOO_LARGE("404","文件超过2MB"),
    CORPUS_SURPLUS_NUM_ZERO("405","剩余可用语料数为0"),
    CORPUS_USE_GREATER_THAN_TOTAL("406","已用语料数大于等于语料总数"),
    CORPUS_USE_NUM_ZERO("407","已用语料数小于等于0"),
    CORPUS_SURPLUS_GREATER_THAN_TOTAL("408","剩余可用语料数大于等于语料总数"),
    CANNOT_UPD_OTHERS_ORGS("409","无权限编辑其他用户创建的机构"),
    
    
    /**
     * =====================================
     * 450-470
     * =====================================
     */
    ROLE_AUTH_FAILURE("451", "仅可编辑自己创建的角色"),
    ROLE_CANNOT_DEL("452", "需要先删除该角色下的用户后、才能删除该角色"),
    ROLE_PARTERN_ONLY_ONE("453", "仅可给外部机构创建一个管理员角色"),
    USER_CAN_NOT_INIT_PWD("454", "仅外部机构的账号可初始化密码"),
    EMAIL_EXIST("455", "邮箱不可重复"),
    ORG_CODE_EXIT("456", "机构ID不可重复"),
    ORG_NAME_EXIT("457", "机构名称不可重复"),
    ROLE_NAME_EXIT("458", "角色名不可重复"),
    USER_OPERATE_AUTH_FAILURE("459", "仅可编辑自己创建的用户"),
    CANNOT_OPERATE_ORG_USER("460", "没有权限操作其他机构的用户"),
    USER_PARTERN_ONLY_ONE("461", "对每个外部机构仅可创建一个管理员用户"),
    REQUEST_AUTH_FAIL("462", "无权限访问"),
    ROLE_CAN_NOT_CHANGE_ORG("463","已关联用户，无法变更"),
    USER_LEAVE_CANNOT_LOGIN("464","无法登陆，请联系管理员"),

    /**
     * =====================================
     * 1000-1999
     * =====================================
     */
    USER_FROZEN("1000", "frozen user"),
    USER_NOT_EXIST("1001", "用户不存在"),
    USER_EXIST("1002", "用户账号不能重复"),
    USER_NOT_LOGIN("1003", "用户未登录"),

    IDCARD_NAME_NOT_MATCH("1100", "ID card and name is not match"),

    IMAGE_SIZE_BEYOND_10M("1107", "image size beyond 10M"),
    PARAM_ERROR("1500", "参数中存在相同的参数名"),
    PARAM_EMPTY_SIGN("1501", "签名为空"),
    PARAMS_ERROR_SIGN("1502", "错误签名，不能解析"),
    PARAMS_COMMON_LACK_OR_ILLEGAL("1503", "lacking or illegal common params"),


    /**
     * 2000-2999
     */
    POINT_NOT_ENOUGH("2000", "point not enough"),
    GESTURE_ILLEGAL_LOGINTOKEN("2200", "illegal login token"),

    /**
     * =====================================
     * 3000-3010
     * =====================================
     */
    EXCEL_RESOLVE_ERROR("3000","excel resolve error"),
    EXCEL_DATA_DB_NOT_FOUND("3001", "excel data DB not found"),

    /**
     * =====================================
     * 10000-19999
     * =====================================
     */
    IDCARD_QUERY_FAILURE("10006", "query idcard failure"),

    INVALID_VUID("10007", "Verify code error, please re-enter "),

    IDCARD_AUTH_FAILURE("10008", "idcard auth faiure"),

    /**
     * =====================================
     * 20000-20100
     * =====================================
     */
    ORG_AUTH_FAILURE("20000", "机构授权错误"),
    ORG_INVALID("20002", "机构无效"),
    ROBOT_CONFIG_ERROR("20001", "机器人配置错误"),
    ANSIR_QA_ERROR("20003", "核心系统错误"),
    AVAILABLE_TRAFFIC_NOT_ENOUGH("20004", "可用流量不足，请充值"),
    MODEL_NOT_EXISTS("20005", "知识库找不到，请配置");



    private String code;


    private String message;

    // 构造方法
    private ResponseEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }


    public String getMessage() {
        return message;
    }

}
