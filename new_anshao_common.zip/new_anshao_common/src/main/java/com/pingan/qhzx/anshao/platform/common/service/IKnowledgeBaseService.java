package com.pingan.qhzx.anshao.platform.common.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.bean.knowledge.ZskClassifyPageDTO;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.dto.pg.ZskClassify;

/**
 * 商户管理平台->知识库管理->分类管理
 * 
 * @author LIUPENGLIANG375 创建时间：2016年9月27日 下午12:44:33
 */
public interface IKnowledgeBaseService {

	/**
	 * 新增分类
	 * 
	 * @param zskClassify
	 */
	void addClassify(ZskClassify zskClassify);

	/**
	 * 更新分类
	 * 
	 * @param zskClassify
	 */
	void updateClassify(ZskClassify zskClassify);

	/**
	 * 删除分类
	 * 
	 * @param zskClassifyId
	 */
	void deleteClassify(MchtCorpusCtx mchtCorpusCtx);

	/**
	 * 根据orgId获取知识库分类表主键list
	 * 
	 * @param orgId
	 * @return List<ZskClassify>
	 */
	List<ZskClassify> selectZskClassifyListByOrgId(Integer orgId);

	/**
	 * 根据orgId和ZskClassifyId商户语料list
	 * 
	 * @param mchtCorpusCtx
	 * @return List<MchtCorpusCtx>
	 */
	List<MchtCorpusCtx> selectMchtCorpusCtxList(MchtCorpusCtx mchtCorpusCtx);

	/**
	 * 获取分类详细
	 * 
	 * @param zskClassifyId
	 * @return ZskClassify
	 */
	ZskClassify detailClassify(Integer zskClassifyId);

	/**
	 * 分类查询
	 * 
	 * @param zskClassify
	 * @returnList<ZskClassify>
	 */
	PageInfo<ZskClassify> queryClassifyList(ZskClassifyPageDTO zskClassifyPageDTO);

	/**
	 * 根据条件查询List<ZskClassify>
	 * 
	 * @param zskClassify
	 * @returnList<ZskClassify>
	 */
	List<ZskClassify> selectClassifyList(ZskClassify zskClassify);
}
