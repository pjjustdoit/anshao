package com.pingan.qhzx.anshao.platform.common.dao.pg;

import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerialExt;
import com.pingan.qhzx.anshao.platform.common.dto.reportStatistics.SelectTrafficDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface MchtTrafficSerialMapper extends BaseMapper {
    int deleteByPrimaryKey(Long mchtTrafficSerialId);

    int insert(MchtTrafficSerial record);

    int insertSelective(MchtTrafficSerial record);

    MchtTrafficSerial selectByPrimaryKey(Long mchtTrafficSerialId);

    int updateByPrimaryKeySelective(MchtTrafficSerial record);

    int updateByPrimaryKey(MchtTrafficSerial record);

    List<MchtTrafficSerialExt> selectByParams(Map<String,Object> params);

    String querySerialNo();

    Long queryNextChargingBatchNo();

    Integer updateSerialBatchNo(@Param("batchNo") Long batchNo, @Param("orgId") Integer orgId);

    Integer updateSerialChargingStatus(@Param("batchNo") Long batchNo, @Param("chargingStatus") String chargingStatus);

    List<MchtTrafficSerial> selectMchtTrafficSerialList(SelectTrafficDTO selectTrafficDTO);
}