package com.pingan.qhzx.anshao.platform.common.service.model.api;

import com.paic.pafa.appclient.ServiceResults;
import com.pingan.qhzx.anshao.platform.common.bean.qa.SynchronizationQuestionBean;

import java.util.List;
import java.util.Map;

/**
 * Created by yuzilei022 on 16/10/8.
 */
public interface IAnsirAPI {
	void createModel(List<String> orgs);

	Boolean ansirUnknowQuestionList(List<SynchronizationQuestionBean> unknowQuestionList);

	ServiceResults answer(Map<String, Object> requestMap);
}
