package com.pingan.qhzx.anshao.platform.common.service;

import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.dto.pg.OrgExt;
import com.pingan.qhzx.anshao.platform.common.web.form.OrgForm;

import java.util.List;
import java.util.Map;
/**
 * 组织服务类
 * @author ZHANGSHAN193
 *
 */
public interface IOrgService {

    int insertSelective(OrgForm record);

    Org selectByPrimaryKey(Integer orgId);

    int updateByPrimaryKeySelective(OrgForm record,Org queryOrg);
    
    Map<String,Object> selectOrgList(OrgForm record);

    Org queryOrgByOrgCode(String orgCode);

    List<OrgExt> selectOrgExtList(OrgForm record);

    List<Org> querySelectList(Integer orgId);

    List<Org> queryByParams(OrgForm orgForm);

    List<Org> queryPartnerOrgs();

    List<Org> queryOrgInExpire();
    
    List<Org> selectByAuthCode(String authCode);

    Org needSyncOrg(Integer orgId);
}
