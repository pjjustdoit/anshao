package com.pingan.qhzx.anshao.platform.common.enums;

/**
 * 流量类型
 * 
 * @author LIUPENGLIANG375 创建时间：2016年10月9日 下午5:10:24
 */
public enum SerialTypeEnum {

	INCREASE("I", "增加"), REDUCE("O", "减少");

	private String code;
	private String desc;

	private SerialTypeEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public static SerialTypeEnum getInstance(String code) {
		SerialTypeEnum[] allTypes = SerialTypeEnum.values();
		for (SerialTypeEnum serialTypeEnum : allTypes) {
			if (serialTypeEnum.getCode().equalsIgnoreCase(code)) {
				return serialTypeEnum;
			}
		}
		throw new IllegalArgumentException("没有符合状态的枚举对象");
	}
}
