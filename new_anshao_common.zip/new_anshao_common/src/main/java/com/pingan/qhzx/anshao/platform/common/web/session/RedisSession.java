package com.pingan.qhzx.anshao.platform.common.web.session;

import com.google.common.base.Charsets;
import com.pingan.pafa.common.utils.Pafa5ConfigUtils;
import com.pingan.pafa.redis.map.RedisMap;
import com.pingan.pafa.redis.map.RedisMapFactoryBean;
import com.pingan.pafa.stp.wesession.UserSession;
import com.pingan.pafa.stp.wesession.UserSessionImpl;
import com.pingan.pafa.stp.wesession.WeSession;
import com.pingan.pafa.stp.wesession.WeSessionConfig;
import com.pingan.pafa.stp.wesession.id.DefaultSessionIdSupportBean;
import com.pingan.pafa.stp.wesession.id.SessionIdSupport;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by yuzilei022 on 16/8/23.
 */
public class RedisSession extends RedisMapFactoryBean<String, Object> implements WeSession, InitializingBean {
    private static final String ATTR_KEY_WESESSION = "$_session";
    protected Log logger = LogFactory.getLog(this.getClass());
    private boolean isEnabled = true;
    private WeSessionConfig configure;
    private Resource configureResource;
    private Properties configureProperties;
    private SessionIdSupport sessionIdSupport;

    public RedisSession() {
        this.setKeyClazz(String.class);
        this.setValueClazz(Object.class);
    }

    public UserSession getSession(HttpServletRequest request, HttpServletResponse response, boolean create) {
        Object session = request.getAttribute(ATTR_KEY_WESESSION);
        if (session != null) {
            return (UserSession) session;
        } else {
            String sessionId = this.getId(request, response);
            boolean isNew = false;
            if (sessionId == null && create) {
                sessionId = this.createId(request, response);
                isNew = true;
            }

            UserSessionImpl userSession = null;
            if (sessionId != null) {
                if (!isNew) {
                    String redisMap = this.configure.getSessionIdKeyName() + "." + sessionId;
                    if (!this.getRedis().getCommands().exists(redisMap.getBytes(Charsets.UTF_8)).booleanValue()) {
                        if (!create) {
                            if (this.configure.isDestoryCookieOnCacheExpired()) {
                                this.sessionIdSupport.destory(request, response);
                            }

                            return null;
                        }

                        sessionId = this.createId(request, response);
                        isNew = true;
                    }
                }

                RedisMap redisMap1 = this.get(this.configure.getSessionIdKeyName() + "." + sessionId);
                userSession = new UserSessionImpl(redisMap1, sessionId, isNew, this.configure);
                request.setAttribute(ATTR_KEY_WESESSION, userSession);
            }

            return userSession;
        }
    }

    public boolean destroySession(HttpServletRequest request, HttpServletResponse response, UserSession userSession) {
        if (userSession == null) {
            return false;
        } else {
            if (this.logger.isInfoEnabled()) {
                this.logger.info("[Wesession]destroy by sessionId<" + userSession.getId() + ">..");
            }

            this.sessionIdSupport.destory(request, response);
            request.removeAttribute(ATTR_KEY_WESESSION);
            return userSession.destroy();
        }
    }

    public String getId(HttpServletRequest request, HttpServletResponse response) {
        return this.sessionIdSupport.get(request, response);
    }

    public String createId(HttpServletRequest request, HttpServletResponse response) {
        return this.sessionIdSupport.create(request, response, (String) null);
    }

    public synchronized void afterPropertiesSet() throws Exception {
        Properties configProperties = this.getConfigureProperties();
        if (this.configureResource != null) {
            if (configProperties == null) {
                configProperties = new Properties();
            }

            try {
                configProperties.load(this.configureResource.getInputStream());
            } catch (IOException var3) {
                this.logger.error("Read Resource:" + this.configureResource + " error,cause:" + var3.getMessage(), var3);
            }
        }

        WeSessionConfig configure = this.getConfigure();
        if (configProperties != null && configProperties.size() > 0) {
            if (configure == null) {
                configure = new WeSessionConfig();
                this.setConfigure(configure);
            }

            Pafa5ConfigUtils.bindBean(configProperties, configure);
        }

        if (configure == null) {
            throw new IllegalArgumentException("Configure be null.");
        } else {
            if (this.logger.isInfoEnabled()) {
                this.logger.info("[Wesession]configure=" + configure);
            }

            if (this.sessionIdSupport == null) {
                this.sessionIdSupport = new DefaultSessionIdSupportBean(configure);
            }

            if (this.getRedis() == null) {
                throw new FatalBeanException("redis is null");
            } else {
                if (this.getSerialization() == null) {
                    this.setSerialization("hessian2");
                }
            }
        }
    }

    public boolean isEnabled() {
        return this.isEnabled;
    }

    public void setEnabled(boolean isEnabled) {
        this.isEnabled = isEnabled;
    }

    public WeSessionConfig getConfigure() {
        return this.configure;
    }

    public void setConfigure(WeSessionConfig configure) {
        this.configure = configure;
    }

    public Resource getConfigureResource() {
        return this.configureResource;
    }

    public void setConfigureResource(Resource configureResource) {
        this.configureResource = configureResource;
    }

    public Properties getConfigureProperties() {
        return this.configureProperties;
    }

    public void setConfigureProperties(Properties configureProperties) {
        this.configureProperties = configureProperties;
    }

    public SessionIdSupport getSessionIdSupport() {
        return this.sessionIdSupport;
    }

    public void setSessionIdSupport(SessionIdSupport sessionIdSupport) {
        this.sessionIdSupport = sessionIdSupport;
    }

}
