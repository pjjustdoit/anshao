package com.pingan.qhzx.anshao.platform.common.dao.pg;

import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusOutline;
import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;

public interface MchtCorpusOutlineMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer orgId);

    int insert(MchtCorpusOutline record);

    int insertSelective(MchtCorpusOutline record);

    MchtCorpusOutline selectByPrimaryKey(Integer orgId);

    int updateByPrimaryKeySelective(MchtCorpusOutline record);

    int updateByPrimaryKey(MchtCorpusOutline record);

    MchtCorpusOutline selectByOrgIdWithLock(Integer orgId);
}