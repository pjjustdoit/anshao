package com.pingan.qhzx.anshao.platform.common.service.mail;

/**
 * Created by zhangshan193 on 16/9/30.
 */
public interface IMailService {

    /**
     * 
     * @param recipients 收件人
     * @param mailCC 抄送人
     * @param mailType 邮件类型
     * @param mailTitle 邮件标题
     * @param mailContent 邮件内容
     * @param hasAttach 是否附件
     * @param operateBy 操作人
     */
	public void mailListInsert(String recipients, String mailCC, String mailType, String mailTitle,
			String mailContent, boolean hasAttach, String operateBy);

}
