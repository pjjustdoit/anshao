package com.pingan.qhzx.anshao.platform.common.bean.user;

import com.pingan.qhzx.anshao.platform.common.bean.BaseBean;

public class UserSearchCondition extends BaseBean {

	private String loginName;

	private String userName;

	private String userStatus;

	private Integer mchtUserRoleId;

	private Integer mchtUserId;

	private Integer orgId;
	
	private String loginNameSession;

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public Integer getMchtUserRoleId() {
		return mchtUserRoleId;
	}

	public void setMchtUserRoleId(Integer mchtUserRoleId) {
		this.mchtUserRoleId = mchtUserRoleId;
	}

	public Integer getMchtUserId() {
		return mchtUserId;
	}

	public void setMchtUserId(Integer mchtUserId) {
		this.mchtUserId = mchtUserId;
	}

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public String getLoginNameSession() {
		return loginNameSession;
	}

	public void setLoginNameSession(String loginNameSession) {
		this.loginNameSession = loginNameSession;
	}
}
