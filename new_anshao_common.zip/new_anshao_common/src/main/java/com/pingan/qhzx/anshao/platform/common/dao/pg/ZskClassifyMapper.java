package com.pingan.qhzx.anshao.platform.common.dao.pg;

import java.util.List;
import java.util.Map;

import com.pingan.qhzx.anshao.platform.common.bean.knowledge.ZskClassifyPageDTO;
import com.pingan.qhzx.anshao.platform.common.dto.pg.ZskClassify;
import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;

public interface ZskClassifyMapper extends BaseMapper {
	int deleteByPrimaryKey(Integer zskClassifyId);

	int insert(ZskClassify record);

	int insertSelective(ZskClassify record);

	ZskClassify selectByPrimaryKey(Integer zskClassifyId);

	int updateByPrimaryKeySelective(ZskClassify record);

	int updateByPrimaryKey(ZskClassify record);

	/**
	 * 根据orgId获取知识库分类list
	 * 
	 * @param orgId
	 * @return List<ZskClassify>
	 */
	List<ZskClassify> selectZskClassifyListByOrgId(Integer orgId);

	/**
	 * 分类查询
	 * 
	 * @param zskClassifyPageDTO
	 * @return List<ZskClassify>
	 */
	List<ZskClassify> queryClassifylist(ZskClassifyPageDTO zskClassifyPageDTO);

	/**
	 * 根据条件查询List<ZskClassify>
	 * 
	 * @param zskClassify
	 * @return List<ZskClassify>
	 */
	List<ZskClassify> selectClassifyList(ZskClassify zskClassify);

}