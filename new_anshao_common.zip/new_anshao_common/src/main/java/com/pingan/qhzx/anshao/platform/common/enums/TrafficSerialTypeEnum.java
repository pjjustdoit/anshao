package com.pingan.qhzx.anshao.platform.common.enums;

public enum TrafficSerialTypeEnum {
	IN("I","增加流量"),
	OUT("O","减少流量");
	
	String code;
	String desc;
	
	private TrafficSerialTypeEnum(String code,String desc){
		this.code = code;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
