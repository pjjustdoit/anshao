package com.pingan.qhzx.anshao.platform.common.utils;

import com.paic.pafa.biz.services.ServicesException;

import org.apache.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by yuzilei869 on 16/7/20.
 */
public class HttpRequestUtil {
    private static Logger logger = Logger.getLogger(HttpRequestUtil.class);
    // public static String sendJsonWithHttp(String surl, String json) {
    // try {
    // URL url = new URL(surl);
    // HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    // conn.setRequestProperty("Content-Type",
    // "application/json;charset=utf-8");
    // conn.setRequestMethod("POST");// 提交模式
    // conn.setConnectTimeout(100000);// 连接超时单位毫秒 //
    // conn.setReadTimeout(200000);// 读取超时 单位毫秒
    // conn.setDoOutput(true);// 是否输入参数
    // conn.setDoInput(true);
    // conn.setUseCaches(false);
    // conn.connect();
    // DataOutputStream out = new DataOutputStream(conn.getOutputStream());
    // out.write(json.getBytes());
    // out.flush();
    // out.close();
    // BufferedReader reader = new BufferedReader(new InputStreamReader(
    // conn.getInputStream()));
    // StringBuffer sb = new StringBuffer();
    // String line;
    // while ((line = reader.readLine()) != null) {
    // sb.append(line);
    // }
    // reader.close();
    // conn.disconnect();
    // return sb.toString();
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // return null;
    // }
    public static String sendJsonWithHttp(String surl, String json)
            throws ServicesException {
        HttpURLConnection conn = null;
        DataOutputStream out  = null;
        InputStream is = null;
        ByteArrayOutputStream bos = null;
        OutputStream os = null;
        try {
            URL url = new URL(surl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Content-Type",
                    "application/json;charset=utf-8");
            conn.setRequestMethod("POST");// 提交模式
            conn.setConnectTimeout(Integer.valueOf(100000).intValue());// 连接超时单位毫秒
            // //
            conn.setReadTimeout(Integer.valueOf(100000).intValue());// 读取超时
            // 单位毫秒
            conn.setDoOutput(true);// 是否输入参数
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.connect();
            os = conn.getOutputStream();
            out = new DataOutputStream(os);
            out.write(json.getBytes("UTF-8"));
            out.flush();
            
            is = conn.getInputStream();
            bos = new ByteArrayOutputStream();
            byte[] b = new byte[1024];
            int i = -1;
            while ((i = is.read(b)) != -1) {
                bos.write(b, 0, i);
            }
            String returnMsg = new String(bos.toByteArray(), "utf-8");

            return returnMsg;
        } catch (Exception e) {
            throw new ServicesException("E005001_1", e);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
            if(os != null){
            	try {
					os.close();
				} catch (IOException e) {
					logger.error("{}",e);
				}
            }
            if(out != null){
            	try {
					out.close();
				} catch (IOException e) {
					logger.error("{}",e);
				}
            }
            if(bos != null){
            	try {
					bos.close();
				} catch (IOException e) {
					logger.error("{}",e);
				}
            }
            if(is != null){
            	try {
					is.close();
				} catch (IOException e) {
					logger.error("{}",e);
				}
            }
        }
    }

}

