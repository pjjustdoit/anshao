package com.pingan.qhzx.anshao.platform.common.service.chat;

/**
 * Created by yuzilei022 on 16/10/10.
 */
public class ChatService {
}
