package com.pingan.qhzx.anshao.platform.common.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerialExt;
import com.pingan.qhzx.anshao.platform.common.dto.pg.TrafficAccount;
import com.pingan.qhzx.anshao.platform.common.web.form.MchtTrafficSerialForm;

public interface IMchtTrafficSerialService {
	
    int addMchtTrafficSerial(MchtTrafficSerialForm record);
    
    Map<String,Object> selectIncrementByParams(MchtTrafficSerialForm record);
    
    void downloadByParams(MchtTrafficSerialForm record,HttpServletResponse response);
    
    TrafficAccount selectTrafficAccountByOrgId(MchtTrafficSerialForm record);

    TrafficAccount selectSumTraffic();

}
