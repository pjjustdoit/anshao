package com.pingan.qhzx.anshao.platform.common.dao.pg;

import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtRobot;
import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import org.apache.ibatis.annotations.Param;

public interface MchtRobotMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer mchtRobotId);

    int insert(MchtRobot record);

    int insertSelective(MchtRobot record);

    MchtRobot selectByPrimaryKey(Integer mchtRobotId);

    int updateByPrimaryKeySelective(MchtRobot record);

    int updateByPrimaryKey(MchtRobot record);
    
    MchtRobot selectMchtRobotByOrgId(Integer orgId);

    MchtRobot selectRobotByOrgCode(@Param("orgCode") String orgCode);
}