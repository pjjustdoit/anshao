package com.pingan.qhzx.anshao.platform.common.utils;

import javax.servlet.http.HttpSession;

import com.pingan.qhzx.anshao.platform.common.bean.UserSessionBean;

public class SessionUtils {

	private static final String USER_INFO = "userInfo";

	private HttpSession session;

	public SessionUtils(HttpSession session) {
		this.session = session;
	}
	
	public void setUserInfo(UserSessionBean userInfo) {
		session.setAttribute(USER_INFO, userInfo);
	}

	public UserSessionBean getUserInfo() {
		return (UserSessionBean) session.getAttribute(USER_INFO);
	}
}
