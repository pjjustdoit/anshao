package com.pingan.qhzx.anshao.platform.common.dao.pg;

import com.pingan.qhzx.anshao.platform.common.dto.pg.Dic;
import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;

public interface DicMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer dicId);

    int insert(Dic record);

    int insertSelective(Dic record);

    Dic selectByPrimaryKey(Integer dicId);

    int updateByPrimaryKeySelective(Dic record);

    int updateByPrimaryKey(Dic record);
}