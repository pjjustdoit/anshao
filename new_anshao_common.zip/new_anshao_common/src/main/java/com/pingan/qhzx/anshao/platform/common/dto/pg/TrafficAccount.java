package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;
import java.util.Date;

public class TrafficAccount extends BaseDTO {
    private Integer orgId;

    private Long trafficTotalNum;

    private Long trafficInitNum;

    private Long trafficUseNum;

    private Long trafficRemainNum;

    private Date cutoffDate;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Long getTrafficTotalNum() {
        return trafficTotalNum;
    }

    public void setTrafficTotalNum(Long trafficTotalNum) {
        this.trafficTotalNum = trafficTotalNum;
    }

    public Long getTrafficInitNum() {
        return trafficInitNum;
    }

    public void setTrafficInitNum(Long trafficInitNum) {
        this.trafficInitNum = trafficInitNum;
    }

    public Long getTrafficUseNum() {
        return trafficUseNum;
    }

    public void setTrafficUseNum(Long trafficUseNum) {
        this.trafficUseNum = trafficUseNum;
    }

    public Long getTrafficRemainNum() {
        return trafficRemainNum;
    }

    public void setTrafficRemainNum(Long trafficRemainNum) {
        this.trafficRemainNum = trafficRemainNum;
    }

    public Date getCutoffDate() {
        return cutoffDate;
    }

    public void setCutoffDate(Date cutoffDate) {
        this.cutoffDate = cutoffDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy == null ? null : updatedBy.trim();
    }
}