package com.pingan.qhzx.anshao.platform.common.service.model;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;
import com.pingan.pafa.redis.map.RedisMapBean;
import com.pingan.pafa.redis.queue.ConsumeListener;
import com.pingan.pafa.redis.queue.RedisQueue;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.service.IOrgService;
import com.pingan.qhzx.anshao.platform.common.service.model.api.IAnsirAPI;
import com.pingan.qhzx.anshao.platform.common.service.qa.IQuestionsAndAnswersService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Created by yuzilei022 on 16/10/12.
 */
@Service
public class CorpusSyncService implements ICorpusSyncService, ConsumeListener<Integer>, InitializingBean {


    private static final Logger logger = LoggerFactory.getLogger(CorpusSyncService.class);
    @Autowired
    private IQuestionsAndAnswersService answersService;

    @Autowired
    private IAnsirAPI api;

    @Autowired
    private IOrgService orgService;

    @Autowired
    @Qualifier("lock_factory")
    private RedisLockFactory lockFactory;

    @Autowired
    @Qualifier("syncCorpusOrgQueue")
    private RedisQueue<Integer> syncCorpusOrgQueue;

    @Autowired
    @Qualifier("corpusOrgMap")
    private RedisMapBean<String, Integer> corpusOrgMap;


    @Override
    public void syncCorpus(Integer orgId) {
        logger.info("sync corpus push org= [{}]: [{}]", orgId, corpusOrgMap.values());
        if (!corpusOrgMap.containsKey(orgId + "")) {
            logger.info("sync push succ:{}", orgId);
            corpusOrgMap.put(orgId + "", orgId);
            syncCorpusOrgQueue.push(orgId);
        }
    }

    @Override
    public void onReceiveMessages(Integer orgId) {
        logger.info("sync proc orgId:{}", orgId);
        RedisLock lock = lockFactory.getLock("syncCorpusLocker:orgId:" + orgId, 600);
        boolean b = lock.tryLock(5000);
        if (!b) { //can't lock
            syncCorpusOrgQueue.push(orgId);
            return;
        }
        try {
            corpusOrgMap.remove(orgId + "");
            _syncCorpus(orgId);
        } finally {
            lock.unlock();
        }
    }

    private void _syncCorpus(Integer orgId) {
        Org org = orgService.needSyncOrg(orgId);
        if (logger.isDebugEnabled()) {
            logger.debug("sync org = {}", JSON.toJSON(org));
        }
        if (org != null) {
            answersService.writerQAToCsv(org);
            api.createModel(Lists.newArrayList(org.getOrgCode()));
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        corpusOrgMap.clear();
    }
}
