package com.pingan.qhzx.anshao.platform.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.bean.knowledge.ZskClassifyPageDTO;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtCorpusCtxMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.ZskClassifyMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.dto.pg.ZskClassify;
import com.pingan.qhzx.anshao.platform.common.service.model.ICorpusSyncService;

@Service
public class KnowledgeBaseService implements IKnowledgeBaseService {

	@Autowired
	private ZskClassifyMapper zskClassifyMapper;

	@Autowired
	private MchtCorpusCtxMapper mchtCorpusCtxMapper;

	@Autowired
	private ICorpusSyncService corpusSyncService;

	@Override
	@Transactional
	public void addClassify(ZskClassify zskClassify) {
		zskClassifyMapper.insert(zskClassify);
		// 重建问答模型
		corpusSyncService.syncCorpus(zskClassify.getOrgId());
	}

	@Override
	@Transactional
	public void updateClassify(ZskClassify zskClassify) {
		zskClassifyMapper.updateByPrimaryKeySelective(zskClassify);
		// 重建问答模型
		corpusSyncService.syncCorpus(zskClassify.getOrgId());
	}

	@Override
	@Transactional
	public void deleteClassify(MchtCorpusCtx mchtCorpusCtx) {
		zskClassifyMapper.deleteByPrimaryKey(mchtCorpusCtx.getZskClassifyId());
		// 重建问答模型
		corpusSyncService.syncCorpus(mchtCorpusCtx.getOrgId());
	}

	@Override
	public List<ZskClassify> selectZskClassifyListByOrgId(Integer orgId) {
		return zskClassifyMapper.selectZskClassifyListByOrgId(orgId);
	}

	@Override
	public List<MchtCorpusCtx> selectMchtCorpusCtxList(MchtCorpusCtx mchtCorpusCtx) {
		return mchtCorpusCtxMapper.selectMchtCorpusCtxList(mchtCorpusCtx);
	}

	@Override
	public ZskClassify detailClassify(Integer zskClassifyId) {
		ZskClassify zskClassify = zskClassifyMapper.selectByPrimaryKey(zskClassifyId);
		return zskClassify;
	}

	@Override
	public PageInfo<ZskClassify> queryClassifyList(ZskClassifyPageDTO zskClassifyPageDTO) {
		// 设置页和页大小
		PageHelper.startPage(zskClassifyPageDTO.getCurrentPage(), zskClassifyPageDTO.getPageSize());
		List<ZskClassify> classifylist = zskClassifyMapper.queryClassifylist(zskClassifyPageDTO);
		return new PageInfo<ZskClassify>(classifylist);
	}

	@Override
	public List<ZskClassify> selectClassifyList(ZskClassify zskClassify) {
		return zskClassifyMapper.selectClassifyList(zskClassify);
	}
}
