package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;

import java.util.Date;

public class MchtCorpusCtxExt extends MchtCorpusCtx {

    private static final long serialVersionUID = 6856999518054966487L;

    private String classifyName;

    private String exactMatchFlagStr;

    private String effectiveFlagStr;

    public String getClassifyName() {
        return classifyName;
    }

    public void setClassifyName(String classifyName) {
        this.classifyName = classifyName;
    }

    public String getExactMatchFlagStr() {
        return exactMatchFlagStr;
    }

    public void setExactMatchFlagStr(String exactMatchFlagStr) {
        this.exactMatchFlagStr = exactMatchFlagStr;
    }

    public String getEffectiveFlagStr() {
        return effectiveFlagStr;
    }

    public void setEffectiveFlagStr(String effectiveFlagStr) {
        this.effectiveFlagStr = effectiveFlagStr;
    }
}