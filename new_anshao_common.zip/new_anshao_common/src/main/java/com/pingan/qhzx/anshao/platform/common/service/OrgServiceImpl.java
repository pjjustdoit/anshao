package com.pingan.qhzx.anshao.platform.common.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtCorpusOutlineMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.OrgMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.TrafficAccountMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusOutline;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.dto.pg.OrgExt;
import com.pingan.qhzx.anshao.platform.common.dto.pg.TrafficAccount;
import com.pingan.qhzx.anshao.platform.common.enums.OrgStatusEnum;
import com.pingan.qhzx.anshao.platform.common.enums.OrgTypeEnum;
import com.pingan.qhzx.anshao.platform.common.web.form.OrgForm;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class OrgServiceImpl implements IOrgService{
	
	private static final Logger logger = LoggerFactory.getLogger(OrgServiceImpl.class);
	
	@Autowired
	private OrgMapper orgMapper;
	
	@Autowired
	private MchtCorpusOutlineMapper mchtCorpusOutlineMapper;
	
	@Autowired
	private TrafficAccountMapper trafficAccountMapper;
	
	@Override
	public List<Org> selectByAuthCode(String authCode){
		return orgMapper.selectByAuthCode(authCode);
	}

	@Transactional
	@Override
	public int insertSelective(OrgForm orgForm) {
		Org orgTemp = propertyCopy(orgForm);
		Calendar curCal = Calendar.getInstance();
		Date curDate = curCal.getTime();
		orgTemp.setCreatedDate(curDate);
		orgTemp.setUpdatedDate(curDate);
		orgTemp.setAuthDate(curDate);
		orgTemp.setOrgStatus(OrgStatusEnum.COOPERATING.getCode());
		orgTemp.setOrgType(OrgTypeEnum.PARTNER.getCode());

		judgeExpireDate(orgTemp);
		
		int affectRows = orgMapper.insertSelective(orgTemp);
		TrafficAccount trafficAccount = new TrafficAccount();
		trafficAccount.setCreatedBy(orgForm.getCreatedBy());
		trafficAccount.setCreatedDate(curDate);
		trafficAccount.setOrgId(orgTemp.getOrgId());
		trafficAccount.setTrafficInitNum(orgForm.getTrafficInitNum());
		trafficAccount.setTrafficTotalNum(orgForm.getTrafficInitNum());
		trafficAccount.setTrafficRemainNum(orgForm.getTrafficInitNum());
		trafficAccount.setTrafficUseNum(0l);
		trafficAccount.setUpdatedBy(orgForm.getCreatedBy());
		trafficAccount.setUpdatedDate(curDate);
		trafficAccountMapper.insertSelective(trafficAccount);
		
		MchtCorpusOutline mchtCorpusOutline = new MchtCorpusOutline();

		mchtCorpusOutline.setCreatedBy(orgForm.getCreatedBy());
		mchtCorpusOutline.setCreatedDate(curDate);
		mchtCorpusOutline.setUpdatedBy(orgForm.getCreatedBy());
		mchtCorpusOutline.setUpdatedDate(curDate);
		mchtCorpusOutline.setOrgId(orgTemp.getOrgId());
		mchtCorpusOutline.setCorpusInitNum(orgForm.getCorpusTotalNum());
		mchtCorpusOutline.setCorpusTotalNum(orgForm.getCorpusTotalNum());
		mchtCorpusOutline.setCorpusSurplusNum(orgForm.getCorpusTotalNum());
		mchtCorpusOutline.setCorpususenum(0l);
		
		mchtCorpusOutlineMapper.insertSelective(mchtCorpusOutline);
		return affectRows;
	}
	/**
	 * 判断过期日期，并设置机构状态，该方法放在设置机构status之后调用，防止被覆盖
	 * @param orgTemp
	 */
	private void judgeExpireDate(Org orgTemp){
		Date expireDate = orgTemp.getExpireDate();
		if(expireDate != null && expireDateBeforeOrEqualCurrDate(expireDate)){
			orgTemp.setOrgStatus(OrgStatusEnum.PAUSE_COOPERATION.getCode());
		}else if(expireDate != null && !expireDateBeforeOrEqualCurrDate(expireDate)){
			orgTemp.setOrgStatus(OrgStatusEnum.COOPERATING.getCode());
		}
	}
	
	/**
	 * 由于过期时间是时间戳类型的，带有时分秒，故该方法用于只比较年月日
	 * 过期时间位于当前时间之前，返回true
	 * @param expireDate
	 * @return
	 * @throws Exception
	 */
	private boolean expireDateBeforeOrEqualCurrDate(Date expireDate){
		if(expireDate == null){
			return false;
		}
	
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        // 过期时间只关注到年月日
        try{
            Date curDate = sdf.parse(sdf.format(Calendar.getInstance().getTime()));
            expireDate = sdf.parse(sdf.format(expireDate));
            if(expireDate.before(curDate) || expireDate.equals(curDate)){
            	return true;
            }
        }catch(Exception e){
        	logger.error("{}",e);
        }
        return false;
	}

	@Override
	public Org selectByPrimaryKey(Integer orgId) {
		return orgMapper.selectByPrimaryKey(orgId);
	}

	@Override
	public int updateByPrimaryKeySelective(OrgForm orgForm,Org queryOrg) {
		Org orgTemp = propertyCopy(orgForm);
		
		orgTemp.setUpdatedDate(Calendar.getInstance().getTime());
		
		// 过期日期不传，且 机构状态更新状态为 1，则从数据库查询有效期，数据库的有效期小于等于当前日期，则设置为2099年
		if(!StringUtils.isBlank(orgForm.getOrgStatus()) && orgForm.getExpireDate() == null){
			// 只有当状态改变为 合作中才会去判断expireDate是否合理
	        if(orgForm.getOrgStatus().equals(OrgStatusEnum.COOPERATING.getCode())) {
	            Date expireDate = queryOrg.getExpireDate();
	            
	            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	            // 过期时间只关注到年月日
				if(this.expireDateBeforeOrEqualCurrDate(expireDate) == true){
		            try{
		            	orgTemp.setExpireDate(sdf.parse("2099-12-31"));
		            }catch(Exception e){
		            	logger.error("{}",e);
		            }
				}
	        }
		}
		
		judgeExpireDate(orgTemp);
		
		return orgMapper.updateByPrimaryKeySelective(orgTemp);
	}
	
	/**
	 * 属性值复制
	 * @param orgForm
	 * @return
	 */
	private Org propertyCopy(OrgForm orgForm){
		Org orgTemp = new Org();
		try {
			PropertyUtils.copyProperties(orgTemp, orgForm);
		} catch (Exception e) {
			logger.error("{}",e);
		}
		return orgTemp;
	}

	@Override
	public Map<String,Object> selectOrgList(OrgForm orgForm) {
		
    	
    	PageHelper.startPage(orgForm.getCurrentPage(),orgForm.getPageSize(),true);
    	List<OrgExt> orgList = selectOrgExtList(orgForm);
		
        PageInfo<OrgExt> orgPageInfo = new PageInfo<OrgExt>(orgList);

        Map<String,Object> resultMap = new HashMap<String,Object>();
        resultMap.put("totalCount",orgPageInfo.getTotal());
        resultMap.put("currentPage",orgPageInfo.getPageNum());
        resultMap.put("list",orgList);

        return resultMap;
	}

	public Org queryOrgByOrgCode(String orgCode) {
		return orgMapper.queryOrgByOrgCode(orgCode);
	}
	
	@Override
	public List<OrgExt> selectOrgExtList(OrgForm orgForm) {
		Map<String,Object> params = new HashMap<String,Object>();
		if(orgForm.getOrgId() != null) {
			params.put("orgId", orgForm.getOrgId());
		}
		if(!StringUtils.isBlank(orgForm.getOrgName())) {
			params.put("orgName", orgForm.getOrgName());
		}
		if(!StringUtils.isBlank(orgForm.getOrgStatus())) {
			params.put("orgStatus", orgForm.getOrgStatus());
		}
		if(!StringUtils.isBlank(orgForm.getContactName())) {
			params.put("contactName", orgForm.getContactName());
		}
		if(!StringUtils.isBlank(orgForm.getContactTel())) {
			params.put("contactTel", orgForm.getContactTel());
		}
		return orgMapper.selectOrgList(params);
	}

	@Override
	public List<Org> querySelectList(Integer orgId) {
		return orgMapper.querySelectList(orgId);
	}
	@Override
	public List<Org> queryByParams(OrgForm orgForm) {
		Map<String,Object> params = new HashMap<String,Object>();
		if(orgForm.getOrgId() != null){
			params.put("orgId", orgForm.getOrgId());
		}
		if(!StringUtils.isBlank(orgForm.getOrgName())){
			params.put("orgName", orgForm.getOrgName());
		}
		if(!StringUtils.isBlank(orgForm.getOrgCode())){
			params.put("orgCode", orgForm.getOrgCode());
		}
		return orgMapper.queryByParams(params);
	}

	@Override
	public List<Org> queryPartnerOrgs() {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("orgType", OrgTypeEnum.PARTNER.getCode());
		return orgMapper.queryByParams(params);
	}

	@Override
	public List<Org> queryOrgInExpire() {
		return orgMapper.queryOrgInExpire();
	}

	@Override
	public Org needSyncOrg(Integer orgId) {
		return orgMapper.needSyncOrg(orgId);
	}
}
