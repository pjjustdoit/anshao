package com.pingan.qhzx.anshao.platform.common.enums;

/**
 * Created by zhangshan193 on 16/10/9.
 */
public enum TargetUpdateFieldEnum {

    EXACT_MATCH_FLAG("exactMatchFlag","精确匹配"),
    ZSK_CLASSIFY_ID("zskClassifyId","分类"),
    EXPIRE_DATE("expireDate","有效期");

    private String code;
    private String desc;

    private TargetUpdateFieldEnum(String code,String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }
}
