package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;

import java.util.Date;

public class QaSerial extends BaseDTO {
    private Long qaSerialId;

    private String orgCode;

    private Integer orgId;

    private String custId;

    private String questionNo;

    private String serialNo;

    private Date submitDate;

    private String threshold;

    private String fuzzymatch;

    private String question;

    private String answer;

    private Date anwserDate;

    private Boolean ansirMatchFlag;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;
    private String responseSource;

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Long getQaSerialId() {
        return qaSerialId;
    }

    public void setQaSerialId(Long qaSerialId) {
        this.qaSerialId = qaSerialId;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode == null ? null : orgCode.trim();
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId == null ? null : custId.trim();
    }

    public String getQuestionNo() {
        return questionNo;
    }

    public void setQuestionNo(String questionNo) {
        this.questionNo = questionNo == null ? null : questionNo.trim();
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo == null ? null : serialNo.trim();
    }

    public Date getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(Date submitDate) {
        this.submitDate = submitDate;
    }

    public String getThreshold() {
        return threshold;
    }

    public void setThreshold(String threshold) {
        this.threshold = threshold == null ? null : threshold.trim();
    }

    public String getFuzzymatch() {
        return fuzzymatch;
    }

    public void setFuzzymatch(String fuzzymatch) {
        this.fuzzymatch = fuzzymatch == null ? null : fuzzymatch.trim();
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question == null ? null : question.trim();
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer == null ? null : answer.trim();
    }

    public Date getAnwserDate() {
        return anwserDate;
    }

    public void setAnwserDate(Date anwserDate) {
        this.anwserDate = anwserDate;
    }

    public Boolean getAnsirMatchFlag() {
        return ansirMatchFlag;
    }

    public void setAnsirMatchFlag(Boolean ansirMatchFlag) {
        this.ansirMatchFlag = ansirMatchFlag;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy == null ? null : updatedBy.trim();
    }

    public String getResponseSource() {
        return responseSource;
    }

    public void setResponseSource(String responseSource) {
        this.responseSource = responseSource;
    }
}