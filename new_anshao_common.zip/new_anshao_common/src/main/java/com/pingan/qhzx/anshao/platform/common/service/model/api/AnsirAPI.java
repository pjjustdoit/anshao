package com.pingan.qhzx.anshao.platform.common.service.model.api;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.qhzx.anshao.platform.common.bean.qa.SynchronizationQuestionBean;
import com.pingan.qhzx.anshao.platform.common.bean.qa.UnknowQuestionBean;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by yuzilei022 on 16/9/30.
 */
@Component
public class AnsirAPI implements IAnsirAPI {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(AnsirAPI.class);
    @ActionClient(name = "ansirqa.model.createmodel")
    public IServiceClient ansirCreateModel;

    @ActionClient(name = "ansirqa.chat.answer")
    public IServiceClient ansirAnswer;

    @ActionClient(name = "ansirqa.chat.unknow.question")
    public IServiceClient ansirUnknowQuestions;

    /**
     * 问答
     *
     * @param requestMap
     * @return
     */
    @Override
    public ServiceResults answer(Map<String, Object> requestMap) {
        log.info("调用问答：{}", requestMap);
        ServiceResults results = null;
        try {
            results = ansirAnswer.invoke(requestMap);
        } catch (Exception e) {
            log.error("", e);
        }
        log.info("问答返回：{}", results);
        return results;
    }

    /**
     * 创建模型
     *
     * @param orgs
     */
    @Override
    public void createModel(List<String> orgs) {
        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("orgId", orgs);
        log.info("create model request：{}", params);
        ServiceResults results = null;
        try {
            results = ansirCreateModel.invoke(params);
        } catch (Exception e) {
            log.error("create model error!", e);
        }
        log.info("create model response: {}", results);
    }

    /**
     * 未知问题同步
     *
     * @param unknowQuestionList
     * @return
     */
    @Override
    public Boolean ansirUnknowQuestionList(List<SynchronizationQuestionBean> unknowQuestionList) {
        Boolean flag = false;
        if (unknowQuestionList != null && unknowQuestionList.size() > 0) {
            List<UnknowQuestionBean> unknowQuestionBeanList = new ArrayList<UnknowQuestionBean>();
            for (SynchronizationQuestionBean synchronizationQuestionBean : unknowQuestionList) {
                UnknowQuestionBean unknowQuestionBean = new UnknowQuestionBean();
                unknowQuestionBean.setOrgId(synchronizationQuestionBean.getOrgCode());
                unknowQuestionBean.setAccountId(synchronizationQuestionBean.getCustId());
                unknowQuestionBean.setQuestionDate(synchronizationQuestionBean.getSubmitDate());
                String unknownType = synchronizationQuestionBean.getUnknownType();
                unknowQuestionBean.setQuestionSource(unknownType);
                unknowQuestionBean.setQuestionContent(synchronizationQuestionBean.getQuestion());
                unknowQuestionBeanList.add(unknowQuestionBean);
            }
            ServiceResults results = null;
            try {
                HashMap<String, Object> params = new HashMap<String, Object>();
                params.put("unknowQuestionBeanList", unknowQuestionBeanList);
                log.info("synchronization question request：{}", params);
                results = ansirUnknowQuestions.invoke(params);
                String code = results.getString("code");
                if (StringUtils.equals(code, "0")) {
                    flag = true;
                }
            } catch (Exception e) {
                log.error("synchronization question error!", e);
            }
            log.info("synchronization question response: {}", results);
        }
        return flag;
    }
}