package com.pingan.qhzx.anshao.platform.common.dao.pg;

import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.TrafficAccount;
import org.apache.ibatis.annotations.Param;

public interface TrafficAccountMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer orgId);

    int insert(TrafficAccount record);

    int insertSelective(TrafficAccount record);

    TrafficAccount selectByPrimaryKey(Integer orgId);

    int updateByPrimaryKeySelective(TrafficAccount record);

    int updateByPrimaryKey(TrafficAccount record);

    TrafficAccount selectByPrimaryKeyLock(Integer orgId);

    void updateAccountConsume(@Param("orgId") Integer orgId, @Param("batchNo") Long batchNo);

    TrafficAccount selectSumTraffic();
}