package com.pingan.qhzx.anshao.platform.common.dao.pg;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserAuth;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MenuDTO;

public interface MchtUserAuthMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer mchtUserAuthId);

    int insert(MchtUserAuth record);

    int insertSelective(MchtUserAuth record);

    MchtUserAuth selectByPrimaryKey(Integer mchtUserAuthId);

    int updateByPrimaryKeySelective(MchtUserAuth record);

    int updateByPrimaryKey(MchtUserAuth record);
    
    List<MenuDTO> selectMenuByMchtUserRoleId(Integer mchtUserRoleId);
    
    List<MchtUserAuth> selectAuthByOrgIdMchtUserId(@Param("orgId") Integer orgId,
    		@Param("mchtUserId") Integer mchtUserId);
    
    List<MenuDTO> selectAllOutMenuBy(String resClassify);
    
    
    List<MenuDTO> querySAInnerMenu(String roleCode);
}