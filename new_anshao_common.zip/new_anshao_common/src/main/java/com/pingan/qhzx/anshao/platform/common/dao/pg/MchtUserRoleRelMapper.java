package com.pingan.qhzx.anshao.platform.common.dao.pg;

import org.apache.ibatis.annotations.Param;

import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRoleRel;

public interface MchtUserRoleRelMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer mchtUserRoleRelId);
    
    int deleteBy(@Param("mchtUserId")Integer mchtUserId);

    int insert(MchtUserRoleRel record);

    int insertSelective(MchtUserRoleRel record);

    MchtUserRoleRel selectByPrimaryKey(Integer mchtUserRoleRelId);

    int updateByPrimaryKeySelective(MchtUserRoleRel record);

    int updateByPrimaryKey(MchtUserRoleRel record);
    
    Long selectCountByUserRoleId(Integer mchtUserRoleId);
}