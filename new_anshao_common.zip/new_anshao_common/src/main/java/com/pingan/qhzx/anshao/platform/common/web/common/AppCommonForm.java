package com.pingan.qhzx.anshao.platform.common.web.common;

import java.io.Serializable;

/**
 * Created by YUZILEI869 on 2015-12-16.
 */
public class AppCommonForm implements Serializable {

    private static final long serialVersionUID = -4761724182580273230L;

    /**
     * 签名	Y	请求参数按字母顺序排序拼接字符串，md5
     */
    private String sign;

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}
