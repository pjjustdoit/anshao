package com.pingan.qhzx.anshao.platform.common.service.wxhome;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by peijian280 on 17/2/8.
 */
public interface IWxHomeService {

	Map<String, String> acceptMessage(HttpServletRequest request);

	String sendMessage(Map<String, String> acceptMessagemMap, String answer);

}
