package com.pingan.qhzx.anshao.platform.common.dao.pg;

import com.pingan.qhzx.anshao.platform.common.bean.qa.SynchronizationQuestionBean;
import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.QaSerial;
import com.pingan.qhzx.anshao.platform.common.dto.reportStatistics.SelectTrafficDTO;

import java.util.List;

public interface QaSerialMapper extends BaseMapper {
	int deleteByPrimaryKey(Long qaSerialId);

	int insert(QaSerial record);

	Long selectQaSerialId();

	int insertSelective(QaSerial record);

	QaSerial selectByPrimaryKey(Long qaSerialId);

	int updateByPrimaryKeySelective(QaSerial record);

	int updateByPrimaryKey(QaSerial record);

	List<QaSerial> selectQaSerialList(SelectTrafficDTO selectTrafficDTO);
}