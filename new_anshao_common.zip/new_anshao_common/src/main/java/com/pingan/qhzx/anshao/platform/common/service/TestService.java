package com.pingan.qhzx.anshao.platform.common.service;

import org.springframework.stereotype.Service;

@Service
public class TestService implements ITestService {

	@Override
	public String getResult(String variable) {
		String newValue = variable + ",test success";
		return newValue;
	}

}
