package com.pingan.qhzx.anshao.platform.common.dao.pg;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.pingan.qhzx.anshao.platform.common.bean.user.UserSearchCondition;
import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;

public interface MchtUserMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer mchtUserId);

    int insert(MchtUser record);

    int insertSelective(MchtUser record);

    MchtUser selectByPrimaryKey(Integer mchtUserId);

    int updateByPrimaryKeySelective(MchtUser record);

    int updateByPrimaryKey(MchtUser record);
    
    MchtUser selectByLoginName(String loginName);
    
    List<MchtUser> queryAllUserList(UserSearchCondition userSearchCondition);
    
    List<MchtUser> queryUserList(UserSearchCondition userSearchCondition);
    
    MchtUser selectBy(@Param("mchtUserId")Integer mchtUserId, @Param("loginName") String loginNameSession);
    
    Long checkRepeat(MchtUser mchtUser);
    
    Long queryUserPartnerCount(Integer orgId);
    
    MchtUser selectForPwdChange(@Param("loginName") String loginName, @Param("userPwd") String userPwd);
    
    MchtUser queryUpdateSelectList(Integer mchtUserId);
}