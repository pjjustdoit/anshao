package com.pingan.qhzx.anshao.platform.common.service.role;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.bean.ValidResult;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtUserRoleAuthRelMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtUserRoleMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtUserRoleRelMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.OrgMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserAuth;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRole;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRoleAuthRel;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MenuDTO;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.enums.DicCodeEnum;
import com.pingan.qhzx.anshao.platform.common.enums.OrgTypeEnum;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.mchtUser.IMchtUserService;

@Service
public class RoleService implements IRoleService {

	@Autowired
	private MchtUserRoleMapper mchtUserRoleMapper;

	@Autowired
	private MchtUserRoleRelMapper mchtUserRoleRelMapper;

	@Autowired
	private MchtUserRoleAuthRelMapper mchtUserRoleAuthRelMapper;

	@Autowired
	private IMchtUserService mchtUserService;

	@Autowired
	private OrgMapper orgMapper;

	private List<MenuDTO> OuterMenuList;

	/**
	 * 角色查询列表
	 */
	@Override
	public PageInfo<MchtUserRole> getMchtUserRoleList(Integer currentPage, Integer pageSize, Integer orgId,
			String loginNameSession, String roleCodeSession) {
		PageHelper.startPage(currentPage, pageSize);
		List<MchtUserRole> roleList = null;
		if (DicCodeEnum.SUPER_ROLE.getCode().equals(roleCodeSession)) {
			roleList = mchtUserRoleMapper.queryAllRoleList();
		} else {
			roleList = mchtUserRoleMapper.queryRoleList(loginNameSession, orgId);
		}

		return new PageInfo<MchtUserRole>(roleList);
	}

	/**
	 * 获取角色信息
	 */
	@Override
	public ValidResult roleAddInfo(String roleCodeSession, Integer mchtUserRoleId, Integer orgId,
			List<MenuDTO> menuListSession) {
		List<MenuDTO> menuList = null;

		HashMap<String, Object> data = new HashMap<String, Object>();

		Org org = orgMapper.selectByPrimaryKey(orgId);

		if (org == null) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}

		menuList = getMenuList(org.getOrgType(), roleCodeSession, menuListSession);

		data.put("menus", menuList);
		return ValidResult.createSuccessResult(data);
	}
	
	@Override
	public ValidResult roleUpdOrgChangeInfo(String roleCodeSession, Integer mchtUserRoleId, Integer orgId,
			List<MenuDTO> menuListSession) {
		
		HashMap<String, Object> data = new HashMap<String, Object>();
		String mchtUserAuthSelected = "";
		List<MenuDTO> menuList = null;

		MchtUserRole mchtUserRole = mchtUserRoleMapper.selectRoleInfoByPrimaryKey(mchtUserRoleId);

		if (mchtUserRole == null) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}

		Org org = orgMapper.selectByPrimaryKey(orgId);
		if (org == null) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}

		// 查询该角色下是否有用户
		if (mchtUserRoleRelMapper.selectCountByUserRoleId(mchtUserRoleId) > 0) {
			return ValidResult.createValidResult(ResponseEnum.ROLE_CAN_NOT_CHANGE_ORG);
		}
		
		menuList = getMenuList(org.getOrgType(), roleCodeSession, menuListSession);
		
		data.put("mchtUserAuthSelected", mchtUserAuthSelected);

		data.put("menus", menuList);
		return ValidResult.createSuccessResult(data);
	}

	@Override
	public ValidResult roleUpdInfo(String roleCodeSession, Integer mchtUserRoleId, Integer orgId,
			List<MenuDTO> menuListSession, String loginNameSession) {
		List<MenuDTO> menuList = null;
		MchtUserRole mchtUserRole = null;
		String mchtUserAuthSelected = "";
		List<MchtUserRoleAuthRel> mchtUserRoleAuthRelList = null;

		HashMap<String, Object> data = new HashMap<String, Object>();

		mchtUserRole = mchtUserRoleMapper.selectRoleInfoByPrimaryKey(mchtUserRoleId);
		if (mchtUserRole == null) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}

		Org org = orgMapper.selectByPrimaryKey(mchtUserRole.getOrgId());
		if (org == null) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}

		// 只能编辑自己创建的
		if (!mchtUserRole.getCreatedBy().equals(loginNameSession)) {
			return ValidResult.createValidResult(ResponseEnum.ROLE_AUTH_FAILURE);
		}

		// 更换机构时判断是否已关联用户
		// if (orgId != mchtUserRole.getOrgId()) {
		// // 查询该角色下是否有用户
		// if (mchtUserRoleRelMapper.selectCountByUserRoleId(mchtUserRoleId) >
		// 0) {
		// return
		// ValidResult.createValidResult(ResponseEnum.ROLE_CAN_NOT_CHANGE_ORG);
		// }
		// }

		// 更换机构时
		// if (orgId == mchtUserRole.getOrgId()) {
		mchtUserRoleAuthRelList = mchtUserRoleAuthRelMapper.selectByRoleId(mchtUserRoleId);
		if (mchtUserRoleAuthRelList != null && mchtUserRoleAuthRelList.size() > 0) {
			for (MchtUserRoleAuthRel mchtUserRoleAuthRel : mchtUserRoleAuthRelList) {
				mchtUserAuthSelected += mchtUserRoleAuthRel.getMchtUserAuthId() + "|";
			}
			mchtUserAuthSelected = mchtUserAuthSelected.substring(0, mchtUserAuthSelected.length() - 1);
		}
		// }

		menuList = getMenuList(org.getOrgType(), roleCodeSession, menuListSession);

		data.put("orgId", mchtUserRole.getOrgId());
		data.put("orgName", mchtUserRole.getOrgName());
		data.put("roleName", mchtUserRole.getRoleName());
		data.put("roleDesc", mchtUserRole.getRoleDesc());
		data.put("mchtUserAuthSelected", mchtUserAuthSelected);

		data.put("menus", menuList);
		return ValidResult.createSuccessResult(data);

	}

	private List<MenuDTO> getMenuList(String orgType, String roleCodeSession, List<MenuDTO> menuListSession) {
		
		List<MenuDTO> menuList = null;
		
		if (OrgTypeEnum.PARTNER.getCode().equals(orgType)
				&& DicCodeEnum.SUPER_ROLE.getCode().equals(roleCodeSession)) {
			// 超级用户、外部机构
			if (OuterMenuList == null || OuterMenuList.size() == 0) {
				OuterMenuList = mchtUserService.queryAllOutMenu();
			}
			menuList = OuterMenuList;
		} else {
			if (OrgTypeEnum.INTERNAL.getCode().equals(orgType)
					&& DicCodeEnum.SUPER_ROLE.getCode().equals(roleCodeSession)) {
				menuList = mchtUserService.querySAInnerMenu(DicCodeEnum.SUPER_ROLE.getCode());
			} else {
				menuList = menuListSession;
			}
			
		}
		
		return menuList;
	}
	
	/**
	 * 角色编辑
	 */
	@Transactional
	@Override
	public ValidResult roleUpdate(String loginNameSession, Integer mchtUserRoleId, String roleName, String roleDesc,
			String mchtUserAuthSelected, List<MchtUserAuth> auths, String roleCodeSession, Integer orgId) {

		// 权限不能超出创建用户的权限
		List<String> mchtUserAuthSelectedList = Arrays.asList(mchtUserAuthSelected.split("\\|"));

		if (!DicCodeEnum.SUPER_ROLE.getCode().equals(roleCodeSession)) {
			if (roleAuth(mchtUserAuthSelectedList, auths)) {
				return ValidResult.createValidResult(ResponseEnum.ROLE_AUTH_FAILURE);
			}
		}
		
		// 角色表更新
		MchtUserRole mchtUserRole = mchtUserRoleMapper.selectByPrimaryKey(mchtUserRoleId);
		if (mchtUserRole == null) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}
		
		// 更换机构时判断是否已关联用户
		if (orgId != mchtUserRole.getOrgId()) {
			// 查询该角色下是否有用户
			if (mchtUserRoleRelMapper.selectCountByUserRoleId(mchtUserRoleId) > 0) {
				return ValidResult.createValidResult(ResponseEnum.ROLE_CAN_NOT_CHANGE_ORG);
			}
		}
		
		// 只能编辑自己创建的
		if (!mchtUserRole.getCreatedBy().equals(loginNameSession)) {
			return ValidResult.createValidResult(ResponseEnum.ROLE_AUTH_FAILURE);
		}
		
		// 角色名重复判断
		if (checkRoleNameRepeat(mchtUserRole.getMchtUserRoleId(), roleName)) {
			return ValidResult.createValidResult(ResponseEnum.ROLE_NAME_EXIT);
		}
		
		Date now = new Date();
		String updatedBy = loginNameSession;
		mchtUserRole.setOrgId(orgId);
		mchtUserRole.setRoleName(roleName);
		mchtUserRole.setRoleDesc(roleDesc);
		mchtUserRole.setUpdatedBy(updatedBy);
		mchtUserRole.setUpdatedDate(now);
		mchtUserRoleMapper.updateByPrimaryKeySelective(mchtUserRole);
		
		// 先删除再添加
		mchtUserRoleAuthRelMapper.deleteByMchtUserRoleId(mchtUserRoleId);
		insertMchtUserRoleAuthRel(mchtUserAuthSelectedList, mchtUserRoleId, updatedBy, now);

		return ValidResult.createSuccessResult();
	}

	/**
	 * 角色新增
	 */
	@Transactional
	@Override
	public ValidResult roleAdd(Integer mchtUserId, Integer orgIdSession, MchtUserRole userRole,
			String mchtUserAuthSelected, String roleCodeSession, List<MchtUserAuth> auths, String LoginNameSession) {
		
		Org org = orgMapper.selectByPrimaryKey(userRole.getOrgId());
		if (org == null) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}
		
		List<String> mchtUserAuthSelectedList = Arrays.asList(mchtUserAuthSelected.split("\\|"));
		
		if (DicCodeEnum.SUPER_ROLE.getCode().equals(roleCodeSession)) {
			// 超级用户
			if (roleAddFlg(userRole.getOrgId())) {
				return ValidResult.createValidResult(ResponseEnum.ROLE_PARTERN_ONLY_ONE);
			}
		} else {
			// 非超级用户只能创建所属的机构的角色
			if (orgIdSession != userRole.getOrgId()) {
				return ValidResult.createValidResult(ResponseEnum.ROLE_AUTH_FAILURE);
			}
			
			// 权限不能超出创建用户的权限
			if (roleAuth(mchtUserAuthSelectedList, auths)) {
				return ValidResult.createValidResult(ResponseEnum.ROLE_AUTH_FAILURE);
			}
		}

		if (checkRoleNameRepeat(null, userRole.getRoleName())) {
			return ValidResult.createValidResult(ResponseEnum.ROLE_NAME_EXIT);
		}

		// 角色表插入
		String createdBy = LoginNameSession;
		Date now = new Date();		
		String radomStr = RandomStringUtils.random(8, true, true);
		userRole.setRoleCode(userRole.getOrgId() + "_" + radomStr);
		userRole.setCreatedBy(createdBy);
		userRole.setUpdatedBy(createdBy);
		userRole.setCreatedDate(now);
		userRole.setUpdatedDate(now);
		mchtUserRoleMapper.insert(userRole);

		insertMchtUserRoleAuthRel(mchtUserAuthSelectedList, userRole.getMchtUserRoleId(), createdBy, now);

		return ValidResult.createSuccessResult();
	}

	/**
	 * 角色删除
	 */

	@Transactional
	@Override
	public ValidResult roleDel(Integer mchtUserRoleId, String loginNameSession) {
		// 判断角色是否可操作
		if (!roleOperate(loginNameSession, mchtUserRoleId)) {
			return ValidResult.createValidResult(ResponseEnum.ROLE_AUTH_FAILURE);
		}

		// 查询该角色下是否有用户
		if (mchtUserRoleRelMapper.selectCountByUserRoleId(mchtUserRoleId) > 0) {
			return ValidResult.createValidResult(ResponseEnum.ROLE_CANNOT_DEL);
		}

		mchtUserRoleAuthRelMapper.deleteByMchtUserRoleId(mchtUserRoleId);
		mchtUserRoleMapper.deleteByPrimaryKey(mchtUserRoleId);
		
		return ValidResult.createSuccessResult();
	}

	@Override
	public List<MchtUserRole> queryUserUpdateSelectList(String loginNameSession, Integer orgId) {
		return mchtUserRoleMapper.queryUserUpdateSelectList(loginNameSession, orgId);
	}
	
	@Override
	public List<MchtUserRole> queryUserQuerySelectList(String loginNameSession, Integer orgId) {
		return mchtUserRoleMapper.queryUserQuerySelectList(loginNameSession, orgId);
	}

	/**
	 * 判断该角色是否能被操作
	 * 
	 * @return
	 */
	private boolean roleOperate(String loginNameSession, Integer mchtUserRoleId) {
		boolean result = false;

		MchtUserRole mchtUserRole = mchtUserRoleMapper.selectByPrimaryKey(mchtUserRoleId);

		if (mchtUserRole != null) {
			if (mchtUserRole.getCreatedBy().equals(loginNameSession)) {
				result = true;
			}
		}

		return result;
	}

	/**
	 * 仅能给外部机构创建一个角色（管理员）
	 * 
	 * @return
	 */
	private boolean roleAddFlg(Integer orgId) {
		Long count = mchtUserRoleMapper.selectPaterRoleCount(orgId);
		return count > 0;
	}

	/**
	 * 新编辑的角色
	 * 
	 * @param mchtUserAuthSelectedList
	 * @param auths
	 * @return
	 */
	private boolean roleAuth(List<String> mchtUserAuthSelectedList, List<MchtUserAuth> auths) {
		boolean result = false;
		for (String userAuthSelected : mchtUserAuthSelectedList) {
			int flg = 0;
			for (MchtUserAuth mchtUserAuth : auths) {
				if (userAuthSelected.equals(String.valueOf(mchtUserAuth.getMchtUserAuthId()))) {
					flg = flg + 1;
				}
			}
			if (flg == 0) {
				return true;
			}
		}
		return result;
	}
	
	/**
	 * 角色权限表关系
	 * @param mchtUserAuthSelectedList
	 * @param MchtUserRoleId
	 * @param createdBy
	 * @param now
	 */
	private void insertMchtUserRoleAuthRel(List<String> mchtUserAuthSelectedList, Integer MchtUserRoleId,
			String createdBy, Date now) {
		// 角色权限关系表
		for (String userAuthSelected : mchtUserAuthSelectedList) {
			MchtUserRoleAuthRel mchtUserRoleAuthRel = new MchtUserRoleAuthRel();
			mchtUserRoleAuthRel.setMchtUserAuthId(Integer.parseInt(userAuthSelected));
			mchtUserRoleAuthRel.setMchtUserRoleId(MchtUserRoleId);
			mchtUserRoleAuthRel.setCreatedBy(createdBy);
			mchtUserRoleAuthRel.setUpdatedBy(createdBy);
			mchtUserRoleAuthRel.setCreatedDate(now);
			mchtUserRoleAuthRel.setUpdatedDate(now);
			mchtUserRoleAuthRelMapper.insert(mchtUserRoleAuthRel);
		}
	}
	
	/**
	 * 角色名不能重复
	 * @return
	 */
	private boolean checkRoleNameRepeat(Integer MchtUserRoleId, String roleName) {
		boolean result = false;
		Long count = mchtUserRoleMapper.queryCountByRoleName(MchtUserRoleId, roleName);
		if (count > 0) {
			result = true;
		}
		return result;
	}
}
