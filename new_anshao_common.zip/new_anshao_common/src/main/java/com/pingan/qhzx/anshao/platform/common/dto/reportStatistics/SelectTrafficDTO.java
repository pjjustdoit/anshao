package com.pingan.qhzx.anshao.platform.common.dto.reportStatistics;

import java.util.Date;

/**
 * 流量查询
 * 
 * @author LIUPENGLIANG375 创建时间：2016年10月9日 下午3:20:03
 */
public class SelectTrafficDTO {
	
	private Integer orgId;

	private String queryStartDate;

	private String queryEndDate;

	private Date startDate;

	private Date endDate;

	private String serialType;

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public String getQueryStartDate() {
		return queryStartDate;
	}

	public void setQueryStartDate(String queryStartDate) {
		this.queryStartDate = queryStartDate;
	}

	public String getQueryEndDate() {
		return queryEndDate;
	}

	public void setQueryEndDate(String queryEndDate) {
		this.queryEndDate = queryEndDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getSerialType() {
		return serialType;
	}

	public void setSerialType(String serialType) {
		this.serialType = serialType;
	}
}
