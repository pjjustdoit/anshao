package com.pingan.qhzx.anshao.platform.common.service.qa;

import java.util.List;

import com.pingan.qhzx.anshao.platform.common.bean.qa.SynchronizationQuestionBean;
import com.pingan.qhzx.anshao.platform.common.dto.qa.SynchronizationQuestionDTO;

/**
 * 同步未知问题
 * 
 * @author LIUPENGLIANG375 创建时间：2016年10月17日 下午5:26:09
 */
public interface ISynchronizationQuestionService {

	/**
	 * 查询seq_sync_unknown_qa_batch_no
	 * 
	 * @return Integer
	 */
	Integer selectBatchNo();

	/**
	 * 把状态为新建和失败并且时间是最近三天的问题的状态修改为更新中
	 * 
	 * @param synchronizationQuestionDTO
	 * @return int
	 */
	int updateSyncSatus(SynchronizationQuestionDTO synchronizationQuestionDTO);

	/**
	 * 
	 * @param batchNo
	 * @return List<SynchronizationQuestionBean>
	 */
	List<SynchronizationQuestionBean> seltQaSerListByOrgIdSerNo(Integer batchNo);

	/**
	 * 每日处理未知问题列表
	 * 
	 * @return Integer
	 */
	Integer unknowQuestions();

	/**
	 * 把状态为更新中的状态修改为更新完成或者更新失败
	 * 
	 * @param synchronizationQuestionDTO
	 */
	void updateSyncSatuByBatchNo(SynchronizationQuestionDTO synchronizationQuestionDTO);
}
