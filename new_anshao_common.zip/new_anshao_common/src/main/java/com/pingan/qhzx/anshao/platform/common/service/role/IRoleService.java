package com.pingan.qhzx.anshao.platform.common.service.role;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.bean.ValidResult;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserAuth;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRole;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MenuDTO;

public interface IRoleService {

	PageInfo<MchtUserRole> getMchtUserRoleList(Integer currentPage, Integer pageSize,
			Integer orgId, String loginNameSession, String roleCodeSession);
	
	ValidResult roleUpdate(String loginNameSession, Integer mchtUserRoleId,
			String roleName, String roleDesc, String mchtUserAuthSelected,
			List<MchtUserAuth> auths, String roleCodeSession, Integer orgId);
	
	ValidResult roleDel(Integer mchtUserRoleId, String loginNameSession);
	
	ValidResult roleAdd(Integer mchtUserId, Integer orgIdSession, MchtUserRole userRole,
			String mchtUserAuthSelected, String roleCodeSession, List<MchtUserAuth> auths,
			String LoginNameSession);
	
	ValidResult roleAddInfo(String roleCodeSession, Integer mchtUserRoleId,
			Integer orgId, List<MenuDTO> menuListSession);
	
	ValidResult roleUpdOrgChangeInfo(String roleCodeSession, Integer mchtUserRoleId,
			Integer orgId, List<MenuDTO> menuListSession);
	
	ValidResult roleUpdInfo(String roleCodeSession, Integer mchtUserRoleId,
			Integer orgId, List<MenuDTO> menuListSession, String loginNameSession);
	
	List<MchtUserRole> queryUserUpdateSelectList(String loginNameSession, Integer orgId);
	
	List<MchtUserRole> queryUserQuerySelectList(String loginNameSession, Integer orgId);
}
