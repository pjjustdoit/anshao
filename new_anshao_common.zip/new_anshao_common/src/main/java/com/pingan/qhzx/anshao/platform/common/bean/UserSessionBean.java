package com.pingan.qhzx.anshao.platform.common.bean;

import java.io.Serializable;
import java.util.List;

import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserAuth;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRole;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MenuDTO;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;

/**
 * Created by YUZILEI869 on 2015-12-10.
 */
public class UserSessionBean extends BaseBean implements Serializable {
	
	private static final long serialVersionUID = -1358653250690227011L;

	private MchtUser mchtUser;
    
    private Org org;
    
    private List<MchtUserAuth> auths;
    
    private List<MchtUserRole> roles;
    
    private List<MenuDTO> menus;
    
    public UserSessionBean(MchtUser mchtUser, Org org, List<MchtUserAuth> auths,
    		List<MchtUserRole> roles, List<MenuDTO> menus) {
    	this.mchtUser = mchtUser;
    	this.org = org;
    	this.auths = auths;
    	this.roles = roles;
    	this.menus = menus;
    }

	public MchtUser getMchtUser() {
		return mchtUser;
	}

	public void setMchtUser(MchtUser mchtUser) {
		this.mchtUser = mchtUser;
	}

	public Org getOrg() {
		return org;
	}

	public void setOrg(Org org) {
		this.org = org;
	}

	public List<MchtUserAuth> getAuths() {
		return auths;
	}

	public void setAuths(List<MchtUserAuth> auths) {
		this.auths = auths;
	}

	public List<MchtUserRole> getRoles() {
		return roles;
	}

	public void setRoles(List<MchtUserRole> roles) {
		this.roles = roles;
	}
	
	public Integer getOrgId() {
		return this.org.getOrgId();
	}
	
	public Integer getMchtUserId() {
		return this.mchtUser.getMchtUserId();
	}
	
    public String getLoginName() {
        return this.mchtUser.getLoginName();
    }
	
	public List<MenuDTO> getMenus() {
		return menus;
	}

	public void setMenus(List<MenuDTO> menus) {
		this.menus = menus;
	}

	public String getRoleCode() {
		if (roles != null &&  roles.size() > 0) { 
			return roles.get(0).getRoleCode();
		}
		return null;
	}
}
