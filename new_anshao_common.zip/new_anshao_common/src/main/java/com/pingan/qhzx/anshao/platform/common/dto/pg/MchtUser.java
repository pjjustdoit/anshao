package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;
import java.util.Date;

public class MchtUser extends BaseDTO {
    private Integer mchtUserId;

    private Integer orgId;

    private String loginName;

    private String userPwd;

    private String userName;

    private String mobile;

    private String userEmail;

    private String userStatus;

    private String forceChangePwdFlag;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;
    
    private String orgName;
    
    private String orgType;
    
    private Integer mchtUserRoleId;

    public Integer getMchtUserId() {
        return mchtUserId;
    }

    public void setMchtUserId(Integer mchtUserId) {
        this.mchtUserId = mchtUserId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName == null ? null : loginName.trim();
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd == null ? null : userPwd.trim();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail == null ? null : userEmail.trim();
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus == null ? null : userStatus.trim();
    }

    public String getForceChangePwdFlag() {
        return forceChangePwdFlag;
    }

    public void setForceChangePwdFlag(String forceChangePwdFlag) {
        this.forceChangePwdFlag = forceChangePwdFlag == null ? null : forceChangePwdFlag.trim();
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy == null ? null : updatedBy.trim();
    }
    
    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName == null ? null : orgName.trim();
    }
    
    public String getOrgType() {
        return orgType;
    }

    public void setOrgType(String orgType) {
        this.orgType = orgType == null ? null : orgType.trim();
    }

	public Integer getMchtUserRoleId() {
		return mchtUserRoleId;
	}

	public void setMchtUserRoleId(Integer mchtUserRoleId) {
		this.mchtUserRoleId = mchtUserRoleId;
	}
}