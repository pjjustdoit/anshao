package com.pingan.qhzx.anshao.platform.common.web.common;

import com.google.common.html.HtmlEscapers;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import java.beans.PropertyEditorSupport;

/**
 * Created by yuzilei869 on 16/7/21.
 */
public abstract class CommonController {
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, new PropertyEditorSupport() {
            @Override
            public String getAsText() {
                Object value = getValue();
                return value != null ? value.toString() : "";
            }

            @Override
            public void setAsText(String text) throws IllegalArgumentException {
                setValue(text == null ? null : HtmlEscapers.htmlEscaper().escape(text).trim());
            }
        });
    }
}
