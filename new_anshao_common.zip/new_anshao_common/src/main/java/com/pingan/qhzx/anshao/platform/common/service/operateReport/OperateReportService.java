package com.pingan.qhzx.anshao.platform.common.service.operateReport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.bean.operateReport.OperateReporBean;
import com.pingan.qhzx.anshao.platform.common.bean.operateReport.OrgPageDTO;
import com.pingan.qhzx.anshao.platform.common.dao.pg.OrgMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;

@Service
public class OperateReportService implements IOperateReportService {

	@Autowired
	private OrgMapper orgMapper;
	
	@Override
	public PageInfo<OperateReporBean> selectOperateReportPageList(OrgPageDTO orgPageDTO) {
		// 设置页和页大小
		PageHelper.startPage(orgPageDTO.getCurrentPage(), orgPageDTO.getPageSize());
		Org org=new Org();
		org.setOrgName(orgPageDTO.getOrgName());
		org.setOrgCode(orgPageDTO.getOrgCode());
		org.setOrgType(orgPageDTO.getOrgType());
		List<OperateReporBean> list = orgMapper.selectOperateReportList(org);
		return new PageInfo<OperateReporBean>(list);
	}

	@Override
	public List<OperateReporBean> selectOperateReportList(Org org) {
		return orgMapper.selectOperateReportList(org);
	}
}
