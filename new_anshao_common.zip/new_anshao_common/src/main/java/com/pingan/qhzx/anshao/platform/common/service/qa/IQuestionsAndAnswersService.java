package com.pingan.qhzx.anshao.platform.common.service.qa;

import java.util.List;

import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;

/**
 * 问答列表
 * 
 * @author LIUPENGLIANG375 创建时间：2016年10月11日 上午9:29:11
 */
public interface IQuestionsAndAnswersService {

	/**
	 * 根据orgId和effectiveFlag查询问答列表
	 * 
	 * @param mchtCorpusCtx
	 * @return List<MchtCorpusCtx>
	 */
	List<MchtCorpusCtx> selMchtCorListByorgIdEffect(MchtCorpusCtx mchtCorpusCtx);

	/**
	 * 把问答列表存储到csv文件
	 * 
	 * @param org
	 */
	void writerQAToCsv(Org org);
}
