package com.pingan.qhzx.anshao.platform.common.dto.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

/**
 * Created by yuzilei022 on 16/9/23.
 */
@Document
public class TrafficSerialDetail {
    @Id
    @Indexed
    private String trafficSerialDetailId;

    private String serialNo;

    private Date serialDate;

    public String getTrafficSerialDetailId() {
        return trafficSerialDetailId;
    }

    public void setTrafficSerialDetailId(String trafficSerialDetailId) {
        this.trafficSerialDetailId = trafficSerialDetailId;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public Date getSerialDate() {
        return serialDate;
    }

    public void setSerialDate(Date serialDate) {
        this.serialDate = serialDate;
    }
}
