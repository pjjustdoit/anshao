package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;
import java.util.Date;

public class MchtUserRoleAuthRel extends BaseDTO {
    private Integer mchtUserRoleAuthRelId;

    private Integer mchtUserRoleId;

    private Integer mchtUserAuthId;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;

    public Integer getMchtUserRoleAuthRelId() {
        return mchtUserRoleAuthRelId;
    }

    public void setMchtUserRoleAuthRelId(Integer mchtUserRoleAuthRelId) {
        this.mchtUserRoleAuthRelId = mchtUserRoleAuthRelId;
    }

    public Integer getMchtUserRoleId() {
        return mchtUserRoleId;
    }

    public void setMchtUserRoleId(Integer mchtUserRoleId) {
        this.mchtUserRoleId = mchtUserRoleId;
    }

    public Integer getMchtUserAuthId() {
        return mchtUserAuthId;
    }

    public void setMchtUserAuthId(Integer mchtUserAuthId) {
        this.mchtUserAuthId = mchtUserAuthId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy == null ? null : updatedBy.trim();
    }
}