package com.pingan.qhzx.anshao.platform.common.web.form;

import org.apache.commons.lang.StringUtils;

import com.pingan.qhzx.anshao.platform.common.web.common.PageForm;

public class UserForm extends PageForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 434015333418243634L;

	private String loginName;
	
	private String userName;
	
	private String userStatus;

	private Integer mchtUserRoleId;
	
	private Integer mchtUserId;
	
	private Integer orgId;
	
	private String userEmail;
	
	private String mobile;
	

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public Integer getMchtUserRoleId() {
		return mchtUserRoleId;
	}

	public void setMchtUserRoleId(Integer mchtUserRoleId) {
		this.mchtUserRoleId = mchtUserRoleId;
	}

	public Integer getMchtUserId() {
		return mchtUserId;
	}

	public void setMchtUserId(Integer mchtUserId) {
		this.mchtUserId = mchtUserId;
	}

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	public boolean checkEmpty() {
		boolean result = false;
		if (orgId == null
				|| mchtUserRoleId == null
				|| StringUtils.isBlank(userStatus)
				|| StringUtils.isBlank(loginName)
				|| StringUtils.isBlank(userName)
				|| StringUtils.isBlank(userEmail)
				|| StringUtils.isBlank(mobile)) {
			result = true;
		}
		return result;
	}
}
