package com.pingan.qhzx.anshao.platform.common.dao.pg;

import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MailList;

public interface MailListMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer mailListId);

    int insert(MailList record);

    int insertSelective(MailList record);

    MailList selectByPrimaryKey(Integer mailListId);

    int updateByPrimaryKeySelective(MailList record);

    int updateByPrimaryKey(MailList record);
}