package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;
import java.util.Date;

public class MchtUserRole extends BaseDTO {
    private Integer mchtUserRoleId;

    private Integer orgId;

    private String roleCode;

    private String roleName;

    private String roleDesc;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;
    
    private String mchtUserAuthSelected;
    
    private String orgName;

    public Integer getMchtUserRoleId() {
        return mchtUserRoleId;
    }

    public void setMchtUserRoleId(Integer mchtUserRoleId) {
        this.mchtUserRoleId = mchtUserRoleId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode == null ? null : roleCode.trim();
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName == null ? null : roleName.trim();
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc == null ? null : roleDesc.trim();
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy == null ? null : updatedBy.trim();
    }

	public String getMchtUserAuthSelected() {
		return mchtUserAuthSelected;
	}

	public void setMchtUserAuthSelected(String mchtUserAuthSelected) {
		this.mchtUserAuthSelected = mchtUserAuthSelected;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName == null ? null : orgName.trim();
	}
}