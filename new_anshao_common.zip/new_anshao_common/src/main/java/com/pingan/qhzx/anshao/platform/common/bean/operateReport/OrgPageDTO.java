package com.pingan.qhzx.anshao.platform.common.bean.operateReport;

import java.util.Date;

import com.pingan.qhzx.anshao.platform.common.bean.knowledge.PageDTO;

/**
 * org分页扩展类
 * @author LIUPENGLIANG375
 * 创建时间：2016年9月28日 下午12:35:30
 */

public class OrgPageDTO extends PageDTO{
	
	private static final long serialVersionUID = 1L;

	private Integer orgId;

    private String orgCode;

    private String orgName;

    private String orgLevel;

    private String orgAddress;

    private String orgUrl;

    private Integer parentOrgId;

    private String orgStatus;

    private Object orgGis;

    private String contractName;

    private String contractPhone;

    private String contractEmail;

    private String initPwd;

    private Integer handlerCount;
    
    private String orgType;

    private String createdBy;

    private Date createdDate;

    private String updatedBy;

    private Date updatedDate;
    
    private String parentOrgName;

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgLevel() {
		return orgLevel;
	}

	public void setOrgLevel(String orgLevel) {
		this.orgLevel = orgLevel;
	}

	public String getOrgAddress() {
		return orgAddress;
	}

	public void setOrgAddress(String orgAddress) {
		this.orgAddress = orgAddress;
	}

	public String getOrgUrl() {
		return orgUrl;
	}

	public void setOrgUrl(String orgUrl) {
		this.orgUrl = orgUrl;
	}

	public Integer getParentOrgId() {
		return parentOrgId;
	}

	public void setParentOrgId(Integer parentOrgId) {
		this.parentOrgId = parentOrgId;
	}

	public String getOrgStatus() {
		return orgStatus;
	}

	public void setOrgStatus(String orgStatus) {
		this.orgStatus = orgStatus;
	}

	public Object getOrgGis() {
		return orgGis;
	}

	public void setOrgGis(Object orgGis) {
		this.orgGis = orgGis;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	public String getContractPhone() {
		return contractPhone;
	}

	public void setContractPhone(String contractPhone) {
		this.contractPhone = contractPhone;
	}

	public String getContractEmail() {
		return contractEmail;
	}

	public void setContractEmail(String contractEmail) {
		this.contractEmail = contractEmail;
	}

	public String getInitPwd() {
		return initPwd;
	}

	public void setInitPwd(String initPwd) {
		this.initPwd = initPwd;
	}

	public Integer getHandlerCount() {
		return handlerCount;
	}

	public void setHandlerCount(Integer handlerCount) {
		this.handlerCount = handlerCount;
	}

	public String getOrgType() {
		return orgType;
	}

	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getParentOrgName() {
		return parentOrgName;
	}

	public void setParentOrgName(String parentOrgName) {
		this.parentOrgName = parentOrgName;
	}
}
