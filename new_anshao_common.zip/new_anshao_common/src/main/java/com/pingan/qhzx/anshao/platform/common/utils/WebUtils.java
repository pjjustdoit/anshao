package com.pingan.qhzx.anshao.platform.common.utils;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.ex.ServiceException;

/**
 * Created by YUZILEI869 on 2015-12-08.
 */
public class WebUtils {

    public static final String CODE = "code";
    public static final String MSG = "message";
    public static final String DATA = "data";

    public static JSONObject createErrorResult() {
        return createResp(ResponseEnum.UNKNOWN_ERROR);
    }

    public static JSONObject createErrorResult(ResponseEnum responseEnum) {
        return createResp(responseEnum);
    }

    public static JSONObject createErrorResult(ResponseEnum responseEnum, Object data) {
        JSONObject resp = createResp(responseEnum);
        resp.put(DATA, data);
        return resp;
    }

    public static JSONObject createSuccResult() {
        return createResp(ResponseEnum.SUCCESS);
    }

    private static JSONObject createResp(ResponseEnum responseEnum) {
        JSONObject result = new JSONObject();
        result.put(CODE, responseEnum.getCode());
        result.put(MSG, responseEnum.getMessage());
        return result;
    }

    public static JSONObject createSuccResult(Object data) {
        JSONObject result = createSuccResult();
        result.put(DATA, data);
        return result;
    }

    public static JSONObject createErrorResult(ServiceException e) {
        JSONObject result = new JSONObject();
        result.put(CODE, e.getErrCode());
        result.put(MSG, e.getErrMsg());
        return result;
    }
}
