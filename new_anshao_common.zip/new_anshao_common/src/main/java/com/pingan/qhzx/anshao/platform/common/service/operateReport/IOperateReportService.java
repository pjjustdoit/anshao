package com.pingan.qhzx.anshao.platform.common.service.operateReport;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.bean.operateReport.OperateReporBean;
import com.pingan.qhzx.anshao.platform.common.bean.operateReport.OrgPageDTO;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;

/**
 * 登录运营后台->运营报表
 * 
 * @author LIUPENGLIANG375 创建时间：2016年9月28日 下午12:45:49
 */
public interface IOperateReportService {
	
	/**
	 * 运营报表分页查询
	 * @param orgPageDTO
	 */
	PageInfo<OperateReporBean> selectOperateReportPageList(OrgPageDTO orgPageDTO);
	
	/**
	 * 运营报表查询(不分页)
	 * @param Org
	 */
	List<OperateReporBean> selectOperateReportList(Org org);
}
