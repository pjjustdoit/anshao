package com.pingan.qhzx.anshao.platform.common.service;


/**
 * Created by yuzilei869 on 16/7/21.
 */
public interface IRedisService {
    
    RedisProvider<Integer> getLoginErrorTimeCache();

}
