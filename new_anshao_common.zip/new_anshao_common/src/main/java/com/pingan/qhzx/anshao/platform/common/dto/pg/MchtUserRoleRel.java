package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;
import java.util.Date;

public class MchtUserRoleRel extends BaseDTO {
    private Integer mchtUserRoleRelId;

    private Integer mchtUserRoleId;

    private Integer orgId;

    private Integer mchtUserId;

    private Date createdDate;

    private String createdBy;

    public Integer getMchtUserRoleRelId() {
        return mchtUserRoleRelId;
    }

    public void setMchtUserRoleRelId(Integer mchtUserRoleRelId) {
        this.mchtUserRoleRelId = mchtUserRoleRelId;
    }

    public Integer getMchtUserRoleId() {
        return mchtUserRoleId;
    }

    public void setMchtUserRoleId(Integer mchtUserRoleId) {
        this.mchtUserRoleId = mchtUserRoleId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Integer getMchtUserId() {
        return mchtUserId;
    }

    public void setMchtUserId(Integer mchtUserId) {
        this.mchtUserId = mchtUserId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }
}