package com.pingan.qhzx.anshao.platform.common.web.form;

import com.pingan.qhzx.anshao.platform.common.web.common.AppCommonForm;

public class RoleForm extends AppCommonForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 434015333418243634L;

	private Integer mchtUserRoleId;
	
	private String orgName;
	
	private Integer orgId;
	
	private String roleName;
	
	private String roleDesc;
	
	private String mchtUserAuthSelected;
	
	private String operateType;
	
	public Integer getMchtUserRoleId() {
		return mchtUserRoleId;
	}

	public void setMchtUserRoleId(Integer mchtUserRoleId) {
		this.mchtUserRoleId = mchtUserRoleId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public String getMchtUserAuthSelected() {
		return mchtUserAuthSelected;
	}

	public void setMchtUserAuthSelected(String mchtUserAuthSelected) {
		this.mchtUserAuthSelected = mchtUserAuthSelected;
	}

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}
}
