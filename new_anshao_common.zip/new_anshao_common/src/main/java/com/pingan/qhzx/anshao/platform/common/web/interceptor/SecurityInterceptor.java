package com.pingan.qhzx.anshao.platform.common.web.interceptor;

import com.google.common.base.Charsets;
import com.google.common.base.Joiner;
import com.google.common.hash.Hashing;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

public class SecurityInterceptor extends BaseInterceptor implements
        HandlerInterceptor {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(SecurityInterceptor.class);
    public static final Joiner.MapJoiner JOINER = Joiner.on("&").withKeyValueSeparator("=");
    @Value("${web.security.sign.prefix}")
    private String securitySignPrefix;
    @Value("${web.security.sign.suffix}")
    private String securitySignSuffix;

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object arg2) throws Exception {
        String sign = request.getParameter("sign");
        if (StringUtils.isBlank(sign)) {
            write(response, WebUtils.createErrorResult(ResponseEnum.PARAM_EMPTY_SIGN));
            return false;
        }

        if (validParamLength(request, response)) return false;


        String md5Str = calcSign(request);

        boolean isSame = validSame(sign, md5Str);
        if (!isSame) {
            log.debug("[SUCCESS]sign值不同");
            write(response, WebUtils.createErrorResult(ResponseEnum.PARAMS_ERROR_SIGN));
        }
        return isSame;
    }

    private boolean validSame(String sign, String md5Str) {
        if (log.isDebugEnabled()) {
            log.debug("md5 : " + md5Str);
            log.debug("sign: " + sign);
        }
        return null != sign && sign.equalsIgnoreCase(md5Str);
    }

    private String calcSign(HttpServletRequest request) {
        Map<String, String> map = buildParamsMap(request);
        // sort params&values
        StringBuilder queryString = buildQueryString(map);
        if (log.isDebugEnabled())
            log.debug("Query String : " + queryString);
        String md5Str = Hashing.md5().hashString(queryString.toString(), Charsets.UTF_8).toString();
        return md5Str;
    }

    private Map<String, String> buildParamsMap(HttpServletRequest request) {
        Map<String, String> map = new TreeMap<String, String>();
        Enumeration paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String paramName = (String) paramNames.nextElement();
            String[] paramValues = request.getParameterValues(paramName);
            if ("sign".equals(paramName)) {
                continue;
            }
            String paramValue = paramValues[0];
            if (paramValue.length() != 0) {
                map.put(paramName, paramValue);
            } else {
                map.put(paramName, "");
            }
        }
        return map;
    }

    private boolean validParamLength(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Enumeration paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String paramName = (String) paramNames.nextElement();
            String[] paramValues = request.getParameterValues(paramName);
            if (paramValues.length != 1) {
                log.error("===参数长度 : " + paramValues.length);
                write(response, WebUtils.createErrorResult(ResponseEnum.PARAM_ERROR));
                return true;
            }
        }
        return false;
    }

    private StringBuilder buildQueryString(Map<String, String> map) {
        StringBuilder queryString = new StringBuilder();
        JOINER.appendTo(queryString, map);
        queryString.insert(0, securitySignPrefix).append(securitySignSuffix);
        return queryString;
    }

    public void setSecuritySignPrefix(String securitySignPrefix) {
        this.securitySignPrefix = securitySignPrefix;
    }

    public void setSecuritySignSuffix(String securitySignSuffix) {
        this.securitySignSuffix = securitySignSuffix;
    }
}
