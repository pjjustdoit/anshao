package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;

import java.util.Date;

public class MchtUserAuth extends BaseDTO {
    private Integer mchtUserAuthId;

    private String authType;

    private String resClassify;

    private String authName;

    private String authCtx;

    private Integer parentAuthId;

    private Integer orderBy;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;
    
    private String authClass;

    private String authOperType;

    public String getAuthOperType() {
        return authOperType;
    }

    public void setAuthOperType(String authOperType) {
        this.authOperType = authOperType;
    }

    public Integer getMchtUserAuthId() {
        return mchtUserAuthId;
    }

    public void setMchtUserAuthId(Integer mchtUserAuthId) {
        this.mchtUserAuthId = mchtUserAuthId;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType == null ? null : authType.trim();
    }

    public String getResClassify() {
        return resClassify;
    }

    public void setResClassify(String resClassify) {
        this.resClassify = resClassify == null ? null : resClassify.trim();
    }

    public String getAuthName() {
        return authName;
    }

    public void setAuthName(String authName) {
        this.authName = authName == null ? null : authName.trim();
    }

    public String getAuthCtx() {
        return authCtx;
    }

    public void setAuthCtx(String authCtx) {
        this.authCtx = authCtx == null ? null : authCtx.trim();
    }

    public Integer getParentAuthId() {
        return parentAuthId;
    }

    public void setParentAuthId(Integer parentAuthId) {
        this.parentAuthId = parentAuthId;
    }

    public Integer getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(Integer orderBy) {
        this.orderBy = orderBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy == null ? null : updatedBy.trim();
    }

	public String getAuthClass() {
		return authClass;
	}

	public void setAuthClass(String authClass) {
		this.authClass = authClass == null ? null : authClass.trim();
	}
}