package com.pingan.qhzx.anshao.platform.common.bean;

import java.io.Serializable;

/**
 * Created by zhangshan193 on 16/10/13.
 */
public class CorpusImportResultBean implements Serializable{

    private static final long serialVersionUID = 8604529644306962473L;

    private int totalRows;

    private int successRows;

    private int failedRows;

    private String downloadUrl;

    public int getTotalRows() {
        return totalRows;
    }

    public void setTotalRows(int totalRows) {
        this.totalRows = totalRows;
    }

    public int getSuccessRows() {
        return successRows;
    }

    public void setSuccessRows(int successRows) {
        this.successRows = successRows;
    }

    public int getFailedRows() {
        return failedRows;
    }

    public void setFailedRows(int failedRows) {
        this.failedRows = failedRows;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    @Override
    public String toString() {
        return "CorpusImportResultBean{" +
                "totalRows=" + totalRows +
                ", successRows=" + successRows +
                ", failedRows=" + failedRows +
                ", downloadUrl='" + downloadUrl + '\'' +
                '}';
    }
}
