package com.pingan.qhzx.anshao.platform.common.web.form;

import com.alibaba.fastjson.annotation.JSONField;
import com.paic.pafa.validator.annotation.Valid;
import com.pingan.qhzx.anshao.platform.common.web.common.AppCommonForm;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

/**
 * 语料使用详情
 * Created by zhangshan193 on 16/9/30.
 */
public class MchtCorpusCtxForm extends AppCommonForm {
    private static final long serialVersionUID = 1428222306672297824L;

    private Long mchtCorpusCtxId;

    private Integer orgId;

    private Integer zskClassifyId;

    private String exactMatchFlag;

    private String question;

    private String answer;

    private String keyWord;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date expireDate;

    private String effectiveFlag;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date queryStartDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date queryEndDate;

    private String targetField;

    private String fieldValue;

    private Integer pageSize;

    private Integer currentPage;

    private String mchtCorpusCtxIdList;

    @JSONField(serialize = false,deserialize = false)
    private MultipartFile corpusFile;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Long getMchtCorpusCtxId() {
        return mchtCorpusCtxId;
    }

    public void setMchtCorpusCtxId(Long mchtCorpusCtxId) {
        this.mchtCorpusCtxId = mchtCorpusCtxId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Integer getZskClassifyId() {
        return zskClassifyId;
    }

    public void setZskClassifyId(Integer zskClassifyId) {
        this.zskClassifyId = zskClassifyId;
    }

    public String getExactMatchFlag() {
        return exactMatchFlag;
    }

    public void setExactMatchFlag(String exactMatchFlag) {
        this.exactMatchFlag = exactMatchFlag;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getKeyWord() {
        return keyWord;
    }

    public void setKeyWord(String keyWord) {
        this.keyWord = keyWord;
    }

    public Date getExpireDate() {
        return expireDate;
    }

    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }

    public String getEffectiveFlag() {
        return effectiveFlag;
    }

    public void setEffectiveFlag(String effectiveFlag) {
        this.effectiveFlag = effectiveFlag;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public MultipartFile getCorpusFile() {
        return corpusFile;
    }

    public void setCorpusFile(MultipartFile corpusFile) {
        this.corpusFile = corpusFile;
    }

    public Date getQueryStartDate() {
        return queryStartDate;
    }

    public void setQueryStartDate(Date queryStartDate) {
        this.queryStartDate = queryStartDate;
    }

    public Date getQueryEndDate() {
        return queryEndDate;
    }

    public void setQueryEndDate(Date queryEndDate) {
        this.queryEndDate = queryEndDate;
    }

    public String getTargetField() {
        return targetField;
    }

    public void setTargetField(String targetField) {
        this.targetField = targetField;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public String getMchtCorpusCtxIdList() {
        return mchtCorpusCtxIdList;
    }

    public void setMchtCorpusCtxIdList(String mchtCorpusCtxIdList) {
        this.mchtCorpusCtxIdList = mchtCorpusCtxIdList;
    }

    @Override
    public String toString() {
        return "MchtCorpusCtxForm{" +
                "mchtCorpusCtxId=" + mchtCorpusCtxId +
                ", orgId=" + orgId +
                ", zskClassifyId=" + zskClassifyId +
                ", exactMatchFlag='" + exactMatchFlag + '\'' +
                ", question='" + question + '\'' +
                ", answer='" + answer + '\'' +
                ", keyWord='" + keyWord + '\'' +
                ", expireDate=" + expireDate +
                ", effectiveFlag='" + effectiveFlag + '\'' +
                ", createdDate=" + createdDate +
                ", createdBy='" + createdBy + '\'' +
                ", updatedDate=" + updatedDate +
                ", updatedBy='" + updatedBy + '\'' +
                ", queryStartDate='" + queryStartDate + '\'' +
                ", queryEndDate='" + queryEndDate + '\'' +
                ", targetField='" + targetField + '\'' +
                ", fieldValue='" + fieldValue + '\'' +
                ", corpusFile=" + corpusFile +
                '}';
    }
}
