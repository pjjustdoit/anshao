package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;
import java.util.Date;

public class MchtCorpusOutline extends BaseDTO {
    private Integer orgId;

    private Long corpusInitNum;

    private Long corpusTotalNum;

    private Long corpusSurplusNum;

    private Date cutoffDate;

    private Long corpususenum;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Long getCorpusInitNum() {
        return corpusInitNum;
    }

    public void setCorpusInitNum(Long corpusInitNum) {
        this.corpusInitNum = corpusInitNum;
    }

    public Long getCorpusTotalNum() {
        return corpusTotalNum;
    }

    public void setCorpusTotalNum(Long corpusTotalNum) {
        this.corpusTotalNum = corpusTotalNum;
    }

    public Long getCorpusSurplusNum() {
        return corpusSurplusNum;
    }

    public void setCorpusSurplusNum(Long corpusSurplusNum) {
        this.corpusSurplusNum = corpusSurplusNum;
    }

    public Date getCutoffDate() {
        return cutoffDate;
    }

    public void setCutoffDate(Date cutoffDate) {
        this.cutoffDate = cutoffDate;
    }

    public Long getCorpususenum() {
        return corpususenum;
    }

    public void setCorpususenum(Long corpususenum) {
        this.corpususenum = corpususenum;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy == null ? null : updatedBy.trim();
    }

    @Override
    public String toString() {
        return "MchtCorpusOutline{" +
                "orgId=" + orgId +
                ", corpusInitNum=" + corpusInitNum +
                ", corpusTotalNum=" + corpusTotalNum +
                ", corpusSurplusNum=" + corpusSurplusNum +
                ", cutoffDate=" + cutoffDate +
                ", corpususenum=" + corpususenum +
                ", createdDate=" + createdDate +
                ", createdBy='" + createdBy + '\'' +
                ", updatedDate=" + updatedDate +
                ", updatedBy='" + updatedBy + '\'' +
                '}';
    }
}