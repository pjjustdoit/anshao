package com.pingan.qhzx.anshao.platform.common.web.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;

import com.pingan.qhzx.anshao.platform.common.bean.UserSessionBean;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;

/**
 * Created by YUZILEI869 on 2015-12-08.
 */
public class SessionInterceptor extends BaseInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(SessionInterceptor.class);
    private static final String USER_INFO = "userInfo";
    @Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		HttpSession session = request.getSession();
		UserSessionBean currentUserSession;
		if (null == session) {
			write(response, WebUtils.createErrorResult(ResponseEnum.USER_NOT_LOGIN));
			return false;
		}
		if (session != null) {
			currentUserSession = (UserSessionBean) session.getAttribute(USER_INFO);
			if (currentUserSession == null) {
				log.warn("用户 不存在！");
				write(response, WebUtils.createErrorResult(ResponseEnum.USER_NOT_LOGIN));
				return false;
			}
		}
		return true;
	}

}
