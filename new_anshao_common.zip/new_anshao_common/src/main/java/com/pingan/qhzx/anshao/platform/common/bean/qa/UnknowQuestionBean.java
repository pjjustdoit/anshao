package com.pingan.qhzx.anshao.platform.common.bean.qa;

import java.util.Date;

public class UnknowQuestionBean {

	// 机构code
	private String orgId;

	// 客户id
	private String accountId;

	// 提问时间
	private Date questionDate;

	// 问题来源
	private String questionSource;

	// 问题
	private String questionContent;

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public Date getQuestionDate() {
		return questionDate;
	}

	public void setQuestionDate(Date questionDate) {
		this.questionDate = questionDate;
	}

	public String getQuestionContent() {
		return questionContent;
	}

	public void setQuestionContent(String questionContent) {
		this.questionContent = questionContent;
	}

	public String getQuestionSource() {
		return questionSource;
	}

	public void setQuestionSource(String questionSource) {
		this.questionSource = questionSource;
	}

}
