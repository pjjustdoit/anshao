package com.pingan.qhzx.anshao.platform.common.web.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.PatternMatchUtils;

import com.pingan.qhzx.anshao.platform.common.bean.UserSessionBean;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserAuth;
import com.pingan.qhzx.anshao.platform.common.enums.DicCodeEnum;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.utils.SessionUtils;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;

public class AuthInterceptor extends BaseInterceptor {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
        String requestURI = request.getRequestURI();
        SessionUtils sessionUtils = new SessionUtils(request.getSession());
        UserSessionBean userSessionBean = sessionUtils.getUserInfo();

        for (MchtUserAuth mchtUserAuth : userSessionBean.getAuths()) {
            if (mchtUserAuth.getAuthType().equals(DicCodeEnum.PERMISSION_MENU1.getCode())
            		|| mchtUserAuth.getAuthType().equals(DicCodeEnum.PERMISSION_MENU2.getCode())) {
            	String[] authCtxArry = mchtUserAuth.getAuthCtx().split(",");
                if (PatternMatchUtils.simpleMatch(authCtxArry, requestURI)) {
                    return true;
                }
            }
        }
        write(response, WebUtils.createErrorResult(ResponseEnum.REQUEST_AUTH_FAIL));
        return false;
	}

	
}
