package com.pingan.qhzx.anshao.platform.common.dao.pg;


import java.util.List;

import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRoleAuthRel;

public interface MchtUserRoleAuthRelMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer mchtUserRoleAuthRelId);

    int insert(MchtUserRoleAuthRel record);

    int insertSelective(MchtUserRoleAuthRel record);

    MchtUserRoleAuthRel selectByPrimaryKey(Integer mchtUserRoleAuthRelId);

    int updateByPrimaryKeySelective(MchtUserRoleAuthRel record);

    int updateByPrimaryKey(MchtUserRoleAuthRel record);
    
    int deleteByMchtUserRoleId(Integer mchtUserRoleId);
    
    List<MchtUserRoleAuthRel> selectByRoleId(Integer mchtUserRoleId);
    
}