package com.pingan.qhzx.anshao.platform.common.web.form;

import java.util.Date;

import com.pingan.qhzx.anshao.platform.common.web.common.AppCommonForm;
import org.springframework.format.annotation.DateTimeFormat;

public class OrgForm extends AppCommonForm {
	
	private static final long serialVersionUID = -4847247275078056328L;

	private Integer orgId;

    private String orgCode;

    private String orgName;

    private String orgStatus;

    private String contactName;

    private String contactTel;

    private String contactEmail;

    private String orgAddress;

    private String authCode;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date authDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date expireDate;

    private String orgType;
    
    private Integer pageSize;
    
    private Integer currentPage;
    
    private String createdBy;

    private String updatedBy;
    
    private long trafficInitNum;
    
    private long corpusInitNum;
    
    private long corpusTotalNum;

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode == null ? null : orgCode.trim();
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName == null ? null : orgName.trim();
    }

    public String getOrgStatus() {
        return orgStatus;
    }

    public void setOrgStatus(String orgStatus) {
        this.orgStatus = orgStatus == null ? null : orgStatus.trim();
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName == null ? null : contactName.trim();
    }

    public String getContactTel() {
        return contactTel;
    }

    public void setContactTel(String contactTel) {
        this.contactTel = contactTel == null ? null : contactTel.trim();
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail == null ? null : contactEmail.trim();
    }

    public String getOrgAddress() {
        return orgAddress;
    }

    public void setOrgAddress(String orgAddress) {
        this.orgAddress = orgAddress == null ? null : orgAddress.trim();
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode == null ? null : authCode.trim();
    }

    public String getOrgType() {
        return orgType;
    }

    public void setOrgType(String orgType) {
        this.orgType = orgType == null ? null : orgType.trim();
    }

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getAuthDate() {
		return authDate;
	}

	public void setAuthDate(Date authDate) {
		this.authDate = authDate;
	}

	public Date getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	public long getTrafficInitNum() {
		return trafficInitNum;
	}

	public void setTrafficInitNum(long trafficInitNum) {
		this.trafficInitNum = trafficInitNum;
	}

	public long getCorpusInitNum() {
		return corpusInitNum;
	}

	public void setCorpusInitNum(long corpusInitNum) {
		this.corpusInitNum = corpusInitNum;
	}

	public long getCorpusTotalNum() {
		return corpusTotalNum;
	}

	public void setCorpusTotalNum(long corpusTotalNum) {
		this.corpusTotalNum = corpusTotalNum;
	}

}
