package com.pingan.qhzx.anshao.platform.common.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtTrafficSerialMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.TrafficAccountMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerialExt;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.dto.pg.TrafficAccount;
import com.pingan.qhzx.anshao.platform.common.enums.TrafficSerialTypeEnum;
import com.pingan.qhzx.anshao.platform.common.utils.ExcelExporterUtils;
import com.pingan.qhzx.anshao.platform.common.utils.ExcelExporterUtils.FiledDefine;
import com.pingan.qhzx.anshao.platform.common.utils.ExcelExporterUtils.FiledType;
import com.pingan.qhzx.anshao.platform.common.web.form.MchtTrafficSerialForm;
import com.pingan.qhzx.anshao.platform.common.web.form.OrgForm;

@Service
public class MchtTrafficSerialServiceImpl implements IMchtTrafficSerialService {
	
	private static final Logger logger = LoggerFactory.getLogger(MchtTrafficSerialServiceImpl.class);

	@Autowired
	private MchtTrafficSerialMapper mchtTrafficSerialMapper;
	
	@Autowired
	private TrafficAccountMapper trafficAccountMapper;
	
	@Transactional
	@Override
	public int addMchtTrafficSerial(MchtTrafficSerialForm record) {
		MchtTrafficSerial mchtTrafficSerial = propertyCopy(record);
		Date nowDate = Calendar.getInstance().getTime();
		
		TrafficAccount trafficAccount = trafficAccountMapper.selectByPrimaryKeyLock(record.getOrgId());
		
		mchtTrafficSerial.setSerialType(TrafficSerialTypeEnum.IN.getCode());
		mchtTrafficSerial.setSerialDesc("增加流量");
		mchtTrafficSerial.setBeforeNum(trafficAccount.getTrafficTotalNum());
		mchtTrafficSerial.setAfterNum(trafficAccount.getTrafficTotalNum()+mchtTrafficSerial.getOccurNum());
		mchtTrafficSerial.setOccurDate(nowDate);
		mchtTrafficSerial.setCreatedDate(nowDate);
		
		mchtTrafficSerialMapper.insert(mchtTrafficSerial);
		
		TrafficAccount trafficAccountTemp = new TrafficAccount();
		trafficAccountTemp.setOrgId(trafficAccount.getOrgId());
		trafficAccountTemp.setTrafficTotalNum(mchtTrafficSerial.getOccurNum()+trafficAccount.getTrafficTotalNum());
		trafficAccountTemp.setTrafficRemainNum(trafficAccount.getTrafficRemainNum()+mchtTrafficSerial.getOccurNum());
		trafficAccountTemp.setUpdatedDate(nowDate);

		int affect = trafficAccountMapper.updateByPrimaryKeySelective(trafficAccountTemp);
		return affect;
	}
	
	/**
	 * 属性值复制
	 * @param mchtTrafficSerialForm
	 * @return
	 */
	private MchtTrafficSerial propertyCopy(MchtTrafficSerialForm mchtTrafficSerialForm){
		MchtTrafficSerial mchtTrafficSerialTemp = new MchtTrafficSerial();
		try {
			PropertyUtils.copyProperties(mchtTrafficSerialTemp, mchtTrafficSerialForm);
		} catch (Exception e) {
			logger.error("{}",e);
		}
		return mchtTrafficSerialTemp;
	}
	
	public TrafficAccount selectTrafficAccountByOrgId(MchtTrafficSerialForm record){
		TrafficAccount trafficAccount = trafficAccountMapper.selectByPrimaryKey(record.getOrgId());
		
		return trafficAccount;
		
	}

	@Override
	public TrafficAccount selectSumTraffic() {
		return trafficAccountMapper.selectSumTraffic();
	}

	@Override
	public Map<String,Object> selectIncrementByParams(MchtTrafficSerialForm record) {
		
    	PageHelper.startPage(record.getCurrentPage(),record.getPageSize(),true);
    	List<MchtTrafficSerialExt> mchtTrafficSerialExtList = this.mchtTrafficSerialMapper.selectByParams(getParamsByMchtTrafficSerialForm(record));
		
        PageInfo<MchtTrafficSerialExt> mchtTrafficSerialExtPageInfo = new PageInfo<MchtTrafficSerialExt>(mchtTrafficSerialExtList);

        Map<String,Object> resultMap = new HashMap<String,Object>();
        resultMap.put("totalCount",mchtTrafficSerialExtPageInfo.getTotal());
        resultMap.put("currentPage",mchtTrafficSerialExtPageInfo.getPageNum());
        resultMap.put("list",mchtTrafficSerialExtList);

        return resultMap;
	}
	
	private Map<String,Object> getParamsByMchtTrafficSerialForm(MchtTrafficSerialForm record){
		Map<String,Object> params = new HashMap<String,Object>();
		if(!StringUtils.isBlank(record.getOrgName())){
			params.put("orgName", record.getOrgName());
		}
		if(!StringUtils.isBlank(record.getOrgCode())){
    		params.put("orgCode", record.getOrgCode());
		}
		if(record.getStartDate() != null){
			params.put("startDate", record.getStartDate());
		}
		if(record.getEndDate() != null){
			Calendar calTemp = Calendar.getInstance();
			calTemp.setTime(record.getEndDate());
			calTemp.add(Calendar.DATE,1);

			params.put("endDate", calTemp.getTime());
		}

    	params.put("serialType", TrafficSerialTypeEnum.IN.getCode());
    	if(record.getPageSize() != null){
    		params.put("pageSize", record.getPageSize());
    	}
    	if(record.getCurrentPage() != null){
    		params.put("currentPage", record.getCurrentPage());
    	}
    	return params;
	}

	@Override
	public void downloadByParams(MchtTrafficSerialForm record,HttpServletResponse response) {

    	List<MchtTrafficSerialExt> mchtTrafficSerialExtList = this.mchtTrafficSerialMapper.selectByParams(getParamsByMchtTrafficSerialForm(record));
		if(mchtTrafficSerialExtList == null){
			mchtTrafficSerialExtList = new ArrayList<MchtTrafficSerialExt>();
		}

    	List<FiledDefine> filedDefineList = new ArrayList<FiledDefine>();

    	filedDefineList.add(new ExcelExporterUtils.FiledDefine("机构名称","orgName"));
    	filedDefineList.add(new ExcelExporterUtils.FiledDefine("机构ID","orgCode"));
    	filedDefineList.add(new ExcelExporterUtils.FiledDefine("变更时间","occurDate",FiledType.DATE));
    	filedDefineList.add(new ExcelExporterUtils.FiledDefine("变更前总流量","beforeNum"));
    	filedDefineList.add(new ExcelExporterUtils.FiledDefine("调整数量","occurNum"));
    	filedDefineList.add(new ExcelExporterUtils.FiledDefine("变更后总流量","afterNum"));
    	filedDefineList.add(new ExcelExporterUtils.FiledDefine("操作人","createdBy"));

        String fileName = "trafficSerial_"+System.currentTimeMillis()+".xls";
		ExcelExporterUtils.exportXLS(fileName,mchtTrafficSerialExtList, filedDefineList,response);
	}

}
