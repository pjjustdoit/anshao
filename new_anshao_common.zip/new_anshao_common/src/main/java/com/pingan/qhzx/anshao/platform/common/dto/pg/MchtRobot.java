package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;
import java.math.BigDecimal;
import java.util.Date;

public class MchtRobot extends BaseDTO {
    private Integer mchtRobotId;

    private Integer orgId;

    private String robotCode;

    private String robotName;

    private BigDecimal fuzzyMatchThreshold;

    private Boolean fuzzyMatchSwitch;

    private String welcomeLang;

    private String defaultAnswer;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;

    public Integer getMchtRobotId() {
        return mchtRobotId;
    }

    public void setMchtRobotId(Integer mchtRobotId) {
        this.mchtRobotId = mchtRobotId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getRobotCode() {
        return robotCode;
    }

    public void setRobotCode(String robotCode) {
        this.robotCode = robotCode == null ? null : robotCode.trim();
    }

    public String getRobotName() {
        return robotName;
    }

    public void setRobotName(String robotName) {
        this.robotName = robotName == null ? null : robotName.trim();
    }

    public BigDecimal getFuzzyMatchThreshold() {
        return fuzzyMatchThreshold;
    }

    public void setFuzzyMatchThreshold(BigDecimal fuzzyMatchThreshold) {
        this.fuzzyMatchThreshold = fuzzyMatchThreshold;
    }

    public Boolean getFuzzyMatchSwitch() {
        return fuzzyMatchSwitch;
    }

    public void setFuzzyMatchSwitch(Boolean fuzzyMatchSwitch) {
        this.fuzzyMatchSwitch = fuzzyMatchSwitch;
    }

    public String getWelcomeLang() {
        return welcomeLang;
    }

    public void setWelcomeLang(String welcomeLang) {
        this.welcomeLang = welcomeLang == null ? null : welcomeLang.trim();
    }

    public String getDefaultAnswer() {
        return defaultAnswer;
    }

    public void setDefaultAnswer(String defaultAnswer) {
        this.defaultAnswer = defaultAnswer == null ? null : defaultAnswer.trim();
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy == null ? null : updatedBy.trim();
    }
}