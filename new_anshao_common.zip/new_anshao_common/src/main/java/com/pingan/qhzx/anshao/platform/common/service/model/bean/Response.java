package com.pingan.qhzx.anshao.platform.common.service.model.bean;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.platform.common.bean.ValidResult;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;

import java.util.Date;
import java.util.Map;

/**
 * Created by YUZILEI869 on 2015-12-23.
 */
public class Response {

    private ResponseEnum responseEnum;

    private Map<String, Object> data = Maps.newHashMapWithExpectedSize(10);

    private AnswerParser answerParser;

    public Response() {
        this.responseEnum = ResponseEnum.SUCCESS;
    }



    public Object put(String key, Object value) {
        return data.put(key, value);
    }

    public void setResponseEnum(ResponseEnum responseEnum) {
        this.responseEnum = responseEnum;
    }

    public String getAnswer() {
        return (String) data.get("answer");
    }

    public void setAnswer(String answer) {
        data.put("answer", answer);
    }

    public void setAnswerDate(Date answerDate) {
        data.put("answerDate", answerDate);
    }

    public void setSerialNo(String serialNo) {
        data.put("serialNo", serialNo);
    }

    public void setOrgCode(String orgCode) {
        data.put("orgCode", orgCode);
    }

    public void setQuestionNo(String questionNo) {
        data.put("questionNo", questionNo);
    }

    public void setCustId(String custId) {
        data.put("custId", custId);
    }

    public void setQuestionCtx(String questionCtx) {
        data.put("questionCtx", questionCtx);
    }

    public void setClassifierValue(String classifierValue) {
        data.put("classifierValue", classifierValue);
    }

    public JSONObject createJson() {
        return ValidResult.createValidResult(responseEnum, data).toWebResult();
    }

    public AnswerParser getAnswerParser() {
        return answerParser;
    }

    public void setAnswerParser(AnswerParser answerParser) {
        this.answerParser = answerParser;
    }
}

