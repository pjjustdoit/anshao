package com.pingan.qhzx.anshao.platform.common.web.form;

import com.pingan.qhzx.anshao.platform.common.web.common.AppCommonForm;

/**
 * 语料概要总表
 * Created by zhangshan193 on 16/9/30.
 */
public class MchtCorpusOutlineForm extends AppCommonForm {

    private static final long serialVersionUID = 3423901314408266964L;


}
