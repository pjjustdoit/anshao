package com.pingan.qhzx.anshao.platform.common.service.model.bean;

import com.paic.pafa.appclient.ServiceResults;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import static com.alibaba.fastjson.JSON.toJSONString;

/**
 * Created by yuzilei022 on 16/10/8.
 */
public class AnswerParser implements Serializable {

    private List<Answer> beanList;

    private String answer;

    private String serialNo;

    private boolean isMulti = false;

    private boolean isMatch = false;

    private Boolean hasAnswer;

    private Date answerDate;

    private String debug;

    private String source;

    private String code;

    private String message;

    //显示声明 请勿删除！！！
    public AnswerParser() {
        super();
    }

    public AnswerParser(ServiceResults results, Request request) {
        this.serialNo = request.getSerialNo();
        this.source = toJSONString(results);
        this.answerDate = new Date();
        if (results == null) {
            this.code = ResponseEnum.ANSIR_QA_ERROR.getCode();
            this.message = ResponseEnum.ANSIR_QA_ERROR.getMessage();
            return;
        }
        this.code = results.getString("code");
        this.message = results.getString("message");
        this.debug = results.getString("debug");
        this.isMatch = "1".equals(results.getString("ismatchknowledage"));
        this.beanList = results.toDTOList("data", Answer.class);
        this.isMulti = "0".equals(results.getString("questionOrAnswer"));
        this.answer = parseAnswer(results, request);
        if (StringUtils.isNotBlank(debug))
            this.answer += "[debug]:" + this.debug;

    }

    private String parseAnswer(ServiceResults results, Request request) {
        if (results == null || !"0".equals(results.getString("code"))) {
            return request.getMchtRobot().getDefaultAnswer();
        }
        if (this.beanList == null || this.beanList.size() == 0) {
            return request.getMchtRobot().getDefaultAnswer();
        }
        if (!isMulti) {  //单个答案
            return this.beanList.get(0).getAnswer();
        }
        //多个答案
        StringBuilder sb = new StringBuilder(200);
        sb.append("请选择您想了解的问题：");
        for (int i = 0; i < this.beanList.size(); i++) {
            sb.append("\r\n");
            sb.append(i + 1).append(". ").append(this.beanList.get(i).getQuestion());
        }
        sb.append("\r\n").append("\r\n").append("请输入对应的数字：");
        return sb.toString();
    }

    public boolean hasAnswer(String index) {
        if (hasAnswer != null) {
            return hasAnswer;
        }
        if (index.matches("^[0-9]$")) {
            Integer integer = Integer.valueOf(index);
            if (beanList == null || integer > beanList.size()) {
                return hasAnswer = false;
            }
            this.answer = beanList.get(integer - 1).getAnswer();
            return hasAnswer = true;
        }
        return hasAnswer = false;
    }

    public boolean isSuccess() {
        return StringUtils.equals("0", code);
    }

    public boolean isMatch() {
        return isMatch;
    }

    public boolean isMulti() {
        return isMulti;
    }

    public String getAnswer() {
        return answer;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public Date getAnswerDate() {
        return answerDate;
    }

    public String getDebug() {
        return debug;
    }

    public String getSource() {
        return source;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
