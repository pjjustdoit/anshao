package com.pingan.qhzx.anshao.platform.common.service.corpus;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusOutline;
import com.pingan.qhzx.anshao.platform.common.ex.ServiceException;
import com.pingan.qhzx.anshao.platform.common.web.form.MchtCorpusCtxForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangshan193 on 16/9/30.
 */
public interface IMchtCorpusService {

    /**
     * 根据orgId获取语料的初始值、语料总量等信息
     * @param orgId
     * @return
     */
    MchtCorpusOutline getMchtCorpusOutlineByOrgId(Integer orgId);

    /**
     * 添加语料
     * @param mchtCorpusCtxForm
     * @return
     */
    JSONObject addCorpus(MchtCorpusCtxForm mchtCorpusCtxForm)throws IllegalArgumentException,ServiceException;

    /**
     * 批量更新语料
     * @param mchtCorpusCtxForm
     * @return
     */
    JSONObject batchUpdate(MchtCorpusCtxForm mchtCorpusCtxForm)throws ServiceException;

    /**
     * 更新语料
     * @param mchtCorpusCtxForm
     * @return
     */
    JSONObject update(MchtCorpusCtxForm mchtCorpusCtxForm)throws ServiceException;

    /**
     * 删除语料
     * @param mchtCorpusCtxForm
     * @return
     */
    JSONObject delete(MchtCorpusCtxForm mchtCorpusCtxForm)throws ServiceException;

    /**
     * 查询语料详情
     * @param mchtCorpusCtxId
     * @return
     */
    MchtCorpusCtx getMchtCorpusCtxById(Long mchtCorpusCtxId);

    /**
     * 根据分类条件分页查询
     * @param mchtCorpusCtxForm
     * @return
     */
    Map<String,Object> selectByParams(MchtCorpusCtxForm mchtCorpusCtxForm);

    /**
     * 批量导出
     * @param mchtCorpusCtxForm
     */
    void exportByParams(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletResponse response);

    /**
     * 批量导入
     * @param mchtCorpusCtxForm
     */
    JSONObject importMchtCorpusCtx(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletRequest request);

    /**
     * 状态修改
     * @param mchtCorpusCtxForm
     * @return
     */
    int statusChange(MchtCorpusCtxForm mchtCorpusCtxForm);

    /**
     * 下载语料导出失败文件
     * @param request
     * @param response
     */
    void downloadFailedExcel(HttpServletRequest request,HttpServletResponse response);

}
