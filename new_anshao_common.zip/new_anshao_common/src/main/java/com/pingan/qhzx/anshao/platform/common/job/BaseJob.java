package com.pingan.qhzx.anshao.platform.common.job;

import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by yuzilei022 on 16/8/26.
 */
public abstract class BaseJob implements DisposableBean {
    @Autowired
    private RedisLockFactory lockFactory;

    public void execute() {
        RedisLock lock = lockFactory.getLock(this.getClass().getName(), 600);
        boolean flag = lock.tryLock();
        if (flag) {
            try {
                invoke();
            } finally {
                lock.unlock();
            }
        }
    }

    protected abstract void invoke();

    @Override
    public void destroy() throws Exception {
        RedisLock lock = lockFactory.getLock(this.getClass().getName());
        lock.reinit();
    }
}
