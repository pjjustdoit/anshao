package com.pingan.qhzx.anshao.platform.common.dto.qa;

import java.util.Date;
import java.util.List;

public class SynchronizationQuestionDTO {
	private String syncStatus;
	private List<String> syncStateList;
	private Date startDate;
	private Date endDate;
	private Integer batchNo;
	private Date updatedDate;

	public String getSyncStatus() {
		return syncStatus;
	}

	public void setSyncStatus(String syncStatus) {
		this.syncStatus = syncStatus;
	}

	public List<String> getSyncStateList() {
		return syncStateList;
	}

	public void setSyncStateList(List<String> syncStateList) {
		this.syncStateList = syncStateList;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(Integer batchNo) {
		this.batchNo = batchNo;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
}
