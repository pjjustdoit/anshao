package com.pingan.qhzx.anshao.platform.common.service;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.pingan.pafa.redis.Redis;
import com.pingan.pafa.redis.cache.RedisCacheBean;

/**
 * Created by yuzilei869 on 16/7/21.
 */
@Service
public class RedisService implements InitializingBean, IRedisService {

    public static final String LOGIN_NAME_LOGIN_ERROR_TIME = "loginName->loginErrorTime:";

    @Resource(name = "ansir_redis")
    private Redis redis;

    private Map<String, RedisProvider> cache = Maps.newHashMap();


    protected <T> RedisProvider<T> getProvider(String cacheName) {
        return cache.get(cacheName);
    }


    @Override
    public RedisProvider<Integer> getLoginErrorTimeCache() {
        return getProvider(LOGIN_NAME_LOGIN_ERROR_TIME);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        registerProvider(LOGIN_NAME_LOGIN_ERROR_TIME, 3600, Integer.class);
    }

	private void registerProvider(String key, int expire, Class<?> aClass) {
        cache.put(key, RedisProvider.buildProvider(expire, new RedisCacheBean(key, redis, aClass)));
    }
}
