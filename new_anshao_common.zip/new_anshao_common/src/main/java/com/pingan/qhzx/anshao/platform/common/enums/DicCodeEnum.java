package com.pingan.qhzx.anshao.platform.common.enums;

/**
 * DICCODE枚举
 * User: zhangshan193
 * Date: 16-8-6
 * Time: 下午3:21
 * To change this template use File | Settings | File Templates.
 */
public enum DicCodeEnum {

    SUPER_ROLE("SA","超级管理员"),
    NOMAL_ROLE("nomal","普通用户"),
    PERMISSION_RESOURCE("0","资源权限"),
    PERMISSION_MENU1("1","一级菜单"),
    PERMISSION_MENU2("2","二级菜单"),
    OPERATE_TYPE_ADD("0","add"),
    OPERATE_TYPE_UPD("1","upd"),
    SEND_TYPE_NOSENT("0","未发送"),
    SEND_TYPE_HASSENT("1","已发送"),
    SEND_TYPE_SENDING("2","发送中"),
    SEND_TYPE_SENDFAILED("3","发送失败"),
    USER_STATUS_ALL("2", "全选"),
    USER_STATUS_WORKING("1", "在职"),
    USER_STATUS_LEAVE("0", "离职")
    ;


    private String code;
    private String desc;

    private DicCodeEnum(String code,String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
