package com.pingan.qhzx.anshao.platform.common.ext.utils;

import com.alibaba.dubbo.common.serialize.Serialization;
import com.pingan.pafa.redis.map.RedisMapBean;
import org.apache.commons.lang.reflect.FieldUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;

/**
 * Created by yuzilei022 on 16/10/26.
 */
public class CommonRedisMapBean<K, V> extends RedisMapBean<K, V> {
    private static final Logger logger = LoggerFactory.getLogger(CommonRedisMapBean.class);

    @Override
    protected K toKey(byte[] key) {
        if (key == null) {
            throw new IllegalArgumentException("key bytes is null.");
        } else {
            Field declaredField = FieldUtils.getDeclaredField(RedisMapBean.class, "_serialization", true);
            try {
                return this.deserialize((Serialization) declaredField.get(this), this.getKeyClazz(), key);
            } catch (IllegalAccessException e) {
                logger.error("", e);
                throw new IllegalArgumentException("Serialization not be init.");
            }

        }
    }
}
