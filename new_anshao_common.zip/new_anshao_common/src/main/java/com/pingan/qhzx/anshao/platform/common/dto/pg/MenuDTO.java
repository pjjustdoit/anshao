package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;



public class MenuDTO extends BaseDTO {
	
	private Integer id;
	
	private String authName;
	
	private String authCtx;
	
	private Integer orderBy;
	
	private Integer parentId;
	
	private String authClass;

	private String authOperType;

	//private List<MenuDTO> child;


	public String getAuthOperType() {
		return authOperType;
	}

	public void setAuthOperType(String authOperType) {
		this.authOperType = authOperType;
	}

	public String getAuthName() {
		return authName;
	}

	public void setAuthName(String authName) {
		this.authName = authName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getAuthCtx() {
		return authCtx;
	}

	public void setAuthCtx(String authCtx) {
		this.authCtx = authCtx;
	}

	public Integer getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(Integer orderBy) {
		this.orderBy = orderBy;
	}

//	public List<MenuDTO> getChild() {
//		return child;
//	}
//
//	public void setChild(List<MenuDTO> child) {
//		this.child = child;
//	}

	public String getAuthClass() {
		return authClass;
	}

	public void setAuthClass(String authClass) {
		this.authClass = authClass;
	}
}
