package com.pingan.qhzx.anshao.platform.common.service.model.bean;

import com.alibaba.fastjson.annotation.JSONField;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtRobot;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by yuzilei022 on 16/9/26.
 */
public class Request implements Serializable {

    private String orgCode;

    private String questionNo;

    private String custId;

    private String questionCtx;

    private HttpServletRequest request;

    private String serialNo;

    private Date submitDate;

    private MchtRobot mchtRobot;

    private Org org;

    private Boolean newSession = true;

    private Long qaSerialId;


    public MchtRobot getMchtRobot() {
        return mchtRobot;
    }

    public void setMchtRobot(MchtRobot mchtRobot) {
        this.mchtRobot = mchtRobot;
    }

    public Org getOrg() {
        return org;
    }

    public void setOrg(Org org) {
        this.org = org;
    }

    public Date getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(Date submitDate) {
        this.submitDate = submitDate;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getQuestionNo() {
        return questionNo;
    }

    public void setQuestionNo(String questionNo) {
        this.questionNo = questionNo;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getQuestionCtx() {
        return questionCtx;
    }

    public void setQuestionCtx(String questionCtx) {
        this.questionCtx = questionCtx;
    }

    @JSONField(serialize = false)
    public HttpServletRequest getRequest() {
        return request;
    }

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public Boolean getNewSession() {
        return newSession;
    }

    public void setNewSession(Boolean newSession) {
        this.newSession = newSession;
    }

    public Long getQaSerialId() {
        return qaSerialId;
    }

    public void setQaSerialId(Long qaSerialId) {
        this.qaSerialId = qaSerialId;
    }
}
