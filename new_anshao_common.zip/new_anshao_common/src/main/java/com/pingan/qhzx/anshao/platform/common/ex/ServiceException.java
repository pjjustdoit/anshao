package com.pingan.qhzx.anshao.platform.common.ex;

import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;

/**
 * Created by Ray on 2015/2/2.
 */
public class ServiceException extends RuntimeException {
    public static final String UNKNOWN_ERROR_CODE = "0001";
    private String errCode;

    private String errMsg;

    public ServiceException(String errMsg) {
        super(errMsg);
        this.errCode = UNKNOWN_ERROR_CODE;
        this.errMsg = errMsg;
    }

    public ServiceException(ResponseEnum responseEnum) {
        super(responseEnum.getMessage());
        this.errCode = responseEnum.getCode();
        this.errMsg = responseEnum.getMessage();
    }

    public ServiceException(String errMsg, Throwable e) {
        super(e);
        this.errCode = "0001";
        this.errMsg = errMsg;
    }

    public ServiceException(String errCode, String errMsg) {
        super(errMsg);
        this.errCode = errCode;
        this.errMsg = errMsg;
    }

    public ServiceException(String errCode, String errMsg, Throwable e) {
        super(e);
        this.errCode = errCode;
        this.errMsg = errMsg;
    }

    public ServiceException() {
        this("系统异常");
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
}
