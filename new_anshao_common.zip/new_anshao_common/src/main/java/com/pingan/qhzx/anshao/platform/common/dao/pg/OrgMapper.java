package com.pingan.qhzx.anshao.platform.common.dao.pg;

import com.pingan.qhzx.anshao.platform.common.bean.operateReport.OperateReporBean;
import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.dto.pg.OrgExt;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface OrgMapper extends BaseMapper {
	int deleteByPrimaryKey(Integer orgId);

	int insert(Org record);

	int insertSelective(Org record);

	Org selectByPrimaryKey(Integer orgId);

	int updateByPrimaryKeySelective(Org record);

	int updateByPrimaryKey(Org record);

	List<OrgExt> selectOrgList(Map<String, Object> params);

	Org queryOrgByOrgCode(@Param("orgCode") String orgCode);

	/**
	 * 运营报表查询
	 * 
	 * @param org
	 */
	List<OperateReporBean> selectOperateReportList(Org org);
    
    List<Org> querySelectList(@Param("orgId")Integer orgId);
    
    Org selectByUserId(Integer mchtUserId);
    
    List<Org> queryByParams(Map<String,Object> params);

	int updateOrgStatus(String orgStatus);

    List<Org> queryOrgInExpire();
    
    List<Org> selectByAuthCode(String authCode);

	Org needSyncOrg(@Param("orgId") Integer orgId);
}