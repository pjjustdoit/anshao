package com.pingan.qhzx.anshao.platform.common.web.common.controller.user;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.platform.common.bean.UserSessionBean;
import com.pingan.qhzx.anshao.platform.common.bean.ValidResult;
import com.pingan.qhzx.anshao.platform.common.bean.user.UserSearchCondition;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRole;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.IOrgService;
import com.pingan.qhzx.anshao.platform.common.service.mchtUser.IMchtUserService;
import com.pingan.qhzx.anshao.platform.common.service.role.IRoleService;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;
import com.pingan.qhzx.anshao.platform.common.web.common.controller.AnshaoPtCommonController;
import com.pingan.qhzx.anshao.platform.common.web.form.RoleForm;
import com.pingan.qhzx.anshao.platform.common.web.form.UserForm;

/**
 * Created by yuzilei869 on 16/7/21.
 */

public class UserCommonController extends AnshaoPtCommonController {

	private static final Logger log = LoggerFactory.getLogger(UserCommonController.class);

	@Autowired
	private IOrgService orgService;
	
	@Autowired
	private IMchtUserService mchtUserService;
	
	@Autowired
	private IRoleService roleService;
	
	/**
	 * 所属机构和自己创建的用户
	 * @param pageForm
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/list/")
	public JSONObject userList(UserForm userForm, HttpServletRequest request) {
		try {
			HashMap<String, Object> data = new HashMap<String, Object>();

			UserSessionBean userSessionBean = getUserInfo(request);
			
			String roleCodeSession = userSessionBean.getRoleCode();

			UserSearchCondition userSearchCondition = new UserSearchCondition();
			userSearchCondition.setLoginName(userForm.getLoginName());
			userSearchCondition.setMchtUserRoleId(userForm.getMchtUserRoleId());
			userSearchCondition.setUserName(userForm.getUserName());
			userSearchCondition.setUserStatus(userForm.getUserStatus());
			
			PageInfo<MchtUser> mchtUserPage = mchtUserService.getMchtUserList(userForm.getCurrentPage(),
					userForm.getPageSize(), userSessionBean.getOrgId(), userSessionBean.getLoginName(),
					roleCodeSession, userSearchCondition);

			data.put("list", mchtUserPage.getList());
			data.put("totalCount", mchtUserPage.getTotal());
			data.put("currentPage", mchtUserPage.getPageNum());

			return WebUtils.createSuccResult(data);
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	@ResponseBody
	@RequestMapping("/list/roleSelect")
	public JSONObject queryUserRoleSelect(RoleForm roleForm, HttpServletRequest request) {
		try {
			
			Map<String, Object> data = Maps.newHashMap();


			UserSessionBean userSessionBean = getUserInfo(request);
			String loginNameSession = userSessionBean.getLoginName();
			
			Integer orgId = userSessionBean.getOrgId();
			
			List<MchtUserRole> userRoleSelectList = roleService.queryUserQuerySelectList(loginNameSession, orgId);
			
			data.put("list", userRoleSelectList);
			
			return WebUtils.createSuccResult(data);
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	/**
	 * 用户状态变化
	 * @param pageForm
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/status/change")
	public JSONObject userStatusChange(UserForm userForm, HttpServletRequest request) {
		try {
			HashMap<String, Object> data = new HashMap<String, Object>();

			if (StringUtils.isBlank(userForm.getUserStatus())
					|| userForm.getMchtUserId() == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			
			UserSessionBean userSessionBean = getUserInfo(request);
			
			String loginNameSession = userSessionBean.getLoginName();

			ValidResult validResult = mchtUserService.userStatusChange(userForm.getMchtUserId(), loginNameSession, userForm.getUserStatus());

			return validResult.toWebResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	/**
	 * 初始化密码
	 * @param pageForm
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/initPwd")
	public JSONObject userInitPwd(UserForm userForm, HttpServletRequest request) {
		try {

			if (userForm.getMchtUserId() == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			
			UserSessionBean userSessionBean = getUserInfo(request);
			
			String loginNameSession = userSessionBean.getLoginName();
			
			ValidResult validResult = mchtUserService.userInitPwd(userForm.getMchtUserId(), loginNameSession);

			return validResult.toWebResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	/**
	 * 用户新增
	 * @param UserForm
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/add/")
	public JSONObject userAdd(UserForm userForm, HttpServletRequest request) {
		try {
			
			if (userForm.checkEmpty()) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			
			UserSessionBean userSessionBean = getUserInfo(request);
			
			String loginNameSession = userSessionBean.getLoginName();
			String roleCodeSession = userSessionBean.getRoleCode();
			Integer orgIdSession = userSessionBean.getOrgId();

			MchtUser mchtUser = new MchtUser();
			
			mchtUser.setOrgId(userForm.getOrgId());
			mchtUser.setUserStatus(userForm.getUserStatus());
			mchtUser.setLoginName(userForm.getLoginName());
			mchtUser.setUserName(userForm.getUserName());
			mchtUser.setUserEmail(userForm.getUserEmail());
			mchtUser.setMobile(userForm.getMobile());
			
			ValidResult validResult = mchtUserService.userAdd(mchtUser, userForm.getMchtUserRoleId(), loginNameSession, roleCodeSession, orgIdSession);
			
			return validResult.toWebResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	
	/**
	 * 用户编辑
	 * @param UserForm
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/upd/")
	public JSONObject userUpd(UserForm userForm, HttpServletRequest request) {
		try {
			
			if (userForm.checkEmpty()
					|| userForm.getMchtUserId() == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			
			UserSessionBean userSessionBean = getUserInfo(request);
			
			String loginNameSession = userSessionBean.getLoginName();
			String roleCodeSession = userSessionBean.getRoleCode();
			Integer orgIdSession = userSessionBean.getOrgId();

			MchtUser mchtUser = new MchtUser();
			mchtUser.setMchtUserId(userForm.getMchtUserId());
			mchtUser.setOrgId(userForm.getOrgId());
			mchtUser.setUserStatus(userForm.getUserStatus());
			mchtUser.setLoginName(userForm.getLoginName());
			mchtUser.setUserName(userForm.getUserName());
			mchtUser.setUserEmail(userForm.getUserEmail());
			mchtUser.setMobile(userForm.getMobile());
			
			ValidResult validResult = mchtUserService.userUpd(mchtUser, userForm.getMchtUserRoleId(), loginNameSession, roleCodeSession, orgIdSession);
			
			return validResult.toWebResult();
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	/**
	 * 用户编辑前的查询
	 * @param UserForm
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/upd/select")
	public JSONObject userUpdSelect(UserForm userForm, HttpServletRequest request) {
		try {
			if (userForm.getMchtUserId() == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			
			MchtUser mchtUser = mchtUserService.queryUpdateSelectList(userForm.getMchtUserId());
			if (mchtUser == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}
			
			UserSessionBean userSessionBean = getUserInfo(request);
			// 判断用户是否是自己创建的
			if (!mchtUser.getCreatedBy().equals(userSessionBean.getLoginName())) {
				return WebUtils.createErrorResult(ResponseEnum.USER_OPERATE_AUTH_FAILURE);
			}
			
			return WebUtils.createSuccResult(mchtUser);
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	
	public JSONObject updateUserRoleSelect(RoleForm roleForm, HttpServletRequest request) {
		try {
			
			Map<String, Object> data = Maps.newHashMap();

			if (roleForm.getOrgId() == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}

			UserSessionBean userSessionBean = getUserInfo(request);
			String loginNameSession = userSessionBean.getLoginName();
			
			List<MchtUserRole> userRoleSelectList = roleService.queryUserUpdateSelectList(loginNameSession, roleForm.getOrgId());
			
			data.put("list", userRoleSelectList);
			
			return WebUtils.createSuccResult(data);
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
}
