package com.pingan.qhzx.anshao.platform.common.service.traffic;

import com.pingan.pafa.redis.map.RedisMapBean;
import com.pingan.qhzx.anshao.platform.common.dao.pg.*;
import com.pingan.qhzx.anshao.platform.common.dto.pg.*;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.AnswerParser;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.QaCountBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * Created by yuzilei022 on 16/9/26.
 */
@Component
public class TrafficService implements ITrafficService {
    private static final Logger logger = LoggerFactory.getLogger(TrafficService.class);

    @Autowired
    private MchtTrafficSerialMapper mchtTrafficSerialMapper;

    @Autowired
    private TrafficAccountMapper trafficAccountMapper;

    @Autowired
    private MchtRobotMapper mchtRobotMapper;

    @Autowired
    private QaSerialMapper qaSerialMapper;

    @Autowired
    private UnknownQaMapper unknownQaMapper;

    @Autowired
    @Qualifier("orgQaCounter")
    private RedisMapBean<String, QaCountBean> orgQaCounter;

    public String generateSerialNo() {
        return mchtTrafficSerialMapper.querySerialNo();
    }

    @Override
    public MchtRobot selectRobotByOrgCode(String orgCode) {
        return mchtRobotMapper.selectRobotByOrgCode(orgCode);
    }

    @Override
    public TrafficAccount selectMchtTrafficAccountByOrgId(Integer orgId) {
        return trafficAccountMapper.selectByPrimaryKey(orgId);
    }

    @Async
    @Override
    public void record(QaSerial qaSerial) {
        qaSerialMapper.insert(qaSerial);
    }

    @Override
    public Long selectQaSerialId() {
        return qaSerialMapper.selectQaSerialId();
    }

    @Transactional
    @Override
    public void saveOrgTrafficSerial(MchtTrafficSerial mchtTrafficSerial, Integer recThreshold) {
        mchtTrafficSerialMapper.insert(mchtTrafficSerial);
        setOrgQaCounter(mchtTrafficSerial, recThreshold);
    }

    private void setOrgQaCounter(MchtTrafficSerial mchtTrafficSerial, Integer recThreshold) {
        QaCountBean qaCountBean = getQaCountBean(mchtTrafficSerial);
        if (qaCountBean == null) {
            qaCountBean = new QaCountBean();
        }
        Long occurNum = mchtTrafficSerial.getOccurNum();
        qaCountBean.plusOccurSum(occurNum);
        if (qaCountBean.needRefresh(recThreshold)) {
            updateOrgTrafficAndInitCache(mchtTrafficSerial.getOrgId(), qaCountBean);
        }
        orgQaCounter.put(mchtTrafficSerial.getOrgId() + "", qaCountBean);
    }

    @Transactional
    @Override
    public void updateOrgTrafficAndInitCache(Integer orgId, QaCountBean qaCountBean) {
        Long batchNo = mchtTrafficSerialMapper.queryNextChargingBatchNo();
        Integer counter = mchtTrafficSerialMapper.updateSerialBatchNo(batchNo, orgId);
        if (counter > 0) {
            trafficAccountMapper.updateAccountConsume(orgId, batchNo);
            qaCountBean.init();
            mchtTrafficSerialMapper.updateSerialChargingStatus(batchNo, "1");
        }
    }

    private QaCountBean getQaCountBean(MchtTrafficSerial mchtTrafficSerial) {
        QaCountBean qaCountBean = null;
        try {
            qaCountBean = orgQaCounter.get(mchtTrafficSerial.getOrgId() + "");
        } catch (Exception e) {
            return null;
        }
        return qaCountBean;
    }

    @Async
    @Override
    public void recUnknownQa(AnswerParser answerParser, String unknownType) {
        UnknownQa unknownQa = new UnknownQa();
        unknownQa.setSerialNo(answerParser.getSerialNo());
        unknownQa.setCreatedBy("system");
        unknownQa.setCreatedDate(new Date());
        unknownQa.setUpdatedBy("system");
        unknownQa.setSyncStatus("0");
        unknownQa.setUpdatedDate(new Date());
        unknownQa.setUnknownType(unknownType);
        try {
            unknownQaMapper.insert(unknownQa);
        } catch (Exception e) {
            logger.error("", e);
        }
    }
}
