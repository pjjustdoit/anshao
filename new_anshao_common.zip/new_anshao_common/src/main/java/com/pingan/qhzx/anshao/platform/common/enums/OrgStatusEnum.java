package com.pingan.qhzx.anshao.platform.common.enums;

public enum OrgStatusEnum {
	
	COOPERATING("1","合作中"),
	PAUSE_COOPERATION("2","暂停合作");
	
	public String code;
	private String desc;
	
	private OrgStatusEnum(String code,String desc){
		this.code = code;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
}
