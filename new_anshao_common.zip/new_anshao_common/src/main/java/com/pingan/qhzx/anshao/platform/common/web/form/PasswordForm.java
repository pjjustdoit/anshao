package com.pingan.qhzx.anshao.platform.common.web.form;

/**
 * Created by yuzilei869 on 16/7/21.
 */
public class PasswordForm extends LoginForm {

	private String originPwd;
	
	private boolean flag;

	public String getOriginPwd() {
		return originPwd;
	}

	public void setOriginPwd(String originPwd) {
		this.originPwd = originPwd;
	}

	public boolean isValidOriginPwd() {
		return getOriginPwd().length() == 32;
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}
}
