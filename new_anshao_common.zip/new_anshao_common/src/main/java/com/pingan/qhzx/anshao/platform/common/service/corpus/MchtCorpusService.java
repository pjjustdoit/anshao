package com.pingan.qhzx.anshao.platform.common.service.corpus;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.platform.common.bean.CorpusImportResultBean;
import org.apache.commons.lang.StringUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.bean.CorpusImportBean;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtCorpusCtxMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtCorpusOutlineMapper;
import com.pingan.qhzx.anshao.platform.common.dao.pg.ZskClassifyMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtxExt;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusOutline;
import com.pingan.qhzx.anshao.platform.common.dto.pg.ZskClassify;
import com.pingan.qhzx.anshao.platform.common.enums.EffectiveFlagEnum;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.enums.TargetUpdateFieldEnum;
import com.pingan.qhzx.anshao.platform.common.ex.ServiceException;
import com.pingan.qhzx.anshao.platform.common.service.model.CorpusSyncService;
import com.pingan.qhzx.anshao.platform.common.utils.ExcelExporterUtils;
import com.pingan.qhzx.anshao.platform.common.utils.ExcelImpotUtils;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;
import com.pingan.qhzx.anshao.platform.common.web.form.MchtCorpusCtxForm;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zhangshan193 on 16/9/30.
 */
@Service
public class MchtCorpusService implements IMchtCorpusService {

    private static final Logger logger = LoggerFactory.getLogger(MchtCorpusService.class);

    @Autowired
    private MchtCorpusCtxMapper mchtCorpusCtxMapper;

    @Autowired
    private MchtCorpusOutlineMapper mchtCorpusOutlineMapper;

    @Autowired
    private ZskClassifyMapper zskClassifyMapper;


    @Override
    public MchtCorpusOutline getMchtCorpusOutlineByOrgId(Integer orgId) {
        return mchtCorpusOutlineMapper.selectByPrimaryKey(orgId);
    }

    @Transactional
    @Override
    public JSONObject addCorpus(MchtCorpusCtxForm mchtCorpusCtxForm) throws IllegalArgumentException,ServiceException{
        // 语料增加:1、概要表 2、语料表
        MchtCorpusCtx mchtCorpusCtx = propertyCopy(mchtCorpusCtxForm);
        Date curDate = Calendar.getInstance().getTime();
        if(mchtCorpusCtx.getExpireDate() != null && curDate.after(mchtCorpusCtx.getExpireDate())){
        	logger.info("addCorpus mchtCorpusCtx.getExpireDate():"+mchtCorpusCtx.getExpireDate());
            return WebUtils.createErrorResult(ResponseEnum.EXPIRE_DATE_ILLEGAL);
        }
        ZskClassify zskClassify = zskClassifyMapper.selectByPrimaryKey(mchtCorpusCtx.getZskClassifyId());
        if(zskClassify == null){
            logger.info("知识库分类表对应的纪录不存在,mchtCorpusCtx.getZskClassifyId():"+mchtCorpusCtx.getZskClassifyId());
            return WebUtils.createErrorResult(ResponseEnum.CLASSIFY_ID_NOT_EXISTS);
        }
        mchtCorpusCtx.setEffectiveFlag(EffectiveFlagEnum.EFFECTIVE.getCode());
        mchtCorpusCtx.setCreatedDate(curDate);
        mchtCorpusCtx.setUpdatedDate(curDate);
        mchtCorpusCtx.setUpdatedBy(mchtCorpusCtx.getCreatedBy());


        // 并发操作,加行级锁
        MchtCorpusOutline mchtCorpusOutline = mchtCorpusOutlineMapper.selectByOrgIdWithLock(mchtCorpusCtxForm.getOrgId());

        mchtCorpusOutline.setUpdatedDate(curDate);
        mchtCorpusOutline.setUpdatedBy(mchtCorpusCtxForm.getUpdatedBy());

        if(mchtCorpusOutline.getCorpusSurplusNum()<= 0){
        	logger.info("语料数量异常,mchtCorpusOutline.getCorpusSurplusNum():"+mchtCorpusOutline.getCorpusSurplusNum());
        	return WebUtils.createErrorResult(ResponseEnum.CORPUS_SURPLUS_NUM_ZERO);
        }
        
        if(mchtCorpusOutline.getCorpususenum() >= mchtCorpusOutline.getCorpusTotalNum()){
        	logger.info("语料数量异常,corpususenum:"+mchtCorpusOutline.getCorpususenum()+",corpusTotalNum:"+mchtCorpusOutline.getCorpusTotalNum());
        	return WebUtils.createErrorResult(ResponseEnum.CORPUS_USE_GREATER_THAN_TOTAL);
        }

        mchtCorpusOutline.setCorpusSurplusNum(mchtCorpusOutline.getCorpusSurplusNum() - 1); // 语料池剩余量
        mchtCorpusOutline.setCorpususenum(mchtCorpusOutline.getCorpususenum() + 1); // 语料池可使用语料
        
        
        mchtCorpusCtxMapper.insertSelective(mchtCorpusCtx);
        mchtCorpusOutlineMapper.updateByPrimaryKeySelective(mchtCorpusOutline);
        return WebUtils.createSuccResult();
    }

    /**
     * 属性值复制
     * @param mchtCorpusCtxForm
     * @return
     */
    private MchtCorpusCtx propertyCopy(MchtCorpusCtxForm mchtCorpusCtxForm){
        MchtCorpusCtx mchtCorpusCtx = new MchtCorpusCtx();
        mchtCorpusCtx.setEffectiveFlag(mchtCorpusCtxForm.getEffectiveFlag());
        mchtCorpusCtx.setUpdatedDate(mchtCorpusCtxForm.getUpdatedDate());
        mchtCorpusCtx.setUpdatedBy(mchtCorpusCtxForm.getUpdatedBy());
        mchtCorpusCtx.setAnswer(filterSpecialCharacter(mchtCorpusCtxForm.getAnswer()));
        mchtCorpusCtx.setCreatedDate(mchtCorpusCtxForm.getCreatedDate());
        mchtCorpusCtx.setCreatedBy(mchtCorpusCtxForm.getCreatedBy());
        mchtCorpusCtx.setExactMatchFlag(mchtCorpusCtxForm.getExactMatchFlag());
        mchtCorpusCtx.setKeyWord(filterSpecialCharacter(mchtCorpusCtxForm.getKeyWord()));
        mchtCorpusCtx.setMchtCorpusCtxId(mchtCorpusCtxForm.getMchtCorpusCtxId());
        mchtCorpusCtx.setQuestion(filterSpecialCharacter(mchtCorpusCtxForm.getQuestion()));
        mchtCorpusCtx.setOrgId(mchtCorpusCtxForm.getOrgId());
        mchtCorpusCtx.setZskClassifyId(mchtCorpusCtxForm.getZskClassifyId());
        mchtCorpusCtx.setMchtCorpusCtxId(mchtCorpusCtxForm.getMchtCorpusCtxId());
        mchtCorpusCtx.setExpireDate(mchtCorpusCtxForm.getExpireDate());

        return mchtCorpusCtx;
    }

    /**
     * 批量修改
     * 修改目标:
     * 1、精确匹配 请选择  是   否
     * 2、分类名称 请选择  分类管理中的所有分类
     * 3、有效期限 日期控件选择日期
     * zskClassifyId:分类id,
     * exactMatchFlag：精确匹配 1=是 0=否
     * question：内容问题
     * queryStartDate：修改日期区间开始
     * queryEndDate：修改日期区间结束
     * targetField:目标字段 exactMatchFlag＝精确匹配 zskClassify＝分类 expireDate 有效期
     * fieldValue：对应修改的值 String 日期格式 yyyy-MM-dd
     * @param mchtCorpusCtxForm
     * @return
     * @throws ServiceException
     */
    @Override
    public JSONObject batchUpdate(MchtCorpusCtxForm mchtCorpusCtxForm)throws ServiceException {
        // 1、验证知识库分类是否存在
        if(TargetUpdateFieldEnum.ZSK_CLASSIFY_ID.getCode().equals(mchtCorpusCtxForm.getTargetField())){
            ZskClassify zskClassify = zskClassifyMapper.selectByPrimaryKey(Integer.parseInt(mchtCorpusCtxForm.getFieldValue()));
            if(zskClassify == null){
                logger.info("知识库分类表对应的纪录不存在,mchtCorpusCtxForm.getZskClassifyId():"+mchtCorpusCtxForm.getFieldValue());
                return WebUtils.createErrorResult(ResponseEnum.CLASSIFY_ID_NOT_EXISTS);
            }
        }
        Map<String,Object> params  = wrapperMap(mchtCorpusCtxForm);

        // 2、验证输入的更新时间是否在当前日期之前
        Date curDate = Calendar.getInstance().getTime();
        Object expireDateObj = params.get("newExpireDate");
        if(expireDateObj != null){
            Date expireDate = (Date)expireDateObj;
            if(curDate.after(expireDate)){
                logger.info("expire date illegal");
                return WebUtils.createErrorResult(ResponseEnum.EXPIRE_DATE_ILLEGAL);
            }
            params.put("effectiveFlag",EffectiveFlagEnum.EFFECTIVE.getCode());
        }
        
        params.put("updatedDate",Calendar.getInstance().getTime());
        params.put("updatedBy",mchtCorpusCtxForm.getUpdatedBy());
        mchtCorpusCtxMapper.batchUpdate(params);
        return WebUtils.createSuccResult();
    }

    /**
     * 将mchtCorpusCtxForm装配成map
     * @param mchtCorpusCtxForm
     * @return
     */
    private Map<String,Object> wrapperMap(MchtCorpusCtxForm mchtCorpusCtxForm){
        Map<String,Object> params = new HashedMap();
        String mchtCorpusCtxIdListStr = mchtCorpusCtxForm.getMchtCorpusCtxIdList();

        if(!StringUtils.isBlank(mchtCorpusCtxIdListStr)){
            List<Integer> mchtCorpusCtxIdList = new ArrayList<Integer>();
            for(String temp:mchtCorpusCtxIdListStr.trim().split("\\|")){
                try{
                    mchtCorpusCtxIdList.add(Integer.parseInt(temp.trim()));
                }catch (Exception e){
                    logger.error("{}",e);
                }
            }
            if(mchtCorpusCtxIdList != null && !mchtCorpusCtxIdList.isEmpty()) {
                params.put("mchtCorpusCtxIdList", mchtCorpusCtxIdList);
            }
        }
        Integer orgId = mchtCorpusCtxForm.getOrgId();
        if(orgId != null){
        	params.put("orgId", orgId);
        }

        Integer zskClassifyId = mchtCorpusCtxForm.getZskClassifyId();
        if(zskClassifyId != null) {
            params.put("zskClassifyId", zskClassifyId);
        }
        String exactMatchFlag = mchtCorpusCtxForm.getExactMatchFlag();
        if(!StringUtils.isBlank(exactMatchFlag)) {
            params.put("exactMatchFlag", exactMatchFlag);
        }
        String question = mchtCorpusCtxForm.getQuestion();
        if(!StringUtils.isBlank(question)) {
            params.put("question", filterSpecialCharacter(question));
        }
        if(mchtCorpusCtxForm.getQueryStartDate() != null){

            params.put("queryStartDate",mchtCorpusCtxForm.getQueryStartDate());
        }
        if(mchtCorpusCtxForm.getQueryEndDate() != null){
            Calendar calTemp = Calendar.getInstance();
            calTemp.setTime(mchtCorpusCtxForm.getQueryEndDate());
            calTemp.add(Calendar.DATE,1);
            params.put("queryEndDate",calTemp.getTime());
        }
        if(!StringUtils.isBlank(mchtCorpusCtxForm.getTargetField())) {
            String targetField = mchtCorpusCtxForm.getTargetField().trim();
            String fieldValue = mchtCorpusCtxForm.getFieldValue().trim();
            if (TargetUpdateFieldEnum.EXACT_MATCH_FLAG.getCode().equals(targetField)) {
                params.put("newExactMatchFlag", fieldValue);
            } else if (TargetUpdateFieldEnum.ZSK_CLASSIFY_ID.getCode().equals(targetField)) {
                params.put("newZskClassifyId", Integer.parseInt(fieldValue));
            } else {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    params.put("newExpireDate", sdf.parse(fieldValue));
                } catch (Exception e) {
                    logger.info("parse error,fieldValue:"+fieldValue);
                    logger.error("{}",e);
                }
            }
        }

        return params;
    }

    @Override
    public JSONObject update(MchtCorpusCtxForm mchtCorpusCtxForm)throws ServiceException {
        // 更新语料
        // 1、验证知识库分类是否存在
        if(mchtCorpusCtxForm.getZskClassifyId() != null) {
            ZskClassify zskClassify = zskClassifyMapper.selectByPrimaryKey(mchtCorpusCtxForm.getZskClassifyId());
            if (zskClassify == null) {
                logger.info("知识库分类表对应的纪录不存在,mchtCorpusCtxForm.getZskClassifyId():" + mchtCorpusCtxForm.getZskClassifyId());
                return WebUtils.createErrorResult(ResponseEnum.CLASSIFY_ID_NOT_EXISTS);
            }
        }
        MchtCorpusCtx mchtCorpusCtx = propertyCopy(mchtCorpusCtxForm);

        Date curDate = Calendar.getInstance().getTime();
        Date expireDate = mchtCorpusCtx.getExpireDate();
        // 2、验证输入的更新时间是否在当前日期之前,若在,则设置该纪录的有效标志为 无效
        if(expireDate != null && curDate.after(expireDate)){
            logger.info("update expire date illegal");
            return WebUtils.createErrorResult(ResponseEnum.EXPIRE_DATE_ILLEGAL);
        }
        if(expireDate != null){
        	mchtCorpusCtx.setEffectiveFlag(EffectiveFlagEnum.EFFECTIVE.getCode());
        }
        mchtCorpusCtx.setUpdatedDate(curDate);

        mchtCorpusCtxMapper.updateByPrimaryKeySelective(mchtCorpusCtx);
        return WebUtils.createSuccResult();
    }

    @Transactional
    @Override
    public JSONObject delete(MchtCorpusCtxForm mchtCorpusCtxForm) {
        

        // 并发操作,加行级锁
        MchtCorpusOutline mchtCorpusOutline = mchtCorpusOutlineMapper.selectByOrgIdWithLock(mchtCorpusCtxForm.getOrgId());

        mchtCorpusOutline.setUpdatedDate(Calendar.getInstance().getTime());
        mchtCorpusOutline.setUpdatedBy(mchtCorpusCtxForm.getUpdatedBy());
        if(mchtCorpusOutline.getCorpususenum() <= 0){
        	logger.info("delete 已用语料数小于等于0, corpususenum:"+mchtCorpusOutline.getCorpususenum());
        	return WebUtils.createErrorResult(ResponseEnum.CORPUS_USE_NUM_ZERO);
        }
        
        if(mchtCorpusOutline.getCorpusSurplusNum() >= mchtCorpusOutline.getCorpusTotalNum()){
        	logger.info("delete 剩余可用语料数大于等于语料总数  corpusSurplusNum:"+mchtCorpusOutline.getCorpusSurplusNum()+",totalNum:"+mchtCorpusOutline.getCorpusTotalNum());
        	return WebUtils.createErrorResult(ResponseEnum.CORPUS_SURPLUS_GREATER_THAN_TOTAL);
        }
        int affectRows = mchtCorpusCtxMapper.deleteByPrimaryKey(mchtCorpusCtxForm.getMchtCorpusCtxId());
        // 若语料池剩余量 < 语料池总量 且 语料池可用语料数量 > 0
        mchtCorpusOutline.setCorpusSurplusNum(mchtCorpusOutline.getCorpusSurplusNum() + 1); // 语料池剩余量
        mchtCorpusOutline.setCorpususenum(mchtCorpusOutline.getCorpususenum() - 1); // 语料池可使用语料
        
        mchtCorpusOutlineMapper.updateByPrimaryKeySelective(mchtCorpusOutline);
        return WebUtils.createSuccResult();
    }

    @Override
    public MchtCorpusCtx getMchtCorpusCtxById(Long mchtCorpusCtxId) {
        return mchtCorpusCtxMapper.selectByPrimaryKey(mchtCorpusCtxId);
    }

    @Override
    public Map<String,Object> selectByParams(MchtCorpusCtxForm mchtCorpusCtxForm) {
        Map<String,Object> params = wrapperMap(mchtCorpusCtxForm);

        PageHelper.startPage(mchtCorpusCtxForm.getCurrentPage(),mchtCorpusCtxForm.getPageSize(),true);
        List<MchtCorpusCtxExt> mchtCorpusCtxExtList = mchtCorpusCtxMapper.selectByParams(params);

        PageInfo<MchtCorpusCtxExt> orgPageInfo = new PageInfo<MchtCorpusCtxExt>(mchtCorpusCtxExtList);

        Map<String,Object> resultMap = new HashMap<String,Object>();
        resultMap.put("totalCount",orgPageInfo.getTotal());
        resultMap.put("currentPage",orgPageInfo.getPageNum());
        resultMap.put("list",mchtCorpusCtxExtList);

        return resultMap;
    }

    @Override
    public void exportByParams(MchtCorpusCtxForm mchtCorpusCtxForm,HttpServletResponse response) {
        Map<String,Object> params = wrapperMap(mchtCorpusCtxForm);
        List<MchtCorpusCtxExt> mchtCorpusCtxExtList = mchtCorpusCtxMapper.selectByParams(params);

        if(mchtCorpusCtxExtList == null){
            mchtCorpusCtxExtList = new ArrayList<MchtCorpusCtxExt>();
        }

        List<ExcelExporterUtils.FiledDefine> filedDefineList = new ArrayList<ExcelExporterUtils.FiledDefine>();

        filedDefineList.add(new ExcelExporterUtils.FiledDefine("分类名称","classifyName"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("精准匹配","exactMatchFlagStr"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("内容问题","question"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("内容答案","answer"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("有效期限","expireDate", ExcelExporterUtils.FiledType.DATE));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("是否有效","effectiveFlagStr"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("修改时间","updatedDate", ExcelExporterUtils.FiledType.DATE));
        String fileName = "corpus_"+System.currentTimeMillis()+".xls";
        ExcelExporterUtils.exportXLS(fileName,mchtCorpusCtxExtList, filedDefineList,response);
    }

    @Override
    public JSONObject importMchtCorpusCtx(MchtCorpusCtxForm mchtCorpusCtxForm, HttpServletRequest request) {

        InputStream is = null;
        String fileName = null;
        if( mchtCorpusCtxForm.getCorpusFile().getSize() > 2097152){
        	return WebUtils.createErrorResult(ResponseEnum.File_TOO_LARGE);
        }
        try{
            is = mchtCorpusCtxForm.getCorpusFile().getInputStream();
            fileName = mchtCorpusCtxForm.getCorpusFile().getOriginalFilename();
        }catch(Exception e){
            logger.error("{}",e);
        }
        List<ExcelImpotUtils.FieldDefine> fieldDefineList = new ArrayList<ExcelImpotUtils.FieldDefine>();

        fieldDefineList.add(new ExcelImpotUtils.FieldDefine("分类名称","classifyName"));
        fieldDefineList.add(new ExcelImpotUtils.FieldDefine("精准匹配","exactMatchFlag"));
        fieldDefineList.add(new ExcelImpotUtils.FieldDefine("内容问题","question"));
        fieldDefineList.add(new ExcelImpotUtils.FieldDefine("内容答案","answer"));
        fieldDefineList.add(new ExcelImpotUtils.FieldDefine("有效期限","expireDateValue"));
        fieldDefineList.add(new ExcelImpotUtils.FieldDefine("关键字","keyWord"));

        List<CorpusImportBean> corpusImportBeanList = ExcelImpotUtils.excelToList(is,1, CorpusImportBean.class,fieldDefineList,fileName);
        if(corpusImportBeanList ==null || corpusImportBeanList.size() <= 1){
            return WebUtils.createErrorResult();
        }

        JSONObject resultJsonObj = convertCorpusImportBean2CorpusCtx(corpusImportBeanList,mchtCorpusCtxForm,request);

        return resultJsonObj;
    }

    @Override
    public int statusChange(MchtCorpusCtxForm mchtCorpusCtxForm) {
        Calendar currCal = Calendar.getInstance();
        Date nowDate = currCal.getTime();
        MchtCorpusCtx mchtCorpusCtx = this.mchtCorpusCtxMapper.selectByPrimaryKey(mchtCorpusCtxForm.getMchtCorpusCtxId());
        
        mchtCorpusCtx.setUpdatedBy(mchtCorpusCtxForm.getUpdatedBy());
        mchtCorpusCtx.setUpdatedDate(nowDate);
        mchtCorpusCtx.setEffectiveFlag(mchtCorpusCtxForm.getEffectiveFlag());
        
        // 如果从无效 变为 有效，过期时间 在当前日期之前 则将有效期变更为 2099-12-31
        if("1".equals(mchtCorpusCtxForm.getEffectiveFlag())){
        	logger.info("mchtCorpusCtx.getExpireDate():"+mchtCorpusCtx.getExpireDate());
        	if(mchtCorpusCtx.getExpireDate() != null &&( mchtCorpusCtx.getExpireDate().before(nowDate) || mchtCorpusCtx.getExpireDate().equals(nowDate))){
        		mchtCorpusCtx.setExpireDate(null);
        	}
        }

        return mchtCorpusCtxMapper.updateByPrimaryKey(mchtCorpusCtx);
    }

    @Override
    public void downloadFailedExcel(HttpServletRequest request,HttpServletResponse response) {
        Object failedCorpusImportBeanListObj = request.getSession().getAttribute("failedCorpusImportBeanList");
        List<CorpusImportBean> failedCorpusImportBeanList = null;
        if(failedCorpusImportBeanListObj == null){
            failedCorpusImportBeanList = new ArrayList<CorpusImportBean>();
        }else{
            failedCorpusImportBeanList = (List<CorpusImportBean>)failedCorpusImportBeanListObj;
        }
        List<ExcelExporterUtils.FiledDefine> filedDefineList = new ArrayList<ExcelExporterUtils.FiledDefine>();

        filedDefineList.add(new ExcelExporterUtils.FiledDefine("分类名称","classifyName"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("精准匹配","exactMatchFlag"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("内容问题","question"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("内容答案","answer"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("有效期限","expireDateValue"));
        filedDefineList.add(new ExcelExporterUtils.FiledDefine("关键字","keyWord"));
        
        String fileName = "failed_corpus_"+System.currentTimeMillis()+".xls";
        ExcelExporterUtils.exportXLS(fileName,failedCorpusImportBeanList, filedDefineList,response);
    }

    private JSONObject convertCorpusImportBean2CorpusCtx(List<CorpusImportBean> corpusImportBeanList,MchtCorpusCtxForm mchtCorpusCtxFormTemp,HttpServletRequest request){
    	ZskClassify zskClassify = new ZskClassify();
    	zskClassify.setOrgId(mchtCorpusCtxFormTemp.getOrgId());
        List<ZskClassify> zskClassifyList = zskClassifyMapper.selectClassifyList(zskClassify);
        List<CorpusImportBean> failedCorpusImportBeanList = new ArrayList<CorpusImportBean>();
        int totalRows = corpusImportBeanList.size() - 1;
        for(int i = 1;i<corpusImportBeanList.size();i++){
            CorpusImportBean corpusImportBean = corpusImportBeanList.get(i);
            MchtCorpusCtxForm mchtCorpusCtxForm = new MchtCorpusCtxForm();

            if(validateRows(corpusImportBean,zskClassifyList,mchtCorpusCtxForm) == false){

                failedCorpusImportBeanList.add(corpusImportBean);
                continue;
            }

            mchtCorpusCtxForm.setOrgId(mchtCorpusCtxFormTemp.getOrgId());
            mchtCorpusCtxForm.setUpdatedBy(mchtCorpusCtxFormTemp.getUpdatedBy());
            mchtCorpusCtxForm.setCreatedBy(mchtCorpusCtxFormTemp.getUpdatedBy());

            mchtCorpusCtxForm.setQuestion(corpusImportBean.getQuestion());
            mchtCorpusCtxForm.setAnswer(corpusImportBean.getAnswer());
            mchtCorpusCtxForm.setKeyWord(corpusImportBean.getKeyWord());
            String exactMatchFlagStr = corpusImportBean.getExactMatchFlag();
            int exactMatchFlag = 0;

            exactMatchFlag = Integer.parseInt(exactMatchFlagStr);
            if(exactMatchFlag == 1) {
                mchtCorpusCtxForm.setExactMatchFlag("1");
            }else{
                mchtCorpusCtxForm.setExactMatchFlag("0");
            }

            String expireDateValueStr = corpusImportBean.getExpireDateValue();
            int expireDateValue = 0;
            expireDateValue = Integer.parseInt(expireDateValueStr);

            Calendar curCal = Calendar.getInstance();
            switch (expireDateValue){
                case 1:
                    curCal.add(Calendar.DATE,180);
                    break;
                case 2:
                    curCal.add(Calendar.YEAR,1);
                    break;
                case 3:
                    curCal.add(Calendar.YEAR,5);
                    break;
                case 4:
                    curCal.add(Calendar.YEAR,10);
                    break;
                default:
                    curCal.add(Calendar.YEAR,100);
                    break;
            }
            mchtCorpusCtxForm.setExpireDate(curCal.getTime());
            try {
                JSONObject jsonObj = addCorpus(mchtCorpusCtxForm);
                if(jsonObj == null || !ResponseEnum.SUCCESS.getCode().equals(jsonObj.getString("code"))){
                    logger.info("jsonObj.getString(\"code\"):"+jsonObj.getString("code"));
                	failedCorpusImportBeanList.add(corpusImportBean);
                }
            }catch (Exception e){
                logger.info("convertCorpusImportBean2CorpusCtx 添加语料失败,"+mchtCorpusCtxForm);
                logger.error("{}",e);
                failedCorpusImportBeanList.add(corpusImportBean);
            }
        }

        request.getSession().setAttribute("failedCorpusImportBeanList",failedCorpusImportBeanList);
        CorpusImportResultBean corpusImportResultBean = new CorpusImportResultBean();
        corpusImportResultBean.setFailedRows(failedCorpusImportBeanList.size());
        corpusImportResultBean.setSuccessRows(totalRows - failedCorpusImportBeanList.size());
        corpusImportResultBean.setTotalRows(totalRows);
        corpusImportResultBean.setDownloadUrl("/mcht/zsk/corpus/downloadFailedExcel");
        return WebUtils.createSuccResult(corpusImportResultBean);
    }

    /**
     * 验证导入的bean的合法性
     * @param corpusImportBean
     * @param zskClassifyList
     * @param mchtCorpusCtxForm
     * @return
     */
    private boolean validateRows(CorpusImportBean corpusImportBean,List<ZskClassify> zskClassifyList,MchtCorpusCtxForm mchtCorpusCtxForm){
        if(corpusImportBean == null || StringUtils.isBlank(corpusImportBean.getClassifyName())
            || StringUtils.isBlank(corpusImportBean.getAnswer())
            || StringUtils.isBlank(corpusImportBean.getExactMatchFlag())
            || StringUtils.isBlank(corpusImportBean.getQuestion())
            || StringUtils.isBlank(corpusImportBean.getExpireDateValue())
            || zskClassifyList == null || zskClassifyList.isEmpty()){
                return false;
        }

        // 查看分类名称是否存在,若不存在则返回false
        boolean classifyNameExistsFlag = false;
        for(ZskClassify zskClassify:zskClassifyList){
            if(zskClassify.getClassifyName().equals(corpusImportBean.getClassifyName())){
                mchtCorpusCtxForm.setZskClassifyId(zskClassify.getZskClassifyId());
                classifyNameExistsFlag = true;
            }
        }
        if(classifyNameExistsFlag == false){
            return false;
        }
        corpusImportBean.setExactMatchFlag(corpusImportBean.getExactMatchFlag().replaceAll("\\.0*",""));
        if(!corpusImportBean.getExactMatchFlag().matches("1|2")){
            return false;
        }

        if(corpusImportBean.getQuestion().length() > 60){
            return false;
        }

        if(corpusImportBean.getAnswer().length() > 500){
            return false;
        }

        corpusImportBean.setExpireDateValue(corpusImportBean.getExpireDateValue().replaceAll("\\.0*",""));
        if(!corpusImportBean.getExpireDateValue().matches("1|2|3|4|5")){
            return false;
        }
        
        String keyWord = corpusImportBean.getKeyWord();
        if(!StringUtils.isBlank(keyWord) && (keyWord.length() > 340)){
        	return false;
        }

        return true;
    }
    
    private String filterSpecialCharacter(String str){
    	if(StringUtils.isBlank(str)){
    		return str;
    	}
    	return str.replaceAll(",", "，").replaceAll("\"", "“").replaceAll("\r", "").replaceAll("\n", "");
    }
    
}
