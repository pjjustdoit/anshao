package com.pingan.qhzx.anshao.platform.common.service.mchtUser;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.pingan.qhzx.anshao.platform.common.bean.ValidResult;
import com.pingan.qhzx.anshao.platform.common.bean.user.UserSearchCondition;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserAuth;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRole;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MenuDTO;

public interface IMchtUserService {

	ValidResult loginValidUser(String loginName, String password);
	
	MchtUser queryUserByLoginName(String loginName);
	
	MchtUser selectForPwdChange(String loginName, String password);
	
	void pwdChange(MchtUser user);
	
	List<MchtUserRole> queryByUserIdOrgId(Integer mchtUserId, Integer orgId);
	
	List<MenuDTO> queryMenu(Integer mchtUserRoleId);
	
	List<MenuDTO> queryAllOutMenu();
	
	List<MchtUserAuth> queryAuthByOrgIdMchtUserId(Integer orgId,
    		Integer mchtUserId);

	PageInfo<MchtUser> getMchtUserList(Integer currentPage, Integer pageSize,
			Integer orgId, String loginNameSession, String roleCodeSession,
			UserSearchCondition userSearchCondition);
	
	ValidResult userStatusChange(Integer mchtUserId, String loginNameSession,String userStatus);
	
	ValidResult userInitPwd(Integer mchtUserId, String loginNameSession);
	
	ValidResult userAdd(MchtUser mchtUser, Integer mchtUserRoleId, String loginNameSession, String roleCodeSession, Integer orgIdSession);
    
	ValidResult userUpd(MchtUser mchtUser, Integer mchtUserRoleId, String loginNameSession, String roleCodeSession, Integer orgIdSession);
	
	MchtUser queryUpdateSelectList(Integer mchtUserId);
	
	List<MenuDTO> querySAInnerMenu(String roleCode);
}
