package com.pingan.qhzx.anshao.platform.common.service.qa;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.pingan.qhzx.anshao.platform.common.dao.pg.MchtCorpusCtxMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtCorpusCtx;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.ex.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;

@Service
public class QuestionsAndAnswersService implements IQuestionsAndAnswersService {
    private static final Logger logger = LoggerFactory.getLogger(QuestionsAndAnswersService.class);

    @Value("${csv.qa.path}")
    private String filePath;

    @Autowired
    private MchtCorpusCtxMapper mchtCorpusCtxMapper;

    @Override
    public List<MchtCorpusCtx> selMchtCorListByorgIdEffect(MchtCorpusCtx mchtCorpusCtx) {
        return mchtCorpusCtxMapper.selMchtCorListByorgIdEffect(mchtCorpusCtx);
    }

    // 把问答列表按照csv的格式转换成String(不包含Label)
    public String changeMchtCorpusCtxListToString(Org org) {
        MchtCorpusCtx mchtCorpusCtx = new MchtCorpusCtx();
        mchtCorpusCtx.setEffectiveFlag("1");
        Integer orgId = org.getOrgId();
        mchtCorpusCtx.setOrgId(orgId);
        List<MchtCorpusCtx> list = selMchtCorListByorgIdEffect(mchtCorpusCtx);
        logger.info("sync orgCode: {}, corpus size:{}", org.getOrgCode(), list.size());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Answer,keywords,Question");
        for (MchtCorpusCtx mchtCorpus : list) {
            stringBuilder.append("\r\n");// 换行
            String answer = mchtCorpus.getAnswer();
            if (answer == null) {
                answer = "";
            }
            stringBuilder.append(answer + ",");

            String keywords = mchtCorpus.getKeyWord();
            if (keywords == null) {
                keywords = "";
            }
            stringBuilder.append(keywords + ",");

            String question = mchtCorpus.getQuestion();
            if (question == null) {
                question = "";
            }
            stringBuilder.append(question);
        }
        return stringBuilder.toString();
    }

    // 把String写成csv文件
    private void writerToCsv(String qa, String orgCode) {
        String csvFilePath = filePath + orgCode;
        // 如果目录不存在，创建新目录。
        File csvFile = new File(csvFilePath);
        if (!csvFile.exists())
            csvFile.mkdirs();

        // 生成临时文件
        String tempFileName = csvFilePath + File.separator + orgCode + ".csv" + System.currentTimeMillis() + ".temp";
        File tempFile = new File(tempFileName);
        try {
            // 创建新的csv文件
            tempFile.createNewFile();
            Files.write(qa, tempFile, Charsets.UTF_8);
        } catch (Exception e) {
            logger.error("", e);
            throw new ServiceException(e.getMessage());
        }

        String fileName = csvFilePath + File.separator + orgCode + ".csv";
        File file = new File(fileName);
        // 删除原csv文件
        if (file.exists())
            file.delete();
        tempFile.renameTo(file);
    }

    @Override
    public void writerQAToCsv(Org org) {
        String qa = changeMchtCorpusCtxListToString(org);
        String orgCode = org.getOrgCode();
        writerToCsv(qa, orgCode);
    }
}
