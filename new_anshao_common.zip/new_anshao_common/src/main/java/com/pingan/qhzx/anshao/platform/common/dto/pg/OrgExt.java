package com.pingan.qhzx.anshao.platform.common.dto.pg;

public class OrgExt extends Org {
	
	private static final long serialVersionUID = -3964753705438125101L;

	private Long trafficInitNum;

	private Long corpusInitNum;

	private Long corpusTotalNum;

	public Long getTrafficInitNum() {
		return trafficInitNum;
	}

	public void setTrafficInitNum(Long trafficInitNum) {
		this.trafficInitNum = trafficInitNum;
	}

	public Long getCorpusInitNum() {
		return corpusInitNum;
	}

	public void setCorpusInitNum(Long corpusInitNum) {
		this.corpusInitNum = corpusInitNum;
	}

	public Long getCorpusTotalNum() {
		return corpusTotalNum;
	}

	public void setCorpusTotalNum(Long corpusTotalNum) {
		this.corpusTotalNum = corpusTotalNum;
	}

}