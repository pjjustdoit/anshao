package com.pingan.qhzx.anshao.platform.common.service.mail;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pingan.qhzx.anshao.platform.common.dao.pg.MailListMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MailList;
import com.pingan.qhzx.anshao.platform.common.enums.DicCodeEnum;

/**
 * Created by zhangshan193 on 16/9/30.
 */
@Service
public class MailService implements IMailService {

    private static final Logger logger = LoggerFactory.getLogger(MailService.class);

    @Autowired
	private MailListMapper mailListMapper;
    
    @Transactional
	@Override
	public void mailListInsert(String recipients, String mailCC, String mailType, String mailTitle,
			String mailContent, boolean hasAttach, String operateBy) {
		MailList mailList = new MailList();
		// TODO
		mailList.setRecipients(recipients);
		mailList.setCc(mailCC);
		mailList.setMailType(mailType);
		mailList.setTitle(mailTitle);
		mailList.setMailContent(mailContent);
		mailList.setHasAttach(hasAttach);
		mailList.setSendType(DicCodeEnum.SEND_TYPE_NOSENT.getCode());
		mailList.setCreatedBy(operateBy);
		mailList.setCreatedDate(new Date());
		mailList.setUpdatedBy(operateBy);
		mailList.setUpdatedDate(new Date());
		
		mailListMapper.insert(mailList);	
	}

}
