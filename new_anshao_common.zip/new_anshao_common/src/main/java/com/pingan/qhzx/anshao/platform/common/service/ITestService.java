package com.pingan.qhzx.anshao.platform.common.service;

public interface ITestService {

	String getResult(String variable);

}
