package com.pingan.qhzx.anshao.platform.common.service.wxhome;

import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.pingan.qhzx.anshao.platform.common.bean.wx.TextMsg;
import com.thoughtworks.xstream.XStream;

/**
 * Created by peijian280 on 17/2/8.
 */
@Service
public class WxHomeService implements IWxHomeService {
	
	private static final Logger log = LoggerFactory.getLogger(WxHomeService.class);

	@Override
	public Map<String, String> acceptMessage(HttpServletRequest request) {
		try {
			InputStream inputStream = request.getInputStream();
			Map<String, String> acceptMessagemMap = parseXml(inputStream);
//			String toUserName = acceptMessagemMap.get("ToUserName");
//			String fromUserName = acceptMessagemMap.get("FromUserName");
			String msgType = acceptMessagemMap.get("MsgType");
//			String content = acceptMessagemMap.get("Content");
			if(!"text".equals(msgType)) {
				log.info("不支持其它的消息类型");
			}
			inputStream.close();
			return acceptMessagemMap;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@Override
	public String sendMessage(Map<String, String> acceptMessagemMap, String answer) {
		TextMsg textMsg = new TextMsg();
		textMsg.setToUserName(acceptMessagemMap.get("FromUserName"));// 发送和接收信息“User”刚好相反
		textMsg.setFromUserName(acceptMessagemMap.get("ToUserName"));
		textMsg.setCreateTime(new Date().getTime());// 消息创建时间 （整型）
		textMsg.setMsgType("text");// 文本类型消息
		textMsg.setContent(answer);

		//将构造的信息转化为微信识别的xml格式
		XStream xStream = new XStream();
		xStream.alias("xml", textMsg.getClass());
		String textMsg2Xml = xStream.toXML(textMsg);
		log.info(textMsg2Xml);
		return textMsg2Xml;

	}
	
	protected Map<String, String> parseXml(InputStream inputStream) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		SAXReader reader = new SAXReader();
		Document doc = reader.read(inputStream);
		Element root = doc.getRootElement();
		List<Element> elementList = root.elements();
		for(Element e : elementList) {
			map.put(e.getName(), e.getText().trim());
		}
		Set<String> keySet = map.keySet();
		for (String key : keySet) {
			log.info(key + ":" + map.get(key));
		}
		return map;
	}
	
		
}
