package com.pingan.qhzx.anshao.platform.common.dto;

import java.io.Serializable;

/**
 * Created by YUZILEI022 on 2016-07-20.
 */
public class BaseDTO implements Serializable {
    
}
