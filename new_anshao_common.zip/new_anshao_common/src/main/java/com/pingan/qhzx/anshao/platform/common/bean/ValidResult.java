package com.pingan.qhzx.anshao.platform.common.bean;

import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;

/**
 * Created by yuzilei022 on 16/9/26.
 */
public class ValidResult {
    private ResponseEnum responseEnum;
    private JSONObject jsonObject;
    private Map<String, Object> objectMap = Maps.newHashMap();


    public ValidResult(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public ValidResult() {
    }

    public static ValidResult createValidResult(ResponseEnum responseEnum) {
        ValidResult validResult = new ValidResult(WebUtils.createErrorResult(responseEnum));
        validResult.responseEnum = responseEnum;
        return validResult;
    }

    public static ValidResult createSuccessResult() {
        return createValidResult(ResponseEnum.SUCCESS);
    }

    public static ValidResult createSuccessResult(Object data) {
        ValidResult validResult = createValidResult(ResponseEnum.SUCCESS);
        validResult.jsonObject.put("data", data);
        return validResult;
    }

    public static ValidResult createValidResult(ResponseEnum responseEnum, Object data) {
        ValidResult validResult = createValidResult(responseEnum);
        validResult.jsonObject.put("data", data);
        return validResult;
    }

    public ResponseEnum getResponseEnum() {
        return responseEnum;
    }

    public boolean valid() {
        return jsonObject == null || ResponseEnum.SUCCESS.getCode().equals(jsonObject.get(WebUtils.CODE));
    }

    public JSONObject toWebResult() {
        return jsonObject;
    }
    
    public Object get(Object key) {
        return objectMap.get(key);
    }

    public ValidResult put(String key, Object value) {
        objectMap.put(key, value);
        return this;
    }

}
