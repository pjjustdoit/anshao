package com.pingan.qhzx.anshao.platform.common.web.form;

import com.pingan.qhzx.anshao.platform.common.web.common.AppCommonForm;

/**
 * Created by yuzilei869 on 16/7/21.
 */
public class LoginForm extends AppCommonForm {

    private String userPwd;
    private String loginName;

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public boolean isValidPassword() {
		return getUserPwd().length() == 32;
	}
}
