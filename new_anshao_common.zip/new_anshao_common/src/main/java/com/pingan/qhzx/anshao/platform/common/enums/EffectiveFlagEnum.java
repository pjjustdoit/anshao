package com.pingan.qhzx.anshao.platform.common.enums;

/**
 * Created by zhangshan193 on 16/9/30.
 */
public enum EffectiveFlagEnum {

    EFFECTIVE("1","有效"),
    IN_EFFECTIVE("0","无效");

    private String code;
    private String desc;

    private EffectiveFlagEnum(String code,String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
