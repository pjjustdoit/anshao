package com.pingan.qhzx.anshao.platform.common.service.systemSetting;

import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtRobot;

public interface ISystemSettingService {

	/**
	 * 机器人配置Detail
	 * 
	 * @param mchtRobotId
	 */
	MchtRobot robotDetail(Integer mchtRobotId);
	
	/**
	 * 机器人设置
	 * 
	 * @param MchtRobot
	 */
	void robotSetting(MchtRobot mchtRobot);
	
	/**
	 * 新增机器人
	 * 
	 * @param mchtRobot
	 */
	void createRobot(MchtRobot mchtRobot);
}
