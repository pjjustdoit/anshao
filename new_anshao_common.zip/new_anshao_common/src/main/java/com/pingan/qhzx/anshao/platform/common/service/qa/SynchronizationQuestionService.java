package com.pingan.qhzx.anshao.platform.common.service.qa;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pingan.qhzx.anshao.platform.common.bean.qa.SynchronizationQuestionBean;
import com.pingan.qhzx.anshao.platform.common.dao.pg.UnknownQaMapper;
import com.pingan.qhzx.anshao.platform.common.dto.qa.SynchronizationQuestionDTO;

@Service
public class SynchronizationQuestionService implements ISynchronizationQuestionService {

	@Autowired
	private UnknownQaMapper unknownQaMapper;

	@Override
	public Integer selectBatchNo() {
		return unknownQaMapper.selectBatchNo();
	}

	@Override
	public int updateSyncSatus(SynchronizationQuestionDTO synchronizationQuestionDTO) {
		return unknownQaMapper.updateSyncSatus(synchronizationQuestionDTO);
	}

	@Override
	public List<SynchronizationQuestionBean> seltQaSerListByOrgIdSerNo(Integer batchNo) {
		return unknownQaMapper.seltQaSerListByOrgIdSerNo(batchNo);
	}

	@Override
	public Integer unknowQuestions() {
		Integer batchNo = selectBatchNo();
		SynchronizationQuestionDTO synchronizationQuestionDTO = new SynchronizationQuestionDTO();
		synchronizationQuestionDTO.setBatchNo(batchNo);
		List<String> syncStateList = new ArrayList<String>();
		syncStateList.add("0");// 未同步
		syncStateList.add("3");// 同步失败
		synchronizationQuestionDTO.setSyncStateList(syncStateList);
		synchronizationQuestionDTO.setSyncStatus("2");// 状态为"更新中"
		Calendar calendar = Calendar.getInstance();
		Date endDate = calendar.getTime();
		synchronizationQuestionDTO.setEndDate(endDate);
		synchronizationQuestionDTO.setUpdatedDate(endDate);
		calendar.add(Calendar.DATE, -3);
		Date startDate = calendar.getTime();
		synchronizationQuestionDTO.setStartDate(startDate);
		updateSyncSatus(synchronizationQuestionDTO);
		return batchNo;
	}

	@Override
	public void updateSyncSatuByBatchNo(SynchronizationQuestionDTO synchronizationQuestionDTO) {
		unknownQaMapper.updateSyncSatuByBatchNo(synchronizationQuestionDTO);
	}
}
