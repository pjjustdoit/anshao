package com.pingan.qhzx.anshao.platform.common.enums;

/**
 * Created by yuzilei869 on 16/7/20.
 */
public enum ForceChangePwdEnum {
	YES("1","是"),
	NO("0","否");

    private String code;

    private String desc;

    ForceChangePwdEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
