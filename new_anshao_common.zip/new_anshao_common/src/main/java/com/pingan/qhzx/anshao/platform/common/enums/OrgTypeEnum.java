package com.pingan.qhzx.anshao.platform.common.enums;

public enum OrgTypeEnum {
	
	INTERNAL("INTERNAL","内部机构"),
	PARTNER("PARTNER","外部合作伙伴");
	
	public String code;
	private String desc;
	
	private OrgTypeEnum(String code,String desc){
		this.code = code;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
}
