package com.pingan.qhzx.anshao.platform.common.bean.knowledge;

import com.paic.pafa.biz.dto.BaseDTO;

/**
 * 分页查询基类
 * 
 * @author LIUPENGLIANG375 创建时间：2016年10月9日 下午3:33:29
 */
public class PageDTO extends BaseDTO {
	
	private static final long serialVersionUID = -2789070625794074989L;

	private Integer totalPage; // 总页数
	private Integer totalCount; // 总条数
	private Integer currentPage; // 当前页
	private Integer pageSize; // 每页条数

	public Integer getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(Integer totalPage) {
		this.totalPage = totalPage;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getCurrentPage() {
		return currentPage == null ? 1 : currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public Integer getPageSize() {
		return pageSize == null ? 10 : pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

}
