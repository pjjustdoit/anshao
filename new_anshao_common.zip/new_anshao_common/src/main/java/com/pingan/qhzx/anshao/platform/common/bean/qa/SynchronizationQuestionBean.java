package com.pingan.qhzx.anshao.platform.common.bean.qa;

import java.util.Date;

public class SynchronizationQuestionBean {
	private Integer orgId;
	private String orgCode;
	private String custId;

	// 未知问题id
	private Long unknowQaId;

	// 未知问题提交时间
	private Date submitDate;

	// 未知问题
	private String question;

	// 未知问题來源
	private String unknownType;

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public Long getUnknowQaId() {
		return unknowQaId;
	}

	public void setUnknowQaId(Long unknowQaId) {
		this.unknowQaId = unknowQaId;
	}

	public Date getSubmitDate() {
		return submitDate;
	}

	public void setSubmitDate(Date submitDate) {
		this.submitDate = submitDate;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getUnknownType() {
		return unknownType;
	}

	public void setUnknownType(String unknownType) {
		this.unknownType = unknownType;
	}

}
