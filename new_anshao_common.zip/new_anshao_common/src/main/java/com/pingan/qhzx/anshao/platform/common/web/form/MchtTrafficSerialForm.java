package com.pingan.qhzx.anshao.platform.common.web.form;

import java.io.Serializable;
import java.util.Date;

import com.pingan.qhzx.anshao.platform.common.web.common.AppCommonForm;
import org.springframework.format.annotation.DateTimeFormat;

public class MchtTrafficSerialForm extends AppCommonForm{

	private static final long serialVersionUID = -871560803543827860L;
	
	private Long mchtTrafficSerialId;

    private Integer orgId;    

    private String serialType;

    private String serialDesc;

    private Long occurNum;

    private Long beforeNum;

    private Long afterNum;

    private Long targetId;

    private Date occurDate;

    private Integer pageSize;
    
    private Integer currentPage;
    
    private String orgCode;
    
    private String orgName;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date startDate;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date endDate;
    
    private String createdBy;
    
	public Long getMchtTrafficSerialId() {
		return mchtTrafficSerialId;
	}

	public void setMchtTrafficSerialId(Long mchtTrafficSerialId) {
		this.mchtTrafficSerialId = mchtTrafficSerialId;
	}

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public String getSerialType() {
		return serialType;
	}

	public void setSerialType(String serialType) {
		this.serialType = serialType;
	}

	public String getSerialDesc() {
		return serialDesc;
	}

	public void setSerialDesc(String serialDesc) {
		this.serialDesc = serialDesc;
	}

	public Long getOccurNum() {
		return occurNum;
	}

	public void setOccurNum(Long occurNum) {
		this.occurNum = occurNum;
	}

	public Long getBeforeNum() {
		return beforeNum;
	}

	public void setBeforeNum(Long beforeNum) {
		this.beforeNum = beforeNum;
	}

	public Long getAfterNum() {
		return afterNum;
	}

	public void setAfterNum(Long afterNum) {
		this.afterNum = afterNum;
	}

	public Long getTargetId() {
		return targetId;
	}

	public void setTargetId(Long targetId) {
		this.targetId = targetId;
	}

	public Date getOccurDate() {
		return occurDate;
	}

	public void setOccurDate(Date occurDate) {
		this.occurDate = occurDate;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
    
}
