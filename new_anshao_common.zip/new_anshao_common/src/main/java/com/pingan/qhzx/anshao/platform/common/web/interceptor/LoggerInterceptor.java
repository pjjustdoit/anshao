package com.pingan.qhzx.anshao.platform.common.web.interceptor;

import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by YUZILEI869 on 2016-01-15.
 */
public class LoggerInterceptor extends BaseInterceptor {

    private static final Logger log = LoggerFactory.getLogger("com.cs.dsd.web.access.txn.LoggerInterceptor");
    private AtomicLong atomicLong = new AtomicLong(0);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        MDC.put("txnId", String.valueOf(atomicLong.addAndGet(1)));
        log.info("path:[{}], params:[{}],ip:[{}]", request.getRequestURI(), JSON.toJSONString(request.getParameterMap()), request.getRemoteAddr());
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        MDC.remove("txnId");
    }
}
