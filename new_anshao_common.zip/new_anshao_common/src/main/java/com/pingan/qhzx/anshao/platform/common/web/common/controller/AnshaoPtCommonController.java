package com.pingan.qhzx.anshao.platform.common.web.common.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.platform.common.bean.UserSessionBean;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.enums.DicCodeEnum;
import com.pingan.qhzx.anshao.platform.common.service.IOrgService;
import com.pingan.qhzx.anshao.platform.common.utils.SessionUtils;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;
import com.pingan.qhzx.anshao.platform.common.web.common.CommonController;



/**
 * Created by yuzilei869 on 16/7/21.
 */

public class AnshaoPtCommonController extends CommonController {

	@Autowired
	private IOrgService orgService;
	
	public UserSessionBean getUserInfo(HttpServletRequest request) {
		SessionUtils sessionUtils = new SessionUtils(request.getSession());
		return sessionUtils.getUserInfo();
	}
	
	public JSONObject selectList(HttpServletRequest request) {

    	Integer orgId = null;
		HashMap<String, Object> data = new HashMap<String, Object>();
		UserSessionBean userSessionBean = getUserInfo(request);
		if (!DicCodeEnum.SUPER_ROLE.getCode().equals(userSessionBean.getRoleCode())) {
			orgId = userSessionBean.getOrgId();
		}
		List<Org> orgList = orgService.querySelectList(orgId);
		data.put("list", orgList);
		return WebUtils.createSuccResult(data);
	}

}
