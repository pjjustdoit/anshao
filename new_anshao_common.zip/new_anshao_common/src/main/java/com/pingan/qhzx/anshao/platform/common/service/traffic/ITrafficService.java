package com.pingan.qhzx.anshao.platform.common.service.traffic;

import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtRobot;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtTrafficSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.QaSerial;
import com.pingan.qhzx.anshao.platform.common.dto.pg.TrafficAccount;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.AnswerParser;
import com.pingan.qhzx.anshao.platform.common.service.model.bean.QaCountBean;
import org.springframework.scheduling.annotation.Async;

/**
 * Created by yuzilei022 on 16/9/26.
 */
public interface ITrafficService {
    String generateSerialNo();


    MchtRobot selectRobotByOrgCode(String orgCode);

    TrafficAccount selectMchtTrafficAccountByOrgId(Integer orgId);

    @Async
    void record(QaSerial qaSerial);

    Long selectQaSerialId();

    void saveOrgTrafficSerial(MchtTrafficSerial mchtTrafficSerial, Integer recThreshold);

    void updateOrgTrafficAndInitCache(Integer orgId, QaCountBean qaCountBean);

    void recUnknownQa(AnswerParser answerParser, String unknownType);
}
