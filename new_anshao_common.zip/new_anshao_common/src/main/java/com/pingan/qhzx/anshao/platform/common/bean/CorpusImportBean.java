package com.pingan.qhzx.anshao.platform.common.bean;

import java.io.Serializable;

/**
 * Created by zhangshan193 on 16/10/10.
 */
public class CorpusImportBean implements Serializable {

    private static final long serialVersionUID = 7145377585793673825L;

    private String classifyName;
    private String exactMatchFlag;
    private String question;
    private String answer;
    private String expireDateValue;
    private String keyWord;


    public String getClassifyName() {
        return classifyName;
    }

    public void setClassifyName(String classifyName) {
        this.classifyName = classifyName == null ? null : classifyName.trim();
    }

    public String getExactMatchFlag() {
        return exactMatchFlag;
    }

    public void setExactMatchFlag(String exactMatchFlag) {
        this.exactMatchFlag = exactMatchFlag == null ? null : exactMatchFlag.trim();
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question == null ? null : question.trim();
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer == null ? null : answer.trim();
    }

    public String getExpireDateValue() {
        return expireDateValue;
    }

    public void setExpireDateValue(String expireDateValue) {
        this.expireDateValue = expireDateValue == null ? null : expireDateValue.trim();
    }        

    public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord == null ? null : keyWord.trim();
	}

	@Override
	public String toString() {
		return "CorpusImportBean [classifyName=" + classifyName
				+ ", exactMatchFlag=" + exactMatchFlag + ", question="
				+ question + ", answer=" + answer + ", expireDateValue="
				+ expireDateValue + ", keyWord=" + keyWord + "]";
	}

}
