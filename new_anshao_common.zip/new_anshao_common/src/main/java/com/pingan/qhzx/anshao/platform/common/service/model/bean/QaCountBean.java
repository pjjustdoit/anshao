package com.pingan.qhzx.anshao.platform.common.service.model.bean;

import org.joda.time.DateTime;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by yuzilei022 on 16/10/21.
 */
public class QaCountBean implements Serializable {

    private Long counter;

    private Date createDate;

    public QaCountBean() {
        init();
    }

    public void init() {
        counter = 0l;
        createDate = DateTime.now().toDate();
    }

    public Long getCounter() {
        return counter;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Long plusOccurSum(Long occurSum) {
        return this.counter += occurSum;
    }

    public boolean needRefresh(Integer recThreshold) {
        return this.counter > recThreshold || new DateTime(this.createDate).isBefore(DateTime.now().plusMinutes(-30));
    }
}
