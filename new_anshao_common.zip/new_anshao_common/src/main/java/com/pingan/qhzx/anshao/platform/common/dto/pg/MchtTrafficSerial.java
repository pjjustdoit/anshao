package com.pingan.qhzx.anshao.platform.common.dto.pg;

import com.pingan.qhzx.anshao.platform.common.dto.BaseDTO;

import java.util.Date;

public class MchtTrafficSerial extends BaseDTO {
    private Long mchtTrafficSerialId;

    private Integer orgId;

    private String serialType;

    private String serialDesc;

    private Long occurNum;

    private Long beforeNum;

    private Long afterNum;

    private Long targetId;

    private Date occurDate;

    private Date createdDate;

    private String createdBy;

    /**
     * 计费状态 0＝未统计 1=已计入 2=计入中
     */
    private String chargingStatus;

    /**
     * 计费批次
     */
    private Long chargingBatchNo;

    public Long getChargingBatchNo() {
        return chargingBatchNo;
    }

    public void setChargingBatchNo(Long chargingBatchNo) {
        this.chargingBatchNo = chargingBatchNo;
    }

    public String getChargingStatus() {
        return chargingStatus;
    }

    public void setChargingStatus(String chargingStatus) {
        this.chargingStatus = chargingStatus;
    }

    public Long getMchtTrafficSerialId() {
        return mchtTrafficSerialId;
    }

    public void setMchtTrafficSerialId(Long mchtTrafficSerialId) {
        this.mchtTrafficSerialId = mchtTrafficSerialId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getSerialType() {
        return serialType;
    }

    public void setSerialType(String serialType) {
        this.serialType = serialType == null ? null : serialType.trim();
    }

    public String getSerialDesc() {
        return serialDesc;
    }

    public void setSerialDesc(String serialDesc) {
        this.serialDesc = serialDesc == null ? null : serialDesc.trim();
    }

    public Long getOccurNum() {
        return occurNum;
    }

    public void setOccurNum(Long occurNum) {
        this.occurNum = occurNum;
    }

    public Long getBeforeNum() {
        return beforeNum;
    }

    public void setBeforeNum(Long beforeNum) {
        this.beforeNum = beforeNum;
    }

    public Long getAfterNum() {
        return afterNum;
    }

    public void setAfterNum(Long afterNum) {
        this.afterNum = afterNum;
    }

    public Long getTargetId() {
        return targetId;
    }

    public void setTargetId(Long targetId) {
        this.targetId = targetId;
    }

    public Date getOccurDate() {
        return occurDate;
    }

    public void setOccurDate(Date occurDate) {
        this.occurDate = occurDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy == null ? null : createdBy.trim();
    }
}