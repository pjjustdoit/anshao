package com.pingan.qhzx.anshao.platform.common.bean;

import java.io.Serializable;

/**
 * Created by yuzilei022 on 16/8/16.
 */
public class BaseBean implements Serializable {
	private static final long serialVersionUID = -5189470077627811255L;    
}
