package com.pingan.qhzx.anshao.platform.common.service.model;

/**
 * Created by yuzilei022 on 16/10/12.
 */
public interface ICorpusSyncService {
    void syncCorpus(Integer orgId);
}
