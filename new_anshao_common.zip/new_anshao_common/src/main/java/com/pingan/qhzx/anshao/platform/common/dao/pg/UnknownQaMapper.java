package com.pingan.qhzx.anshao.platform.common.dao.pg;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.pingan.qhzx.anshao.platform.common.bean.qa.SynchronizationQuestionBean;
import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.UnknownQa;
import com.pingan.qhzx.anshao.platform.common.dto.qa.SynchronizationQuestionDTO;

public interface UnknownQaMapper extends BaseMapper {
	int deleteByPrimaryKey(Long unknowQaId);

	int insert(UnknownQa record);

	int insertSelective(UnknownQa record);

	UnknownQa selectByPrimaryKey(Long unknowQaId);

	int updateByPrimaryKeySelective(UnknownQa record);

	int updateByPrimaryKey(UnknownQa record);

	Integer selectBatchNo();

	List<SynchronizationQuestionBean> seltQaSerListByOrgIdSerNo(@Param(value = "batchNo") Integer batchNo);

	/**
	 * 把状态为新建和失败并且时间是最近三天的问题的状态修改为更新中
	 * 
	 * @param synchronizationQuestionDTO
	 * @return int
	 */
	int updateSyncSatus(SynchronizationQuestionDTO synchronizationQuestionDTO);

	/**
	 * 把状态改为更新失败或者更新成功
	 * 
	 * @param synchronizationQuestionDTO
	 * @return int
	 */
	int updateSyncSatuByBatchNo(SynchronizationQuestionDTO synchronizationQuestionDTO);
}