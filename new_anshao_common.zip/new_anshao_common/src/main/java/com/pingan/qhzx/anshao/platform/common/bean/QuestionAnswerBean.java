package com.pingan.qhzx.anshao.platform.common.bean;

import java.util.Date;

public class QuestionAnswerBean {
	private Long mchtCorpusCtxId;

    private Integer orgId;

    private Integer zskClassifyId;

    private String exactMatchFlag;

    private String question;

    private String answer;

    private String keyWord;

    private Date expireDate;

    private String effectiveFlag;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;

    private String classifyName;

	public Long getMchtCorpusCtxId() {
		return mchtCorpusCtxId;
	}

	public void setMchtCorpusCtxId(Long mchtCorpusCtxId) {
		this.mchtCorpusCtxId = mchtCorpusCtxId;
	}

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public Integer getZskClassifyId() {
		return zskClassifyId;
	}

	public void setZskClassifyId(Integer zskClassifyId) {
		this.zskClassifyId = zskClassifyId;
	}

	public String getExactMatchFlag() {
		return exactMatchFlag;
	}

	public void setExactMatchFlag(String exactMatchFlag) {
		this.exactMatchFlag = exactMatchFlag;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}

	public Date getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	public String getEffectiveFlag() {
		return effectiveFlag;
	}

	public void setEffectiveFlag(String effectiveFlag) {
		this.effectiveFlag = effectiveFlag;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getClassifyName() {
		return classifyName;
	}

	public void setClassifyName(String classifyName) {
		this.classifyName = classifyName;
	}
}
