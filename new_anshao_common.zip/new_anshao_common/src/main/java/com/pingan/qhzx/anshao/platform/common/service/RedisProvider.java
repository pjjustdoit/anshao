package com.pingan.qhzx.anshao.platform.common.service;

import com.google.common.base.Charsets;
import com.pingan.pafa.redis.cache.RedisCacheBean;

/**
 * Created by yuzilei869 on 16/7/21.
 */
public class RedisProvider<V> {

    private int expireTime;

    private RedisCacheBean<V> redisCacheBean;

    protected RedisProvider(int expireTime, RedisCacheBean<V> redisCacheBean) {
        this.expireTime = expireTime;
        this.redisCacheBean = redisCacheBean;
    }

    static <T> RedisProvider<T> buildProvider(int expireTime, RedisCacheBean<T> redisCacheBean) {
        redisCacheBean.afterPropertiesSet();
        return new RedisProvider<T>(expireTime, redisCacheBean);
    }

    public boolean add(String key, V value) {
        return redisCacheBean.add(key, value, expireTime);
    }

    public boolean remove(String... keys) {
        return redisCacheBean.remove(buildKey(keys));
    }

    public V get(String... keys) {
        return redisCacheBean.get(buildKey(keys));
    }

    public String buildKey(String... keys) {
        StringBuilder sb = new StringBuilder(50);
        for (int i = 0; i < keys.length; i++) {
            if (i != 0) {
                sb.append(".");
            }
            sb.append(keys[i]);
        }
        return sb.toString();
    }

    public void set(String key, V value) {
        redisCacheBean.set(key, value, expireTime);
    }

    public boolean expire(String key) {
        return redisCacheBean.expire(key, expireTime);
    }


    public String nativeStr(String... keys) {
        byte[] bytes = redisCacheBean.getRedis().getCommands().get((redisCacheBean.getNamespace() + buildKey(keys)).getBytes(Charsets.UTF_8));
        if (bytes != null) {
            return new String(bytes, Charsets.UTF_8);
        }
        return null;
    }
}