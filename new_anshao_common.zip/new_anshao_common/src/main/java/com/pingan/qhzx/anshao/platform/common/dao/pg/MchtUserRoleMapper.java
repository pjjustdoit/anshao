package com.pingan.qhzx.anshao.platform.common.dao.pg;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.pingan.qhzx.anshao.platform.common.dao.mybatis.BaseMapper;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRole;

public interface MchtUserRoleMapper extends BaseMapper {
    int deleteByPrimaryKey(Integer mchtUserRoleId);

    int insert(MchtUserRole record);

    int insertSelective(MchtUserRole record);

    MchtUserRole selectByPrimaryKey(Integer mchtUserRoleId);

    int updateByPrimaryKeySelective(MchtUserRole record);

    int updateByPrimaryKey(MchtUserRole record);
    
    List<MchtUserRole> selectByUserIdOrgId(@Param("mchtUserId") Integer mchtUserId,
    		@Param("orgId") Integer orgId);
    
    List<MchtUserRole> queryRoleList(@Param("loginName") String loginName,
    		@Param("orgId") Integer orgId);
    
    Long selectPaterRoleCount(@Param("orgId") Integer orgId);
    
    Long queryCountByRoleName(@Param("mchtUserRoleId") Integer mchtUserRoleId, @Param("roleName") String roleName);
    
    List<MchtUserRole> queryUserUpdateSelectList(@Param("loginName")String loginName, @Param("orgId")Integer orgId);
    
    List<MchtUserRole> queryAllRoleList();
    
    List<MchtUserRole> queryUserQuerySelectList(@Param("loginName")String loginName, @Param("orgId")Integer orgId);

    MchtUserRole selectRoleInfoByPrimaryKey(Integer mchtUserRoleId);
}