package com.pingan.qhzx.anshao.platform.common.web.common.controller.user;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.platform.common.bean.UserSessionBean;
import com.pingan.qhzx.anshao.platform.common.bean.ValidResult;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUser;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserAuth;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MchtUserRole;
import com.pingan.qhzx.anshao.platform.common.dto.pg.MenuDTO;
import com.pingan.qhzx.anshao.platform.common.dto.pg.Org;
import com.pingan.qhzx.anshao.platform.common.enums.ForceChangePwdEnum;
import com.pingan.qhzx.anshao.platform.common.enums.ResponseEnum;
import com.pingan.qhzx.anshao.platform.common.service.IOrgService;
import com.pingan.qhzx.anshao.platform.common.service.mchtUser.IMchtUserService;
import com.pingan.qhzx.anshao.platform.common.utils.SessionUtils;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;
import com.pingan.qhzx.anshao.platform.common.web.common.controller.AnshaoPtCommonController;
import com.pingan.qhzx.anshao.platform.common.web.form.LoginForm;
import com.pingan.qhzx.anshao.platform.common.web.form.PasswordForm;

/**
 * Created by yuzilei869 on 16/7/21.
 */
public class LoginCommonController extends AnshaoPtCommonController {

	private static final Logger log = LoggerFactory.getLogger(LoginCommonController.class);

	@Autowired
	private IMchtUserService mchtUserService;

	@Autowired
	private IOrgService orgService;

	@ResponseBody
	@RequestMapping("/nologin/login")
	public JSONObject login(LoginForm loginForm, HttpServletRequest request) {
		try {
			ValidResult validResult = validUser(loginForm);
			if (!validResult.valid())
				return validResult.toWebResult();
			MchtUser user = (MchtUser) validResult.get("user");
			JSONObject vo = getLoginSuccessVo(user, request);
			return WebUtils.createErrorResult(ResponseEnum.SUCCESS, vo);

		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}

	private ValidResult validUser(LoginForm loginForm) {
		if (StringUtils.isBlank(loginForm.getLoginName()) || StringUtils.isBlank(loginForm.getUserPwd())
				|| !loginForm.isValidPassword()) {
			return ValidResult.createValidResult(ResponseEnum.INVALID_PARAMS);
		}

		return mchtUserService.loginValidUser(loginForm.getLoginName(), loginForm.getUserPwd());

	}

	private JSONObject getLoginSuccessVo(MchtUser User, HttpServletRequest request) {

		SessionUtils session = new SessionUtils(request.getSession());

		Org org = orgService.selectByPrimaryKey(User.getOrgId());

		List<MchtUserRole> userRoleList = mchtUserService.queryByUserIdOrgId(User.getMchtUserId(),
				org.getOrgId());
		
		// 权限
		List<MchtUserAuth> auths = mchtUserService.queryAuthByOrgIdMchtUserId(User.getOrgId(), User.getMchtUserId());

		List<MenuDTO> MenuList = mchtUserService.queryMenu(userRoleList.get(0).getMchtUserRoleId());
		
		session.setUserInfo(new UserSessionBean(User, org, auths, userRoleList, MenuList));

		return createLoginSuccResult(User, org, userRoleList, MenuList);
	}

	private JSONObject createLoginSuccResult(MchtUser tUser, Org mchtOrg,
			List<MchtUserRole> userRoleList, List<MenuDTO> MenuList) {
		JSONObject user = new JSONObject();
		JSONObject org = new JSONObject();
		
		user.put("userId", tUser.getMchtUserId());
		user.put("loginName", tUser.getLoginName());
		user.put("userName", tUser.getUserName());
		user.put("mobile", tUser.getMobile());
		user.put("userEmail", tUser.getUserEmail());
		user.put("userStatus", tUser.getUserStatus());
		user.put("createdDate", tUser.getCreatedDate());
		user.put("forceChangePwdFlag", tUser.getForceChangePwdFlag());
		
		org.put("orgId", mchtOrg.getOrgId());
		org.put("orgCode", mchtOrg.getOrgCode());
		org.put("orgName", mchtOrg.getOrgName());
		org.put("orgStatus", mchtOrg.getOrgStatus());
		user.put("org", org);

		user.put("userRole", userRoleList);

		user.put("menus", MenuList);	
		
		// 添加身份证号码
		return user;
	}

	@ResponseBody
	@RequestMapping("/nologin/logout")
	public JSONObject logout(HttpServletRequest request) {
		try {
			HttpSession session = request.getSession(false);
			if (session != null) {
				session.invalidate();
			}
			return WebUtils.createSuccResult();

		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
	public JSONObject changePwd(PasswordForm form, HttpServletRequest request) {
		try {
			// 返回结果
			JSONObject result = null;
			String loginName = form.getLoginName();
			String newPassword = form.getUserPwd();
			String originPwd = form.getOriginPwd();

			if (StringUtils.isBlank(loginName) || StringUtils.isBlank(newPassword) || !form.isValidPassword()
					|| StringUtils.isBlank(originPwd) || !form.isValidOriginPwd()) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_PARAMS);
			}

			MchtUser mchtUser = mchtUserService.selectForPwdChange(loginName, originPwd);

			if (mchtUser == null) {
				return WebUtils.createErrorResult(ResponseEnum.INVALID_LOGIN_PWD);
			}

			mchtUser.setUserPwd(newPassword);
			
			String forceChangePwdFlag = mchtUser.getForceChangePwdFlag();
			
			if (ForceChangePwdEnum.YES.getCode().equals(forceChangePwdFlag)) {
				mchtUser.setForceChangePwdFlag(ForceChangePwdEnum.NO.getCode());
			}
			
			mchtUser.setUpdatedBy(loginName);
			mchtUser.setUpdatedDate(new Date());
			
			mchtUserService.pwdChange(mchtUser);
			result = WebUtils.createSuccResult();
			return result;
		} catch (Exception e) {
			log.error("", e);
			return WebUtils.createErrorResult(ResponseEnum.FAILURE);
		}
	}
	
}
