package com.pingan.qhzx.anshao.platform.common.web.interceptor;

import com.alibaba.fastjson.JSONObject;
import com.pingan.qhzx.anshao.platform.common.utils.WebUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.http.entity.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by YUZILEI869 on 2015-12-08.
 */
public class ExceptionInterceptor extends BaseInterceptor {

    private static final Logger log = LoggerFactory.getLogger(ExceptionInterceptor.class);

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        if (ex != null) {
            log.error("[!!!未处理异常!!!] path:" + request.getRequestURI(), ex);
            response.setContentType(ContentType.APPLICATION_JSON.toString());
            JSONObject errorResult = WebUtils.createErrorResult();
            errorResult.put("exception", ExceptionUtils.getMessage(ex));
            if (log.isDebugEnabled())
                errorResult.put("stackTrace", ExceptionUtils.getStackTrace(ex));
            write(response, errorResult);
        }
    }
}
